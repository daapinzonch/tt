function getEmptyError(){return "No puede estar vac�o";}
function getLimitDotsError(limit){return limit == 0 ? "No puede tener puntos" : (limit == 1 ? "No debe tener m�s de " + limit + " punto" : "No debe tener m�s de " + limit + " puntos");}
function getInvertedCommaError(){return "No puede contener el caracter '";}
function getValueInvalidError(){return "No puede contener este valor";}
function getItemDontBelongError(){return "No pertenece a la lista desplegable";}
function getLengthError(length){return "Debe tener " + length + " caracteres";}
function getDateStructureInvalidError(){return "La estructura debe ser DD/MM/AAAA";}
function getLimitDayError(){return "El d�a debe estar entre 1 y 31";}
function getLimitMonthError(){return "El mes debe estar entre 1 y 12";}
function getMinimumDateError(){return "Debe ser mayor a la fecha actual";}
function getNumericError(){return "Debe ser num�rico";}
function getValueZeroError(){return "Este valor no puede ser cero";}
function getIncompleteValueError(){return "El valor no puede iniciar con el caracter punto";}