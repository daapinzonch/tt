/**********************************************************************************************************************************/
/********************************************* D O C U M E N T  O B J E C T  M O D E L ********************************************/
/**********************************************************************************************************************************/
// Add class to HTML element throught a selector
function addClass(selector, className){
	$(selector).addClass(className);
}

// Remove class to HTML element throught a selector
function removeClass(selector, className){
	$(selector).removeClass(className);
}

// Remove classes to HTML elements throught a classes array and selectors array
function removeClasses(selectors, classNames){
	for (i = 0; i < classNames.length; i++){
		for (j = 0; j < selectors.length; j++){
			removeClass(selectors[j], classNames[i]);
		}
	}
}

// Add classes to HTML elements throught a classes array and selectors array
function addClasses(selectors, classNames){
	for (i = 0; i < classNames.length; i++){
		for (j = 0; j < selectors.length; j++){
			addClass(selectors[j], classNames[i]);
		}
	}
}

// Add multiple classes to multiple elements
function addMultipleClassesToMultipleElements(selectors, classNames){
	selectors.forEach(function(a, b){addClass(a, classNames[b])})
}

// remove multiple classes to multiple elements
function removeMultipleClassesToMultipleElements(selectors, classNames){
	selectors.forEach(function(a, b){removeClass(a, classNames[b])})
}

// Assign content to a HTML element
function assignContent(selector, content){
	$(selector).html(content);
}

// Add content to a HTML element
function addContent(selector, content){
	$(selector).append(content);
}

// Assign new value to an input
function assignValue(selector, content){
	$(selector).val(content);
}

// Assign new value to multiple inputs
function assignMultipleValues(selectorsArray, contentsArray){
	for (var i = 0; i < selectorsArray.length; i++){
		assignValue(selectorsArray[i], contentsArray[i]);
	}
}

// Verify if HTML element have class
function hasClass(selector, soughtClass){
	return ($(selector).hasClass(soughtClass)) ? true : false;
}

// Set style to HTML element
function setStyle(selector, property, value){
	$(selector).css(property, value);
}

// If element has class1 exchange to class2 or it has class2 exchange to class1
function exchangeClass(selector, class1, class2){
	if (hasClass(selector, class1)){
		removeClass(selector, class1);
		addClass(selector, class2);
	} else if(hasClass(selector, class2)){
		removeClass(selector, class2);
		addClass(selector, class1);
	}
}

/**********************************************************************************************************************************/
/********************************************************** I N P U T S ***********************************************************/
/**********************************************************************************************************************************/
// Only allow numeric values in a input
function allowNumericValues(e){
	//if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
	if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
			 return;
	}
	if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
		e.preventDefault();
	}
}

// Only allow Text values in a input
function allowOnlyText(e){
	//if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
	if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110,190]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
			 return;
	}
	if ((e.shiftKey || (e.keyCode < 65 || e.keyCode > 90))) {
		e.preventDefault();
	}
}

// Only allow allowAlphaNumerics values in a input
function allowAlphaNumerics(e){
	//if ($.inArray(e.keyCode, [46, 8, 9, 27, 13]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
	if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 32, 110, 190]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
			 return;
	}
	if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 90)) && (e.keyCode < 96 || e.keyCode > 105)) {
		e.preventDefault();
	}
}

// Move cursor to last position
function moveCursorLastPosition(selector, length){
	$(selector).focus();
	$(selector)[0].setSelectionRange(length * 2, length * 2);
}

// Change an input property
function changeProperty(selector, property, value){
	$(selector).prop(property, value);
}

// Change multiple items property
function changeMultipleItemsProperty(selectorsArray, property, valuesArray){
	for (var i = 0; i < selectorsArray.length; i++){
		changeProperty(selectorsArray[i], property, valuesArray[i]);
	}
}

// Get data input depending type
function getCleanValueForm(selector, type, decimals, items, ids){
	if (compareString(type, "Date")){
		return $(selector).val().substring(6,10) + "/" + $(selector).val().substring(3,5) + "/" + $(selector).val().substring(0,2);
	} else if (compareString(type, "Text")){
		return compareString($(selector).val(), "") ? "NULL" : replaceAll($(selector).val(), ",", "");
	} else if (compareString(type, "Number")){
		return compareString($(selector).val(), "") || !isFinite(parseFloat($(selector).val())) ? "NULL" : parseFloat(replaceAll(replaceAll($(selector).val(), ",", ""), "%", "")).toFixed(decimals);
	} else if (compareString(type, "Percentage")){
		return compareString($(selector).val(), "") || !isFinite(parseFloat($(selector).val())) ? "NULL" : parseFloat(replaceAll(replaceAll($(selector).val(), ",", ""), "%", ""));
	} else if (compareString(type, "Id")){
		return compareString($(selector).val(), "") ? "NULL" : getIdItem($(selector).val(), items, ids);
	} else if (compareString(type, "Progress")){
		return $(selector).text().substring(0, $(selector).text().length - 1);
	}
}

// Show nit coincidences while the nit length is between 7 & 8
function showCoincidences(event, value, query, stringConnection, selectorInput, connection){
	var coincidences = convertItemsArrayToItemsEditableSelect(readDatamart(query, stringConnection, connection, recordSet));

	if (compareString(coincidences, "<option>Sin resultados</option>")){
		alert("No se encontraron coincidencias para este nit.");
	} else{
		destroyEditableSelect(selectorInput);
		loadEditableSelect(selectorInput, coincidences);
		instanceEditableSelect(selectorInput);
		assignValue(selectorInput, value);
		$(selectorInput).focus();
		moveCursorLastPosition(selectorInput, value.length);
	}
}

// Validate length SecondFilter Input
function validateSecondFilter(selector){
	if(compareString($(selector).val(), "")){
		removeClass(selector,"existFilter");
	}else{
		addClass(selector," existFilter");
	}
}


function resetModal(selectorsArray){
	selectorsArray.forEach(function(e){
		if(compareString(e[1], "text")){
			$(e[0]).text("");
		} else if(compareString(e[1], "input")){
			$(e[0]).val("");
		} else if(compareString(e[1], "container")){
			$(e[0]).html("");
			removeClass($(e[0]), "hide");
		}
	})
}

/**********************************************************************************************************************************/
/********************************************************* B U T T O N S **********************************************************/
/**********************************************************************************************************************************/
// Change button "Search coincidences" State
function changeStateSearchButton(e, nitSelector, buttonSelector){
	var nitLength = $(nitSelector).val().length;

	if (e.keyCode == 8){
		if (nitLength == 6 || nitLength == 0){
			clearEditableSelect(nitSelector);
			assignValue(nitSelector, $(nitSelector).val());
			moveCursorLastPosition(nitSelector, nitLength);
		}
	}

	changeProperty(buttonSelector, "disabled", nitLength > 6 ? false : true);
}

function moveScroll(selectorButton, selectorDiv){
	//move scroll left and right
	$(selectorButton).on('click', function(){
		if( ($(selectorDiv).scrollLeft()) <500){
			$(selectorDiv).animate({scrollLeft:1000},800)
		}else{
			$(selectorDiv).animate({scrollLeft:0},800)
		}
	})
}

/**********************************************************************************************************************************/
/********************************************************* S T R I N G S **********************************************************/
/**********************************************************************************************************************************/
// Compare two strings
function compareString(string, stringCompare){
	return (string.localeCompare(stringCompare) == 0) ? true : false;
}

// Replace all coincidences from string
function replaceAll(string, searchString, replaceString){
	return string.replace(new RegExp(searchString, "g"), replaceString);
}

// Replace all coincidences from array
function replaceAllArray(string, arraySearch, replaceSearch){
	for (var i = arraySearch.length - 1; i >= 0; i--) {
		string = string.replace(new RegExp(arraySearch[i], "g"), replaceSearch[i]);
	}
	return string;
}

// Convert first letter to Upper Case
function convertFirstLetterUpper(string){return string.charAt(0).toUpperCase() + string.slice(1);
}

// Get substring from string
function subString(string, indexStart, indexFinish){
	return string.substring(indexStart, indexFinish);
}

// Validate if a string is null, undefined, " " or ""
function isInvalid(string, stringReplace){
	return string == undefined || string == null || compareString(string, "") || compareString(string, "undefined") || compareString(string, " ") || compareString(string, "null") ? stringReplace : string;
}

// Validate if string contain substring
function contain(string, substring){
	return string.indexOf(substring) != -1 ? true : false;
}

/**********************************************************************************************************************************/
/********************************************************** T A B L E S ***********************************************************/
/**********************************************************************************************************************************/
// Sum column HTML Table
function sumColumn(classSelector){
	var sum = 0;
	$(classSelector).each(function(){
		var value = replaceAll($(this).text(), ",", "");
		if(!isNaN(value) && value.length != 0) {
			sum += parseFloat(value);
		}
	});

	return sum == 0 ? "" : addCommas(sum);
}

// Export Table to XLSX File
function exportTable(selectorTable, sheetName, fileName){

	showBootstrapDialog("Confirmaci�n", "Tenga en cuenta que la cantidad de registros a exportar depende del filtro aplicado en la tabla, �Desea continuar?", "DANGER", "CONFIRM", "NORMAL", function(result){if(result){
		try{
			var data = $(selectorTable).tableToJSON();

			if(typeof XLSX == 'undefined') XLSX = require('xlsx');

			var ws = XLSX.utils.json_to_sheet(data);
			var wb = XLSX.utils.book_new();

			XLSX.utils.book_append_sheet(wb, ws, sheetName);
			var wbout = XLSX.write(wb, {bookType:'xlsx', bookSST:false, type:'array'}); 
			saveAs(new Blob([wbout], {type:"text/xlsx"}), fileName + ".xlsx", false);
		} catch(e){
			alert("Ocurri� un error en proceso de exportaci�n (" + e.message + ").");
		}
	}});

}

// Add link on end table
function addLinkOnTable(selectorInfo, selectorPaginate, selectorLink, nameLink){
	$(selectorInfo).parent().removeClass(" col-sm-6");
	$(selectorInfo).parent().addClass(" col-sm-4");
	$(selectorPaginate).parent().removeClass(" col-sm-6");
	$(selectorPaginate).parent().addClass(" col-sm-4");
	$(selectorInfo).parent().after('<div class="col-md-4" style="text-align: center"><a id="' + selectorLink +'">' + nameLink + '</a></div>');
}

// Add Table Type RadioButtons
function addTableTypeRadioButtons(selectorInfo, selectorPaginate, radio1Class, radio2Class, radio3Class){
	$(selectorInfo).parent().removeClass("col-sm-6");
	$(selectorInfo).parent().addClass("col-sm-4");
	$(selectorPaginate).parent().removeClass(" col-sm-6");
	$(selectorPaginate).parent().addClass(" col-sm-4");
	$(selectorInfo).parent().after('<div class="col-md-4" style="text-align: center"><a><div class="divRadios" data-toggle="buttons" id="divRadios"><label class="radio-inline btn active' + radio1Class + '" id="labelRadio1"><input type="radio" name="radioAbiertas" id="radioAbiertas" value="">Op. Abiertas</label><label class="radio-inline btn btn-default' + radio2Class + '" id="labelRadio2"><input type="radio" name="radioFull" id="radioFull" value="">Mostrar todas las op.</label><label class="radio-inline btn btn-default' + radio3Class + '" id="labelRadio3"><input type="radio" name="radioGroup" id="radioGroup" value="">Mostrar mi grupo.</label></div></a></div>');
}

// Put Horizontally Button Scroll on DataTable
// function addScrollButton(selectorInfo){
	// $(selectorInfo).parent().after('<div class="col-md-3" style="text-align: center"><input type="button" value="Desplazamiento lateral" id="scrollLateral" class="buttonScroll"></div>');
	// moveScroll("#scrollLateral", ".scrollHorizontally");
// }

// Remove commas to specific columns of a HTML Table
function removeCommasToColumn(selectorTable, columnsArray){columnsArray.forEach(function(a){$(selectorTable + " tbody tr").each(function(){$(this).find("td:eq(" + a + ")").text(replaceAll($(this).find("td:eq(" + a + ")").text(), ",", ""))})})}

// Put commas to specific columns of a HTML Table
function putCommasToColumn(selectorTable, columnsArray){columnsArray.forEach(function(a){$(selectorTable + " tbody tr").each(function(){ $(this).find("td:eq(" + a + ")").text(addCommas($(this).find("td:eq(" + a + ")").text()))})})}

// Put Horizontally Scroll on DataTable
function putScrollOnTable(selectorTable){addClass($(selectorTable).parent().parent(), " scrollHorizontally");addClass($(selectorTable).parent().parent(), " scrollLateraly")}

// Destroy & Instance table with new values
function changeTableView(originLabelSelector, otherLabelSelector, anotherLabelSelector, statusToShowMe, timeToShowMe){
	if (!hasClass(originLabelSelector, "selected")){
		$(originLabelSelector).removeClass("btn-default");
		$(originLabelSelector).addClass(" selected");
		$(otherLabelSelector).removeClass("selected");
		$(otherLabelSelector).addClass(" btn-default");
		$(anotherLabelSelector).removeClass("selected");
		$(anotherLabelSelector).addClass(" btn-default");

		destroyTable(selectorDatatable);
		// Load data on table
		buildTable(headersTable, getOpportunities(usersToShowMe, statusToShowMe, timeToShowMe), selectorDatatable);
		// Instance DataTable
		instanceTable(selectorDatatable);
		// Add export link in datatable
		addLinkOnTable(selectorDatatable + "_info", selectorDatatable + "_paginate", "exportOpportunities", "Exportar oportunidades");
		// Add Horizontally Scroll on datatable
		putScrollOnTable(selectorDatatable);
		//addTableTypeRadioButtons(selectorDatatable + "_length", selectorDatatable + "_filter", " selected", "", "");
		// Add Horizontally Button Scroll on datatable
		// addScrollButton(selectorDatatable + "_length");
		// addClass("#divRadios", " hide");
	}
}
function changeTableGroup(usersToShowMe, statusToShowMe, timeToShowMe){
		destroyTable(selectorDatatable);
		// Load data on table
		buildTable(headersTable, getOpportunities(usersToShowMe, statusToShowMe, timeToShowMe), selectorDatatable);
		// Instance DataTable
		instanceTable(selectorDatatable);
		// Add export link in datatable
		addLinkOnTable(selectorDatatable + "_info", selectorDatatable + "_paginate", "exportOpportunities", "Exportar oportunidades");
		// Add Horizontally Scroll on datatable
		putScrollOnTable(selectorDatatable);
}

/**********************************************************************************************************************************/
/************************************************************ U S E R *************************************************************/
/**********************************************************************************************************************************/
// Get current user system
function getCurrentUser(net){
	return (net.UserName).toUpperCase();
}

/**********************************************************************************************************************************/
/********************************************************** A R R A Y S ***********************************************************/
/**********************************************************************************************************************************/
// Validate if a value velong to array
function isInArray(value, array){
	return (jQuery.inArray(value, array) !== -1) ? true : false;
}

// Convert items array to items string
function convertItemsArrayToItemsEditableSelect(itemsArray){
	var itemsSelect = "";

	for (i = 0; i < itemsArray.length; i++){
		itemsSelect = itemsSelect + "<option>" + itemsArray[i] + "</option>";
	}

	return itemsSelect;
}

// Convert Array to String
function arrayToString(separator, separator2, array){
	var string = "";

	for (i = 0; i < array.length; i++){
		string = string + separator + array[i] + separator2;
	}

	return string.substring(0, string.length - 1);
}

// Remove array element
function removeArrayElement(array, removeItem){
	return jQuery.grep(array, function(value){return value != removeItem;});
}

// Delete duplicates array elements
function deleteDuplicates(array, newArray){
	$.each(array, function(i, element){if($.inArray(element, newArray) === -1) newArray.push(element);});
}

// Get SelectEditableItem Id
function getIdItem(value, items, idsArrayToSearch){
	return idsArrayToSearch[(replaceAll(items, "<option>", "").split("</option>")).indexOf(value)];
}

// Concat tow array and return it
function concatArrays(arrayOne, arrayTwo){
	return arrayOne.concat(arrayTwo);
}

/**********************************************************************************************************************************/
/**************************************************** I N F O R M A T I V E S *****************************************************/
/**********************************************************************************************************************************/
// Show start message "Espere mientras el m?dulo termina de cargar."
function showMessageLoading(idTitleNotification, idBodyNotification){
	assignContent("#" + idTitleNotification, "<b>Cargando...</b>");
	assignContent("#" + idBodyNotification, "Espere mientras el m�dulo termina de cargar.");
}

// Hide start message when page is charged
function hideStartMessage(containerLoading, containerMain){
	addClass(containerLoading, " hide");
	removeClass(containerMain, " hide");
}

// Show a modal
function showModal(selector){
	$(selector).modal("show");
}

// Hide a modal
function hideModal(selector){
	$(selector).modal("hide");
}

// Show user connected
function showUserConnected(selector){
	$(selector).html("Usuario conectado: <b>" + users.currentUser + "</b>");
}

//Show Bootstrap Dialog
function showBootstrapDialog(title, message, typeClass, type, sizeClass, callback){

	if(type == 'ALERT'){
		BootstrapDialog.alert({
			title: ' <i class="fa fa-info-circle"></i> ' + title,
			message: message,
			type: typeClass == 'DEFAULT' ? BootstrapDialog.TYPE_DEFAULT : typeClass == 'INFO' ? BootstrapDialog.TYPE_INFO : typeClass == 'PRIMARY' ? BootstrapDialog.TYPE_PRIMARY : typeClass == 'SUCCESS' ? BootstrapDialog.TYPE_SUCCESS : typeClass == 'WARNING' ? BootstrapDialog.TYPE_WARNING : typeClass == 'DANGER' ? BootstrapDialog.TYPE_DANGER : alert('Clase Inexistente'),
			closable: true,
			size: sizeClass == 'SMALL' ? BootstrapDialog.SIZE_SMALL : sizeClass == 'NORMAL' ? BootstrapDialog.SIZE_NORMAL : sizeClass == 'WIDE' ? BootstrapDialog.SIZE_WIDE : sizeClass == 'LARGE' ? BootstrapDialog.SIZE_LARGE : alert('Tama?o Inexistente'),
			buttonLabel: 'Aceptar'
		});
	}

	else if( type == 'CONFIRM') {
		BootstrapDialog.confirm({
			title: '<i class="fa fa-question-circle"></i> ' + title,
			message: message,
			type: typeClass == 'DEFAULT' ? BootstrapDialog.TYPE_DEFAULT : typeClass == 'INFO' ? BootstrapDialog.TYPE_INFO : typeClass == 'PRIMARY' ? BootstrapDialog.TYPE_PRIMARY : typeClass == 'SUCCESS' ? BootstrapDialog.TYPE_SUCCESS : typeClass == 'WARNING' ? BootstrapDialog.TYPE_WARNING : typeClass == 'DANGER' ? BootstrapDialog.TYPE_DANGER : alert('Clase Inexistente'),
			closable: true,
			btnCancelLabel: 'Cancelar',
			size: sizeClass == 'SMALL' ? BootstrapDialog.SIZE_SMALL : sizeClass == 'NORMAL' ? BootstrapDialog.SIZE_NORMAL : sizeClass == 'WIDE' ? BootstrapDialog.SIZE_WIDE : sizeClass == 'LARGE' ? BootstrapDialog.SIZE_LARGE : alert('Tama?o Inexistente'),
			btnOKLabel: 'Aceptar',
			callback: callback
        });
	}
	else{
		alert("El tipo no existe")
	}
}


/**********************************************************************************************************************************/
/********************************************************* N U M B E R S **********************************************************/
/**********************************************************************************************************************************/
// Add commas separator from a number
function addCommas(value){
	value = value + '';

	var x = value.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;

	while (rgx.test(x1)) {
			x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}

	return x1 + x2;
}

/**********************************************************************************************************************************/
/************************************************************ T I M E *************************************************************/
/**********************************************************************************************************************************/
// Get current dateObtiene la hora actual con o sin formato (am o pm)
function getTime(withFormat){
	var currentTime = new Date();
	var format = getTimeFormat(currentTime);

	currentTime = validateTime(currentTime);

	return withFormat ? currentTime + " " + format : currentTime;
}

// Get current date
function getDate(numberDaysMinus, withStringMonths){
	var date = new Date();
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var day = date.getDate() - numberDaysMinus;

	if (withStringMonths){
		validateNumberDigits(day);
		month = convertNumericMonthToStringMonth(month);

		return day + " " + month + " " + year;
	} else{
		return verifyDate(day, month, year);
	}
}

// Get date and time
function getDateTime(date, time){
	return date + " " + time;
}

// Convert numeric month to string month (Ex: 01 -> Ene)
function convertNumericMonthToStringMonth(month){
	var stringMonths = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];

	return stringMonths[month - 1];
}

// Convert string month to numeric month (Ex: Ene -> 01)
function convertStringMonthToNumericMonth(month){
	var stringMonths = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
	var numericMonths = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];

	return numericMonths[stringMonths.indexOf(month)];
}

// Validate if day and month are less that 10
function verifyDate(day, month, year){
	day = validateNumberDigits(day);
	month = validateNumberDigits(month);

	return day + "/" + month + "/" + year;
}

// Valdiate if number is less that 10 and add 0 before
function validateNumberDigits(number){
	return (number < 10) ? "0" + number : number;
}

// Put "am" or "pm" to time
function getTimeFormat(time){
	return (time.getHours() < 12) ? "am" : "pm";
}

// Validate if seconds, minutes and hours are less that 10 and add 0 before
function validateTime(time){
	var hours = validateNumberDigits(time.getHours());
	var minutes = validateNumberDigits(time.getMinutes());
	var seconds = validateNumberDigits(time.getSeconds());

	return hours + ":" + minutes + ":" + seconds;
}

/**********************************************************************************************************************************/
/********************************************************** O T H E R S ***********************************************************/
/**********************************************************************************************************************************/
// Show modules for user type
function showModules(userType){
	var messageForTraders = "Usted no se encuentra en nuestra base de datos, este m�dulo es de uso exclusivo para <b>Traders</b>.";
	var messageForTradersConsultants = "Usted no se encuentra en nuestra base de datos, esta herramienta es de uso exclusivo para <b>Traders</b> y <b>Consultores</b>.";

	if (compareString(userType, "Administrador")){
		removeClasses(["#linkPaymentOrders", "#linkFailedOperations", "#linkBussinessTactics", "#linkPipeline", "#linkVencimientos", "#buttonPaymentOrders", "#buttonFailedOperations", "#buttonBussinessTactics", "#buttonPipeline", "#buttonExpirations","#linkPET","#buttonPET","#linkDirectorio"], ["hide"]);
	} else if (compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT")){
		removeClasses(["#linkPaymentOrders", "#linkFailedOperations", "#linkBussinessTactics", "#linkPipeline", "#linkVencimientos", "#buttonPaymentOrders", "#buttonFailedOperations", "#buttonBussinessTactics", "#buttonPipeline", "#buttonExpirations","#linkPET","#buttonPET","#linkDirectorio"], ["hide"]);
	} else if (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI") || compareString(userType, "GerencialI")){
		removeClasses(["#linkFailedOperations","#linkBussinessTactics", "#linkPipeline","#buttonFailedOperations","#buttonBussinessTactics", "#buttonPipeline"], ["hide"]);
		addClasses(["#linkPaymentOrders", "#linkVencimientos", "#buttonPaymentOrders","#buttonExpirations","#linkPET","#buttonPET"], ["hide"]);
		setStyle(".wizard .nav-tabs > li", "width", "33%");
		assignContent(".pageWrapperPaymentOrders", "<h3 style='background: #f2f2f2; text-align: center; line-height: 25'>" + messageForTraders + "</h3>");
	} else{
		addClasses(["#linkPaymentOrders", "#linkFailedOperations", "#linkBussinessTactics", "#linkPipeline", "#linkVencimientos", "#instrucciones"], ["hide"]);
		assignContent("#bodyMainContainer", "<h3>" + messageForTradersConsultants + "</h3>");
		assignContent(".pageWrapperPaymentOrders", "<h3 style='background: #f2f2f2; text-align: center; line-height: 25'>" + messageForTraders + "</h3>");
		assignContent("#pet-container", "<h3 style='text-align: center; line-height:25'>" + messageForTraders + "</h3>");
		assignContent("#contact-container", "<h3 style='text-align: center; line-height:25'>" + messageForTraders + "</h3>");
		assignContent(".pageWrapperfailedOperations", "<h3 style='background: #f2f2f2; text-align: center; line-height: 25'>" + messageForTraders + "</h3>");
		assignContent(".pageWrapperBussinessTactics", "<h3 style='background: #f2f2f2; text-align: center; line-height: 25'>" + messageForTradersConsultants + "</h3>");
		assignContent(".pageWrapperPipeline", "<h3 style='background: #f2f2f2; text-align: center; line-height: 25'>" + messageForTradersConsultants + "</h3>");
	}
}

// Calculated IRR (Internal Rate of Return)
function calculateIRR(valuesArray){
	var min = 0.0;
	var max = 1.0;
	var counter = 0;

	do{
		guest = (min + max) / 2;
		NPV = 0;
		counter++;

		for (var j = 0; j < valuesArray.length; j++){
			NPV += valuesArray[j] / Math.pow((1 + guest), j);
		}

		if (NPV > 0){
			min = guest;
		} else {
			max = guest;
		}
	} while(Math.abs(NPV) > 0.000001 && counter <= 1000);

	if (counter >= 1000){
		alert("No fue posible calcular el campo R/R, el valor quedar? en 0 para luego ser modificado ");
		return 0;
	} else{
		return guest * 100;
	}

}

// Open XLSX & XLSM file
function openExcelFile(path, linkSelector){
	try{
		var Excel = new ActiveXObject("Excel.Application");
		Excel.Visible = true;
		Excel.Workbooks.Open(path);
	} catch(e){alert("Ocurri? un error al intentar abrir el manual (" + e.message + ")")}
}

// Reload Current Page
function reloadPage(){location.reload()}

/**********************************************************************************************************************************/
/*********************************************************** F I L E S ************************************************************/
/**********************************************************************************************************************************/
// Get content txt file
function getContentTxtFile(url, activexObject){
	var file = activexObject.OpenTextFile(url, 1, false, 0); // 1->Read, 8->Write||| false->Create file if no exist|||0->ASCII, 1->Unicode, 2->System Default
	var content = file.ReadAll().toLowerCase();

	file.Close();

	return content.toLowerCase();
}

// Get "Version.txt" Path
function getUrlVersionFile(){
	var urlVersionArr = (replaceAll((location.pathname).substring(1, location.pathname.length), "%20", " ")).split("/");
	var urlVersion = "";

	for (i = 0; i < (urlVersionArr.length - 2); i++){
		urlVersion = urlVersion + urlVersionArr[i] + "\\";
	}

	return urlVersion + "Version.txt";
}

// Get current Path
function getCurrentPath(){
	return replaceAll(replaceAll((location.pathname).substring(1, (location.pathname).length), "/", "\\"), "%20", " ");
}

/**********************************************************************************************************************************/
/********************************************************* P L U G I N S **********************************************************/
/**********************************************************************************************************************************/
// Show plugin "Loading Overlay"
function showLoadingOverlay(){
	$.LoadingOverlay("show");
}

// Hide plugin "Loading Overlay"
function hideLoadingOverlay(){
	setTimeout(function(){
		$.LoadingOverlay("hide");
	}, 700);
}

// Add values to a editable select
function loadEditableSelect(selector, itemsSelect){
	$(selector).html(itemsSelect);
}

// Create and show a editable select
function instanceEditableSelect(selector){
	$(selector).editableSelect();
}

// Destroy a editable select
function destroyEditableSelect(selector){
	$(selector).editableSelect("destroy");
}

// Clear a editable select
function clearEditableSelect(selector){
	$(selector).editableSelect("clear");
}

// Clear multiples editable selects
function clearMultiplesEditableSelects(selectorsArray){
	selectorsArray.forEach(function(a){$(a).editableSelect("clear")});
}

// Remove an option editable select
function removeOptionEditableSelect(selector, index){
	$(selector).editableSelect('remove', index);
}

// Remove multiples options editable select
function removeMultiplesOptionsEditableSelect(selector, indexArray){
	for (i = 0; i < indexArray.length; i++){
		$(selector).editableSelect('remove', indexArray[i]);
	}
}

// Add an option editable select
function addOptionEditableSelect(selector, text){
	$(selector).editableSelect('add', text);
}

// Load multiples editable selects
function loadMultiplesEditableSelects(selectorsArray, itemsArray){
	for (i = 0; i < selectorsArray.length; i++){
		loadEditableSelect(selectorsArray[i], itemsArray[i]);
	}
}

// Instance multiples editables selects
function intanceMultiplesEditableSelects(selectorsArray){
	for (i = 0; i < selectorsArray.length; i++){
		instanceEditableSelect(selectorsArray[i]);
	}
}

// Destroy multiples editables selects
function destroyMultiplesEditableSelects(selectorsArray){
	for (i = 0; i < selectorsArray.length; i++){
		destroyEditableSelect(selectorsArray[i]);
	}
}

// Build table
function buildTable(headers, contentTable, selector){
	var thead = "<thead id='thead'><tr>";
	var tbody = contentTable;

	for(i = 0; i < headers.length; i++){
		thead = thead + "<th>" + headers[i] + "</th>";
	}

	thead = thead + "</tr></thead>";

	$(selector).html("");
	$(selector).append(thead);
	$(selector).append(tbody);
}

// Create and instance table
function instanceTable(selector){
	// $(selector + ' tfoot th').each(function (){$(this).html('<input type="text" placeholder="Buscar ' + $(selector + ' thead th').eq($(this).index()).text() + '" />')});
	$(selector + ' tfoot td').each(function (){$(this).html('<input class="secondFilter" type="text" placeholder="Buscar"/>')});
	$(".footerFilter tr td:nth-child(24)").html("<input class=\"secondFilterFullSize\" type=\"text\" placeholder=\"Buscar\">");
	$(".footerFilter tr td:nth-child(3)").html("<input class=\"secondFilterFullSize\" type=\"text\" placeholder=\"Buscar\">");

	var myDatatable = $(selector).DataTable({
		"lengthMenu": [[7, 15, 30, -1], [7, 15, 30, "Todos"]],
		aaSorting: [[1, 'desc']],//,
		// fixedHeader: {
			// header: true,
			// headerOffset: $('#thead').outerHeight()
        // },
		 //scrollY: 250,
		 //fixedHeader: true,
		// scrollY: 450
		// "iCookieDuration": 60*60,// 1 day (in seconds),
		// "bStateSave": true
	});

	myDatatable.columns().eq(0).each(function (index){
		$('input', myDatatable.column(index).footer()).on('keyup change focusout', function (){
			myDatatable.column(index).search(this.value).draw();
			validateSecondFilter($(this));
		});
	});
}

// Destroy table
function destroyTable(selector){
	$(selector).dataTable().fnDestroy();
	$(selector).html("");
}

// Destroy & Instance Table
function updateTable(selector, headersArray, opportunities){
	destroyTable(selector);
	buildTable(headersArray, opportunities, selector);
	instanceTable(selector);
}

// Instance DatePicker
function instanceDatePicker(selector){
	$(selector).datepicker({
		dateFormat : 'dd/mm/yy',
		beforeShowDay: $.datepicker.noWeekends,
		prevText: 'Anterior',
		nextText: 'Siguiente',
		onSelect: function(dateText, inst){showFormStatus(validateDateInput($("#estimatedDate").val() + ""), 8, "#errorEstimatedDate", "#estimatedDate", "#estimatedDateLabel", "#insertButton", "#editButton")},
		currentText: 'Hoy',
		monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
		monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
		dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi?rcoles', 'Jueves', 'Viernes', 'S?bado'],
		dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mi?;', 'Juv', 'Vie', 'S?b'],
		dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'S?'],
		minDate: '-d',
		beforeShow: function(input, inst) {
			inst.dpDiv.css({"z-index":100});
		}
	});
}

// Put ToolTip
function loadToolTip(selector, withOptions, text, position){
	if (withOptions){
		$(selector).tooltip({
			placement: position,
			title: text
		});
	} else{
		$(selector).tooltip();
	}
}
function getGroupCoordinador(){
	var connection = new ActiveXObject("ADODB.Connection");
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var stringConnection = stringConnections.strConexionDataMart;
	try{
		var query= replaceAll(queries.queryGetGrupoCoordinador, "USUARIO",users.currentUser.toUpperCase());
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		while (recordSet.EOF == false){
				grupoCoordinador.push("'"+recordSet(0)+"'");
				recordSet.MoveNext();
		}
		recordSet.close();
		connection.Close();
	}catch(e){
		alert(e.message)

	}
}

function getGraphConfiguration(values, titleGraph){
	return {
		type: 'bar',
		data: {
			labels: [(new Date()).getFullYear(), (new Date()).getFullYear() - 1, (new Date()).getFullYear() - 2],
			datasets: [{
				data: values,
				backgroundColor: [
					"rgba(54, 162, 235, 0.2)",
					"rgba(255, 99, 132, 0.2)",
					"rgba(75, 192, 192, 0.2)"
				],
				borderColor: [
					"rgba(54, 162, 235, 1)",
					"rgba(255, 99, 132, 1)",
					"rgba(75, 192, 192, 1)"
				],
				borderWidth: 1
			}]
		},
		options: {
			maintainAspectRatio: false,
			responsive:true,
			scales: {
				xAxes: [{
					gridLines: {
						color: "rgba(0, 0, 0, 0)",
					}
				}],
				yAxes: [{
					ticks: {
						beginAtZero:true,
					},
					gridLines: {
						color: "rgba(0, 0, 0, 0)",
					}
				}]
			},
			title: {
				display: true,
				text: titleGraph,
				position:'top',
				padding:17
			},
			legend: {
				display: false
			},
			label: {
				display: false
			},
			tooltips: {
				enabled: false
			},
			hover: {
				animationDuration: 0
			},
			animation: {
				duration: 5,
				onComplete: function () {
					var chartInstance = this.chart,

					ctx = chartInstance.ctx;
					ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
					ctx.textAlign = 'center';
					ctx.textBaseline = 'bottom';

					this.data.datasets.forEach(function (dataset, i) {
						var meta = chartInstance.controller.getDatasetMeta(i);

						meta.data.forEach(function (bar, index) {
							var data = dataset.data[index];

							ctx.fillText(data, bar._model.x, bar._model.y - 3);
						})
					})
				}
			}
		}
	}
}
