function getCurrentArea(user){
	try{
		var connection = new ActiveXObject("ADODB.Connection");
		var recordSet = new ActiveXObject("ADODB.Recordset");
		var stringConnection = stringConnections.strConexionDataMart;
		var query = replaceAll(queries.queryGetArea, "USUARIOTRADER",user );
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		areaUsuario=recordSet(0).value;
		recordSet.Close();
		connection.Close();
	}catch(e){
		alert("Ocurri� un error al verificar el area del usuario actual"); alert(e.message)
	}
};
// Get Traders/Consultants mail and name
function getTradersConsultantsNameAndMail(connection, recordSet, query, stringConnection, namesArrayUpper, mailsArrayUpper, namesArrayNormal, mailsArrayNormal){
	connection.Open(stringConnection);
	
	try{
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			namesArrayUpper.push((recordSet(0).Value).toUpperCase());
			mailsArrayUpper.push((recordSet(1).Value).toUpperCase());
			namesArrayNormal.push(recordSet(0).Value);
			mailsArrayNormal.push(recordSet(1).Value);
			
			recordSet.MoveNext();
		}

		recordSet.Close();
	} catch(e){alert("Ocurri� un error al verificar el usuario actual"); alert(e.message)}
	
	connection.Close();
}

// Mejora la funci�n anterior, actualmente solo uso en PET
function getUserInformation(connection, recordSet, query, stringConnection, array){
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			array.push({mail:(recordSet(0).Value).toUpperCase(), name:recordSet(1).Value});
			recordSet.MoveNext();
		}
	} catch(e){
		alert("Ocurri� un error al verificar el usuario actual");
		alert(e.message)
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

// Get User Rol
function getUserType(connection, recordSet, query, stringConnection){
	var rol = "";
	
	query = replaceAll(query, "rUsuario", users.currentUser);
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		rol = recordSet(0) + "";
	} catch(e){	
		// alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}
	
	return rol;
}

/***********************************************************
************************************************************
************************************************************
***********************************************************/

// Get User
function getUser(){
	var net = new ActiveXObject("WScript.Network");
	var connection = new ActiveXObject("ADODB.Connection");
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var stringConnection = stringConnections.strConexionDataMart;
	var query = replaceAll(queries.queryGetRol, "rUsuario", getCurrentUser(net));
	var currentUser = getCurrentUser(net);
	var user = "";
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		user = compareString(recordSet(0) + "", "Administrador") ? prompt("�Bienvenido Administrador, ingrese el usuario de red que desea simular", currentUser) : currentUser;
		development.developmentMode = compareString(user, currentUser) ? development.developmentMode : true;
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}
	
	return user;
}

/***********************************************************
************************************************************
************************************************************
***********************************************************/

// Insert log when user open module
function insertLog(connection, stringLog){
	if (!development.developmentMode){
		var currentDate = getDate(0, false);
		var currentTime = getTime(true);
		var dateFormated = currentDate.split("/")[2] + "-" + currentDate.split("/")[1] + "-" + currentDate.split("/")[0];

		try{
			connection.Open(stringConnections.strConexionLogs);
			var query = queries.consultaInsertarLog;
			
			query = replaceAll(query, "usuarioActual", users.currentUser);
			query = replaceAll(query, "fechaCompleta", dateFormated + " " + currentTime);
			query = replaceAll(query, "mensajeLog", stringLog+" "+(new ActiveXObject('WScript.Network')).computerName);
			connection.Execute(query);
		} catch(e){
			alert(e.message)
		} finally{
			connection.Close();
		}
	}
}

// Validate if exist in BD
function existInBD(connection, recordSet, query, stringConnection){
	var exist = false;
	
	connection.Open(stringConnection);
	try{
		recordSet.Open(query, connection);
	
		while (recordSet.EOF == false){
			exist = true;
			recordSet.MoveNext();
		}
		
		recordSet.Close();
	} catch(e){alert("Error validando existencia en base de datos."); alert(e.message);}
	
	connection.Close();
	
	return exist;
}

// Insert into DB
function insert(query, stringConnection, connection){
	var execute = false;
	
	try{
		connection.Open(stringConnection);
		connection.Execute(query);
		execute = true;
	} catch(e){
		alert(e.message);
		execute = false;
	} finally{
		connection.Close();
	}
	
	return execute;
}

// Delete into DB
function deleteDB(query, stringConnection, connection){
	var execute = false;
	
	try{
		connection.Open(stringConnection);
		connection.Execute(query);
		execute = true;
	} catch(e){
		alert(e.message);
		execute = false;
	} finally{
		connection.Close();
	}
	
	return execute;
}

// Update in DB
function update(query, stringConnection, connection, command){
	var successful = false;

	try{
		connection.Open(stringConnection);
		command.ActiveConnection = connection;
		command.CommandText = query;
		command.Execute();
		successful = true;
	} catch(e){
		successful = false;
	} finally{
		connection.Close()
	}
	
	return successful;
}


// Read Datamart DB
function readDatamart(query, stringConnection, connection, recordSet){
	var dataArr = [];
	var dataFound = false;
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			dataFound = true;
			dataArr.push(recordSet(0) + "");
			recordSet.MoveNext();
		}
		
		if (!dataFound) dataArr.push("Sin resultados");
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}
	
	return dataArr;
}

// Get users to show me
function getUsersToShowMe(query, stringConnection, connection, recordSet){
	connection.Open(stringConnection);
	recordSet.Open(query, connection);
	
	var users = "";
	var existUsers = false;
	
	while (recordSet.EOF == false){
		existUsers = true;
		users = users + "'" + recordSet(0).Value + "',";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	connection.Close();
	
	return existUsers ? " AND UsuarioSubio IN(" + users.substring(0, users.length - 1) + ")" : "";
}

// Get users to show me
function getUsersToShowMeCurrentGeography(query, stringConnection, connection, recordSet){
	connection.Open(stringConnection);
	recordSet.Open(query, connection);
	
	var users = "";
	var existUsers = false;
	var criterion = compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") ? "Geografia.Trader" : compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI") ? "Geografia.Consultor" : "";
	
	while (recordSet.EOF == false){
		existUsers = true;
		users = users + "'" + recordSet(0).Value + "',";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	connection.Close();
	
	return existUsers ? " AND " + criterion + " IN(" + users.substring(0, users.length - 1) + ")" : "";
}