function actualizar(activexObject){
	if (development.developmentMode){return;}
	try{
		var rutaActual = obtenerRutaActual();
		var rutaArchivoVersion = obtenerRuta(rutaActual, "Version.txt");
		var miVersion = leerArchivoTxt(rutaArchivoVersion, activexObject);
		var ultimaVersion = leerArchivoTxt(files.rutaArchivoUltimaVersion, activexObject);
		
		$('#version').html('V' + ultimaVersion);

		if (miVersion.localeCompare(ultimaVersion) != 0){
			$("#contenidoModalInformacion").empty();
			$('#tituloNotificacion').html('Actualizando...');
			$('#cuerpoNotificacion').html('Actualizando TradingTools, espere.<br><b style="color: #337ab7; font-size: 18px">No cierre</b> la herramienta hasta que la actualizaci�n se efect�e completamente.');
			
			alert("La herramienta se esta actualizando...No minimice ni cambie de ventana hasta que el proceso termine en su totalidad.");

			var rutaCarpetaJsDesactualizada = obtenerRuta(rutaActual, "js");
			var rutaCarpetaImgDesactualizada = obtenerRuta(rutaActual, "img");
			var rutaCarpetaIconosDesactualizada = obtenerRuta(rutaActual, "font-awesome");
			var rutaCarpetaCssDesactualizada = obtenerRuta(rutaActual, "css");
			var rutaCarpetaLibsDesactualizada = obtenerRuta(rutaActual, "libs");
			var rutaCarpetaHtmlDesactualizada = obtenerRuta(rutaActual, "html");
			var rutaCarpetaOtrosDesactualizada = obtenerRuta(rutaActual, "otros");
			var rutaDestino = obtenerRuta(rutaActual, "");

			// Eliminar archivo versi�n actual
			eliminarArchivo(rutaArchivoVersion, activexObject);
			// Crea archivo de versi�n y escribe la actual
			escribirEnArchivoTxt(rutaArchivoVersion, ultimaVersion, activexObject);
			// Elimina las carpetas de Orpas desactualizadas
			eliminarCarpeta(rutaCarpetaJsDesactualizada, activexObject);
			eliminarCarpeta(rutaCarpetaImgDesactualizada, activexObject);
			eliminarCarpeta(rutaCarpetaIconosDesactualizada, activexObject);
			eliminarCarpeta(rutaCarpetaCssDesactualizada, activexObject);
			eliminarCarpeta(rutaCarpetaLibsDesactualizada, activexObject);
			eliminarCarpeta(rutaCarpetaHtmlDesactualizada, activexObject);
			eliminarCarpeta(rutaCarpetaOtrosDesactualizada, activexObject);
			// Pega archivo Orpas.html
			copiarArchivo(files.rutaArchivoOrpasHtmlActualizado, rutaDestino, activexObject);
			// Pega las carpetas de Orpas actualizadas
			copiarCarpeta(files.rutaCarpetaJsActualizada, rutaDestino, activexObject);
			copiarCarpeta(files.rutaCarpetaImgActualizada, rutaDestino, activexObject);
			copiarCarpeta(files.rutaCarpetaIconosActualizada, rutaDestino, activexObject);
			copiarCarpeta(files.rutaCarpetaCssActualizada, rutaDestino, activexObject);
			copiarCarpeta(files.rutaCarpetaLibsActualizada, rutaDestino, activexObject);
			copiarCarpeta(files.rutaCarpetaHtmlActualizada, rutaDestino, activexObject);
			copiarCarpeta(files.rutaCarpetaOtrosActualizada, rutaDestino, activexObject);
			
			$("#tituloModalInformacion").html("Actualizaci�n exitosa");
			$("#contenidoModalInformacion").html("La actualizaci�n a terminado con exito, para que los nuevos cambios se efectuen <b>cierre completamente</b> la herramienta e <b>ingrese de nuevo</b>");
			$('#modalInformacion').modal('show');
		} else{
			$('#tituloNotificacion').html('<b>�Herramienta Actualizada!</b>');
			$('#cuerpoNotificacion').html('TradingTools se encuentra actualizada en su �ltima versi�n ' + ultimaVersion + '. <br> Direccionando hacia su p�gina de inter�s, por favor espere.');
		}
	} catch(e){
		alert("Ocurri� un error al verificar la versi�n de la herramienta.");
	}

	activexObject = null;
}

function obtenerRutaActual(){
	var rutaActual = location.pathname;
	
	rutaActual = rutaActual.substring(1, rutaActual.length);
	rutaActual = reemplazarTodos(rutaActual, "/", "\\");
	rutaActual = reemplazarTodos(rutaActual, "%20", " ");
	
	return rutaActual;
}

function obtenerRuta(rutaPadre, nombreHijo){
	var rutaActualArr = rutaPadre.split("\\");
	var rutaArchivo = "";

	for (i = 0; i < (rutaActualArr.length - 1); i++){
		rutaArchivo = rutaArchivo + rutaActualArr[i] + "\\";
	}

	rutaArchivo = rutaArchivo + nombreHijo;
	
	return rutaArchivo;
}

function leerArchivoTxt(rutaArchivoVersion, activexObject){
	var archivoVersion = activexObject.OpenTextFile(rutaArchivoVersion, 1, false, 0); // 1->lectura, 8-> escritura||| false->crear archivo si no existe|||0->ASCII, 1->Unicode, 2->System Default
	var miVersion = archivoVersion.ReadAll();
	
	archivoVersion.Close();
	
	miVersion = miVersion.toLowerCase();
	
	return miVersion;
}

function eliminarArchivo(rutaArchivo, activexObject){
	activexObject.DeleteFile(rutaArchivo, true);
}

function escribirEnArchivoTxt(rutaArchivo, textoaEscribir, activexObject){
	var archivoNuevo = crearArchivoTxt(rutaArchivo, activexObject);
	
	archivoNuevo.write(textoaEscribir);
	archivoNuevo.Close();
}

function crearArchivoTxt(rutaArchivo, activexObject){
	var archivoNuevo = activexObject.CreateTextFile(rutaArchivo, true);
	
	return archivoNuevo;
}

function eliminarCarpeta(rutaCarpeta, activexObject){
	activexObject.DeleteFolder(rutaCarpeta, true);
}

function copiarCarpeta(rutaOrigen, rutaDestino, activexObject){
	activexObject.CopyFolder(rutaOrigen, rutaDestino, true);
}

function copiarArchivo(rutaOrigen, rutaDestino, activexObject){
	var archivoaCopiar = activexObject.GetFile(rutaOrigen);
	
	rutaDestino = rutaDestino + "\\";

	archivoaCopiar.copy(rutaDestino, true);
}

function reemplazarTodos(texto, textoaBuscar, textoaReemplazar){
	return texto.replace(new RegExp(textoaBuscar, "g"), textoaReemplazar);
}