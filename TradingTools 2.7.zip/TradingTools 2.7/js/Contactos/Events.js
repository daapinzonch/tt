// Add events
function addAllEvents(){

	//Fill Inputs for Contact Form
	generateDate($("#day"), $("#month"), $("#year"));
	adressInformation($("#countries"), $("#cities"), $("#states"), $("#nomenclature"));
	$("#year").on("click", function(){ $("#open").text('Rango de Edad');});
	resetRating(0);
	getEmails();
	rating();

	$('#countries').on('change', function() {
		$('#states').empty().append('<option disabled selected> Departamento </option>');
		$('#cities').empty().append('<option disabled selected> Ciudad </option>');
		adressInformation('', $("#states"), $("#cities"), '');
	});

	$('#states').on('change', function() {
		$('#cities').empty().append('<option disabled selected> Ciudad </option>');
		adressInformation('','', $("#cities"), '');
	});

	//Get Email for row 
	$('#contact-table').on('change', 'td .styled', function () {
	 	if( $(this).prop("checked") == true ){
	 			var value = $(this).parent().parent().parent().children().eq(5).text().trim();
				mails.push(value);
				mails = mails.filter(function(e) { return e.trim() != ''}); 
		}else if($(this).prop("checked") == false){
				value = $(this).parent().parent().parent().children().eq(5).text().trim();
				mails = mails.filter(function(e) { return e != value }); 
		}
	});

	//Create a new Contact
	$('#new-contact').on('click', function (){
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea agregar un nuevo contacto?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){
			state = 1;
			removeClass("#form-header-company","text-center");
			$("#header-customer").text("");
			$("#header-customer").append("<span class='text-center'>Cliente</span>");
			addClass(".arrow-down","hide");
			removeClass(".arrow-down","collapsed");
			$(".arrow-down").attr("aria-expanded","false");
			removeClass("#customer","in");
			$("#customer").attr("aria-expanded","false");
			removeClass("#form-body-company","hide");
			addClass("#edit-header", " hide");
			removeClass("#new-header", "hide");
			addClass("#form-contact","hide");
			removeClass("#company-button","hide");
			$("#edit-contact").attr('id','contact-form');
			resetForm("#company-form");
			resetForm("#contact-form");
			resetRating(0);
			$("#open").text('A�o - Rango de Edad');
			$('#form-modal').modal({backdrop: 'static'});
			$("#form-modal").modal("show");
		}});
	});


	$('#group').on('click', function (){
		character = "group";
		destroyTableContacts('#contact-table', character);
		addClass("#group","hide");
		removeClass("#user","hide");
		getEmails();
	});

	$('#user').on('click', function (){
		character = "user";
		destroyTableContacts("#contact-table", character);
		addClass("#user","hide");
		removeClass("#group","hide");
		getEmails();
	});

	//Download Excel
	$('#download_contacts').on('click', function (){
		var network = new ActiveXObject('WScript.Network');
		var File = new ActiveXObject("Scripting.FileSystemObject");
		var serverName = network.computerName;
		var rutaActual = replaceAll(getCurrentPath(),'Contactos.html',"Contactos_" + users.currentUser + ".csv")
		
		
		showBootstrapDialog("Confirmaci�n", "Tenga en cuenta que la cantidad de registros a exportar depende del filtro aplicado en la tabla, �Desea continuar?", "DANGER", "CONFIRM", "NORMAL", function(result){if(result){
			downloadExcel("#contact-table", "Contactos_" + users.currentUser, rutaActual);				
			try {
				if (compareString(serverName, "ARIESTES02") || compareString(serverName, "ARIESTES01") || compareString(serverName, "WIN2012P02.banbta.net") || compareString(serverName, "WIN2012P02") || compareString(serverName, "win2012p02")){
					var cdoMsg = new ActiveXObject("CDO.Message");
					cdoMsg.From = users.currentUser + "@bancodebogota.com.co";
					cdoMsg.To = users.currentUser + "@bancodebogota.com.co" + ";" + MainTrader +"bancodebogota.com.co";
					cdoMsg.Subject = "Informaci�n Contactos" ;
					cdoMsg.HTMLBody = "<span style='font-family: arial'>El trader: " + (users.currentUser).toUpperCase() +" descargo informaci�n del modulo contactos " + MainTrader +"</span><br>"; //+ $('#contact-table').prop('outerHTML');
					cdoMsg.AddAttachment(rutaActual);
					var namespace = "http://schemas.microsoft.com/cdo/configuration/";
					cdoMsg.Configuration.Fields.Item(namespace + "sendusing") = 2;
					cdoMsg.Configuration.Fields.Item(namespace + "smtpserver") = "outlook.bancodebogota.net";
					cdoMsg.Configuration.Fields.Item(namespace + "smtpserverport") = 25;
					cdoMsg.Configuration.Fields.Item(namespace + "sendusername") = "Internacional@bancodebogota.com.co";
					cdoMsg.Configuration.Fields.Update();
					cdoMsg.Send();
					showBootstrapDialog("Informaci�n", "El archivo fue enviado a su correo" ,"PRIMARY", "ALERT", "NORMAL" );	
				} else{
					var to = MainTrader + "@bancodebogota.com.co";
					// Crea y abre una instancia de Outlook
					var outlook = new ActiveXObject('Outlook.Application');
					// Abre una nueva ventana de correo
					var email = outlook.CreateItem(0);
					// Agrega Destinatarios
					email.Recipients.Add(to);
					// Asunto
					email.Subject = "Informaci�n Modulo Contactos";
					// Coloca contenido en el correo
					email.HTMLBody = "<span style='font-family: arial'>Buen d�a,<br>El trader: <b>" + (users.currentUser).toUpperCase() +"</b> descarg� la informaci�n adjunta desde el m�dulo de contactos<br><b>**Esta alerta fue generada autom�ticamente por la herramienta</b></span>"; //+ $('#contact-table').prop('outerHTML');
					//Adjunta el archivo de excel con contactos
					email.Attachments.Add(rutaActual);
					// Muestra el contenido del correo
					//Envia el correo
					email.Send();
					
					downloadInformation("#contact-table", "Contactos", "Contactos_" + users.currentUser);
				}
			}
			catch(e) {
				showBootstrapDialog("Informaci�n", "Error descargando el archivo" ,"DANGER", "ALERT", "NORMAL");	
			}
			
			//Elimina el archivo creado
			File.FileExists(rutaActual) == true ? File.DeleteFile(rutaActual) : "";
		}});
	});

	//Mail Contact
	$('#mail_contacts').on('click', function (){ 
		if (mails.length > 0) {
			var network = new ActiveXObject('WScript.Network');
			var serverName = network.computerName;
			try {
				if (compareString(serverName, "ARIESTES02") || compareString(serverName, "ARIESTES01") || compareString(serverName, "WIN2012P02.banbta.net") || compareString(serverName, "WIN2012P02") || compareString(serverName, "win2012p02")){
					var cdoMsg = new ActiveXObject("CDO.Message");
					cdoMsg.From = users.currentUser + "@bancodebogota.com.co";
					cdoMsg.To = users.currentUser + "@bancodebogota.com.co";
					cdoMsg.Subject = "Contactos" ;
					cdoMsg.HTMLBody = "<span style='font-family: arial'> Los correos son: "+ replaceAll(mails.toString(),',',';') +"</span><br>"; //+ $('#contact-table').prop('outerHTML');
					var namespace = "http://schemas.microsoft.com/cdo/configuration/";
					cdoMsg.Configuration.Fields.Item(namespace + "sendusing") = 2;
					cdoMsg.Configuration.Fields.Item(namespace + "smtpserver") = "outlook.bancodebogota.net";
					cdoMsg.Configuration.Fields.Item(namespace + "smtpserverport") = 25;
					cdoMsg.Configuration.Fields.Item(namespace + "sendusername") = "Internacional@bancodebogota.com.co";
					cdoMsg.Configuration.Fields.Update();
					cdoMsg.Send();
					showBootstrapDialog("Informaci�n", "La lista de correos fue env�ada a su correo" ,"PRIMARY", "ALERT", "NORMAL" );	
				} else{
					// Crea y abre una instancia de Outlook
					var outlook = new ActiveXObject('Outlook.Application');
					// Abre una nueva ventana de correo
					var email = outlook.CreateItem(0);
					// Agrega Destinatarios
					mails.forEach(function(e){email.Recipients.Add(e)});
					// Asunto
					email.Subject = "Contactos";
					// Coloca contenido en el correo
					email.HTMLBody = "";
					// Muestra el contenido del correo
					email.Display();
				}
			}
			catch(e) {
					alert(e.message);
				}

		}else{
			showBootstrapDialog("Informaci�n", "Por favor seleccione un correo" ,"DANGER", "ALERT", "NORMAL" );
		}
	});

	$("#mail-modal").on('hidden.bs.modal', function (){
		$("#" + replaceAll($(this).attr('id'), "modal", "table")).DataTable().destroy();
	});


	//Delete Contact
	$("#contact-table").on('click', '#deleteContact', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var id = $(this).parent().parent().children().eq(0).children().attr('value');

		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea eliminar este contacto?", "DANGER", "CONFIRM", "NORMAL", function(result){if(result){ 

			var query = replaceAll(replaceAll(queries.queryDeleteContact,'R_NIT',nit),'R_ID',id);
			deleteContact(connection, command, stringConnections.strConexionContactos, query, id);
			destroyTableContacts('#contact-table', character);
			getEmails();
		}});

	});

	//Edit Contact
	$("#contact-table").on('click', '#editContact', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var id = $(this).parent().parent().children().eq(0).children().attr('value');
		var user = $(this).parent().parent().children().eq(7).text().trim();
		finals = [];
		// Dario
		var customer = getCustomer(connection, recordSet, stringConnections.strConexionDataMart, replaceAll(queries.queryGetCustomer,'R_NIT', nit));
		if(compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) {
			$(".consultor").addClass("hide");
			$(".trader").removeClass("hide");		
		}
		else if(compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")){
			$(".trader").addClass("hide");
			$(".consultor").removeClass("hide");
		}else{
			$(".trader").removeClass("hide");	
			$(".consultor").removeClass("hide");	
		}

		addClass("#form-header-company","text-center");
		$("#header-customer").text("");
		$("#header-customer").append("<span class='text-center'>Cliente</span>");
		addClass("#form-body-company, .arrow-down, #new-header","hide");
		removeClass(".arrow-down","collapsed");
		removeClass("#customer","in");
		removeClass("#form-contact, #edit-header, .arrow-down","hide");
		$(".arrow-down, #customer").attr("aria-expanded","false");
		$("#customer-name, #customer-nit, #group-name, #group-nit, #trader, #unidad", "#consultor").text("");
		
		//Customer Information
		$("#customer-name").text(customer[0]);
		$("#customer-nit").text(nit);
		$("#group-name").text(customer[5]);
		$("#group-nit").text(customer[4]);		
		$("#unidad").text(customer[3]);
		$("#consultor").text(customer[2]);
		$("#trader").text(customer[1]);
		$("#id-contact").text(id);
		resetForm("#contact-form");
		resetRating(0);

		finals = getContactInfo(connection, recordSet, stringConnections.strConexionContactos, replaceAll(replaceAll(queries.queryGetInfoContact,'R_NIT',nit),'R_ID',id));
		if(!finals.length == 0) {

			//Nit
			$("#nit").val(finals[0]);

			//Principal
			$("#"+ finals[2]).prop("checked", true);

			//Opera
			$('[value="'+ finals[3].split(',')[0] +'"]').prop("checked", true);
			$('[value="'+ finals[3].split(',')[1] +'"]').prop("checked", true);
			$('[value="'+ finals[3].split(',')[2] +'"]').prop("checked", true);
			$('[value="'+ finals[3].split(',')[3] +'"]').prop("checked", true);
			$('[value="'+ finals[3].split(',')[4] +'"]').prop("checked", true);
			finals[3] = StringCommas(finals[3]);


			//Identificacion
			$("#tID").val(finals[4].split(',')[0]);
			$("#ID").val(finals[4].split(',')[1]);
			
			//Nombres
			$("#name").val((finals[5].split(',')[0]).trim());
			$("#lastname").val((finals[5].split(',')[1]).trim());

			//Cargo
			$("#position").val(finals[6].split(',')[0]);
			$("#timePosition").val(finals[6].split(',')[1]);
			$("#relation").val(finals[6].split(',')[2]);

			//Genero
			$("#" + finals[7]).prop('checked',true);

			//Cumplea�os
			$("#day").val(finals[8].split(',')[0]);
			$("#month").val(finals[8].split(',')[1]);
			$("#year").val(finals[8].split(',')[2]);
			finals[8] == ",,," ? ",," : finals[8];

			//Pais
			$("#countries").empty().append('<option disabled selected> Pais </option>');
			$('#states').empty().append('<option disabled selected> Departamento </option>');
			$('#cities').empty().append('<option disabled selected> Ciudad </option>');

			adressInformation($("#countries"),'','','') ;
			$("#countries").val(finals[9].split(',')[0]);
			adressInformation('', $("#states"),'','');
			$("#states").val(finals[9].split(',')[1]);
			adressInformation('','', $("#cities"),'') ;
			$("#cities").val(finals[9].split(',')[2]);

			//Direccion
			$("#nomenclature").val(finals[10].split(',')[0]);
			$("#address").val(finals[10].split(',')[1]);
			$("#aNumber1").val(finals[10].split(',')[2]);
			$("#aNumber2").val(finals[10].split(',')[3]);
			$("#datosOpci").val(finals[10].split(',')[4]);

			//Emails
			$("#email").val((finals[11].split(",")[0]).trim());
			for(var i=0; i < finals[11].split(",").length-1; i ++){
				nEmail = nEmail + 1;
				$("#email-container").append("<div class='form-group col-md-12 email"+ nEmail +"'><div class='input-group'><div class='input-group-addon'><i class='fa fa-envelope'></i></div><input type='email' class='form-control emails' id='email"+ nEmail +"' value='"+ finals[11].split(",")[nEmail].trim() +"' placeholder='Email "+ nEmail +"'></div></div>");
			}

			//Phones
			$("#phone").val(finals[12].split(",")[0].trim());
			for(var i=0; i < finals[12].split(",").length-1; i ++){
				nPhone = nPhone + 1;
				$("#phone-container").append("<div class='form-group col-md-12 phone"+ nPhone +"'><input type='tel' class='form-control phones'  id='phone"+ nPhone +"' value='"+ finals[12].split(",")[nPhone].trim() +"'></div>");
				formatPhone($("#phone"+ nPhone), 'PHONE');
			}

			//Mobiles
			$("#mobile").val(finals[13].split(",")[0]);
			for(var i=0; i < finals[13].split(",").length-1; i ++){
				nMobile = nMobile + 1;
				$("#mobile-container").append("<div class='form-group col-md-12 mobile"+ nMobile +"'><input type='tel' class='form-control mobiles'  id='mobile"+ nMobile +"' value='"+ finals[13].split(",")[nMobile] +"'></div>");
				formatPhone($("#mobile"+ nMobile), 'MOBILE');
			}

			//Hobbies
			odd = [0, 2, 4, 6, 8];
			even = [1, 3, 5, 7, 9];

			if(finals[14].split(/[,:]/)[0] == ""){
				finals[14].split(/[,:]/)[0] = undefined
			}
			else{
				for(var i=0; i < (finals[14].split(/[,:]/).length)/2 ; i ++){
					nHobbie = nHobbie + 1;
					$("#hobbies-container").append("<div class='form-group col-sm-6 col-md-6 hobbie"+ nHobbie +"'> <select class='form-control hobbies' id='hobbie"+ nHobbie +"'> <option value='Musica'> Musica </option> <option value='Deportes'> Deportes </option> <option value='Comida'> Comida </option> <option value='Planes'> Planes </option> <option value='Otros'> Otros </option> </select></div>");
					$('#hobbie'+nHobbie).val(finals[14].split(/[,:]/)[odd[i]])
					$("#hobbies-container").append("<div class='form-group col-sm-6 col-md-6 hobbie"+ nHobbie +"'> <input type='text' class='form-control hobbies-text' value='"+ finals[14].split(/[,:]/)[even[i]] +"' placeholder='Tipo de Hobbie "+ nHobbie +"'></div>");
				}
			}
			//Observaciones
			$("#obser").val(finals[15]);
			
			resetRating(finals[16]);
			$('#form-modal').modal({backdrop: 'static'});
			$("#form-modal").modal("show");
			state = 2;
		}else{}

		requiredCheckbox([$("[value='Divisas']"), $('[value="Derivados"]'), $('[value="Titulos"]'), $('[value="Comex"]'), $('[value="Cartera / Pasivos"]')]);
	
	});


	$("#Add-Email").on('click', function(){
		addInputFormHTML("#email-container", "email", "El maximo de correos permitidos es 5", 4, nEmail);
	});

	$("#Remove-Email").on('click', function(){
		if(nEmail == 0){ nEmail = 0 } else { $(".email"+ nEmail + "").remove(); nEmail = nEmail - 1 }
	});

	$("#Add-Phone").on('click', function(){
		addInputFormHTML("#phone-container", "phone", "El maximo de telefonos permitidos es 3", 2, nPhone);
	});

	$("#Remove-Phone").on('click', function(){
		if(nPhone == 0){ nPhone = 0 } else { $(".phone"+ nPhone + "").remove(); nPhone = nPhone - 1 }
	});

	$("#Add-Mobile").on('click', function(){
		addInputFormHTML("#mobile-container", "mobile", "El maximo de celulares permitidos es 3", 2, nMobile);
	});

	$("#Remove-Mobile").on('click', function(){
		if(nMobile == 0){ nMobile = 0 } else { $(".mobile"+ nMobile + "").remove(); nMobile = nMobile - 1 }
	});

	$("#Add-Hobbie").on('click', function(){
		addInputFormHTML("#hobbies-container", "hobbie", "El maximo de hobbies permitidos es 5", 5, nHobbie);
	});

	$("#Remove-Hobbie").on('click', function(){
		if(nHobbie == 0){ nHobbie = 0 } else { $(".hobbie"+ nHobbie + "").remove(); nHobbie = nHobbie - 1 }
	});

	$('[value="Divisas"], [value="Derivados"], [value="Titulos"], [value="Comex"], [value="Cartera / Pasivos"]').on('click', function(){
		requiredCheckbox([$("[value='Divisas']"), $('[value="Derivados"]'), $('[value="Titulos"]'), $('[value="Comex"]'), $('[value="Cartera / Pasivos"]')]);
	});


	$('#company-form').submit(function(e) {
		var nit = $("#nit").val().trim();
		var customer = [];
		var user = "";

		customer = getCustomer(connection, recordSet, stringConnections.strConexionDataMart, replaceAll(queries.queryGetCustomer,'R_NIT', nit));
		if(compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) {
			user = customer[1];
			$(".consultor").addClass("hide");
			$(".trader").removeClass("hide");		
		}
		else if(compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")){
			user = customer[2];
			$(".trader").addClass("hide");
			$(".consultor").removeClass("hide");
		}else{
			$(".trader").removeClass("hide");
			$(".consultor").removeClass("hide");	
		}

		e.preventDefault();

		if(UserName != user	&& customer.length > 0 ){
			showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea agregar este cliente? Tenga en cuenta que no est� asignado a su unidad", "DANGER", "CONFIRM", "NORMAL", function(result){if(result){ 
				finals = [];
				addClass("#form-header-company","text-center");
				addClass("#form-body-company","hide");
				removeClass("#form-contact","hide");
				removeClass(".arrow-down","hide");
				$("#customer-name, #customer-nit, #group-name, #group-nit, #trader, #consultor, #unidad").text("");
				$("#customer-name").text(customer[0]);
				$("#customer-nit").text(nit);
				$("#group-name").text(customer[5]);
				$("#group-nit").text(customer[4]);		
				$("#unidad").text(customer[3]);
				$("#consultor").text(customer[2]);
				$("#trader").text(customer[1]);
				addClass("#info-customer","text-center");
				//$("#trader, #consultor").text(user);
			}});
		}
		else if(customer.length == 0){
			showBootstrapDialog("informaci�n", "Este cliente no est� registrado en la base de datos, por lo tanto no es posible crear un contacto", "DANGER", "ALERT", "NORMAL")
		}
		else{
			finals = [];
			addClass("#form-header-company","text-center");	    
		    addClass("#form-body-company","hide");
			removeClass("#form-contact","hide");
			removeClass(".arrow-down","hide");			
			$("#customer-name, #customer-nit, #group-name, #group-nit, #trader, #consultor, #unidad").text("");
			$("#customer-name").text(customer[0]);
			$("#customer-nit").text(nit);
			$("#group-name").text(customer[5]);
			$("#group-nit").text(customer[4]);
			$("#unidad").text(customer[3]);
			$("#consultor").text(customer[2]);
			$("#trader").text(customer[1]);
			addClass("#info-customer","text-center");
			//$("#trader, #consultor").text(user);
		}
	});


	$('#contact-form').submit(function(e) {
		var fields = ['R_NIT', 'R_CUSTOMER','R_MAIN','R_OPERATE','R_IDENTITY','R_NAME','R_JOB','R_GENDER','R_DATE','R_NATION','R_ADDRESS','R_MAIL','R_PHONE','R_MPHONE','R_HOBBIES','R_OBSER','R_PRIO'];
		values = {"inputs":{},"opera":[],"emails":[], "phones":[], "mobiles":[], "hobbies":{}};
		var submitValues = [];
		
		e.preventDefault(); //Para que no recargue la pagina

		$.each($("form").serializeArray(), function (e, i) {
			values.inputs[i.name] = i.value;
			values.inputs.principal = $('[name="principal"]:checked').attr('id');
			values.inputs.genero = $('[name="genero"]:checked').attr('id');
		});

		checkboxValues(["Divisas","Derivados","Titulos","Comex1","CarteraPasivos"], values.opera);
		addInputValues(".emails", values.emails);
		addInputValues(".phones", values.phones);
		addInputValues(".mobiles", values.mobiles);
		addInputValues(".hobbies", values.hobbies);

		$(".hobbies-text").each(function(index, element) {
			var a = JSON.parse(JSON.stringify(values.hobbies));
			var valuesd = Object.keys(a).map(function (key) { return a[key]; });
			values.hobbies[valuesd[index]] = this.value;
		});

		submitValues.push(values.inputs.nit == undefined ? "" : values.inputs.nit);
		submitValues.push($("#customer-name").text().trim());
		submitValues.push(values.inputs.principal);
		submitValues.push(StringCommas(values.opera.toString()));
		submitValues.push((values.inputs.tID == undefined ? "" : values.inputs.tID) + (values.inputs.ID == "" ? "" : "," + values.inputs.ID));
		submitValues.push((values.inputs.name.trim() + "," + values.inputs.lastname.trim()).toUpperCase());
		submitValues.push(((values.inputs.position == "" ? "," : values.inputs.position.toUpperCase() + ",") + (values.inputs.timePosition == undefined ? "," : values.inputs.timePosition + ",") + (values.inputs.relation == undefined ? "" : values.inputs.relation)).trim() == ',,' ? '' :  ((values.inputs.position == "" ? "," : values.inputs.position.toUpperCase() + ",") + (values.inputs.timePosition == undefined ? "," : values.inputs.timePosition + ",") + (values.inputs.relation == undefined ? "" : values.inputs.relation)).trim());
		submitValues.push(values.inputs.genero);
		submitValues.push((values.inputs.day == undefined ? "," : values.inputs.day + ",") + ( values.inputs.month == undefined ? "," : values.inputs.month + ",") + (values.inputs.year == undefined ? "" : values.inputs.year));
		submitValues.push( StringCommas((values.inputs.countries == undefined ? "" : values.inputs.countries + ",") + (values.inputs.cities == undefined ? "" : values.inputs.cities + ",") + (values.inputs.states == undefined ? "" : values.inputs.states)));
		submitValues.push( ((values.inputs.nomenclature == undefined ? "," : values.inputs.nomenclature + ",")  + (values.inputs.address.trim() == "" ? "," : values.inputs.address.trim() + ",") + (values.inputs.aNumber1.trim() == "" ? "," : values.inputs.aNumber1.trim() + ",") + ( values.inputs.aNumber2.trim() == "" ? "," : values.inputs.aNumber2.trim() + ",") + (values.inputs.datosOpci.trim() == "," ? "" : values.inputs.datosOpci.trim())) == ',,,,' ? '' : ((values.inputs.nomenclature == undefined ? "," : values.inputs.nomenclature.trim() + ",")  + (values.inputs.address.trim() == "" ? "," : values.inputs.address.trim() + ",") + (values.inputs.aNumber1.trim() == "" ? "," : values.inputs.aNumber1.trim() + ",") + ( values.inputs.aNumber2.trim() == "" ? "," : values.inputs.aNumber2.trim() + ",") + (values.inputs.datosOpci.trim() == "," ? "" : values.inputs.datosOpci.trim())) );
		submitValues.push(values.emails.toString().toLowerCase());
		submitValues.push(values.phones.toString());
		submitValues.push(values.mobiles.toString());
		submitValues.push(JSON.stringify(values.hobbies).replace(/[{}"]/g,'').trim());
		submitValues.push(values.inputs.obser.trim());
		submitValues.push(parseInt($("#selected_rating").val()));

		var query = replaceAllArray(queries.queryDuplicates,['R_NIT','R_NAME','R_GENDER','R_MAIL','R_PHONE'],[submitValues[0], submitValues[5], submitValues[7], submitValues[11], submitValues[12]]);
		var fieldsCheck = duplicateValues(connection, recordSet,stringConnections.strConexionContactos, query);


		if(state == 1 && fieldsCheck[1] == false){
			query =  replaceAllArray(queries.queryCreateContact,fields,submitValues);
			createContact(connection, stringConnections.strConexionContactos, command, query);
			destroyTableContacts('#contact-table', character);
			getEmails();
		}

		else if (state == 2 && arrayDiff(submitValues,finals).length > 0){
			var id = $("#id-contact").text();

			if(fieldsCheck[1] == true && fieldsCheck[0] == id){
				query = replaceAllArray(replaceAll(queries.queryEditContact,'R_DID',id),fields,submitValues)
				editContact(connection, command, stringConnections.strConexionContactos, query, id);		
				destroyTableContacts('#contact-table', character);
				getEmails();				
			}else if(fieldsCheck[1] == false ){
				query = replaceAllArray(replaceAll(queries.queryEditContact,'R_DID',id),fields,submitValues)
				editContact(connection, command, stringConnections.strConexionContactos, query, id);		
				destroyTableContacts('#contact-table', character);
				getEmails();	
			}
			else{ showBootstrapDialog("Informaci�n","Este contacto ya existe en la base de datos","DANGER","ALERT","NORMAL"); }

		}
		else if (state == 2 && arrayDiff(submitValues,finals).length == 0){  showBootstrapDialog("Informaci�n","No ha modificado ning�n campo del contacto, por ende no es posible guardarlo","DANGER","ALERT","NORMAL"); }
		else{ showBootstrapDialog("Informaci�n","Este contacto ya existe en la base de datos","DANGER","ALERT","NORMAL"); }

	});

	// Allow Only Numeric Values For All Numeric Inputs
	$("#nit, #ID").keydown(function (e){allowNumericValues(e)});
	$("#name, #lastname, #position, #text-hobbie").keydown(function (e){allowOnlyText(e)});
	$("#datosOpci, #obser, #aNumber1, #aNumber2, #address, #email").keydown(function (e){allowAlphaNumerics(e)});


	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});

	// Tooltips
	$('.has-tooltip').tooltip({
		selector: "[data-toggle=tooltip]",
		container: "body",
		trigger: "hover"
	});

}


