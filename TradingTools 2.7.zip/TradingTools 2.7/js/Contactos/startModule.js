//ActiveX DB Objects
var fileSystem = new ActiveXObject("Scripting.FileSystemObject");
var connection = new ActiveXObject("ADODB.Connection");
var command = new ActiveXObject("ADODB.Command");
var recordSet = new ActiveXObject("ADODB.Recordset");

// Other Variables
var usersToShowMe = "", MainTrader = "", UserName = "", userType = "";
var contactTable;
var character = "user";
var traders = [], mails = [], finals = [], table = [];
var values = {"inputs":{},"opera":[],"emails":[], "phones":[], "mobiles":[], "hobbies":{}};
var nEmail = 0; nPhone = 0; nMobile = 0; nHobbie = 0; state = 0;
var develop = false;
 
addClass(".loading-container", " hide");
removeClass(".tables-container", "hide");

$(document).ready(function (){

	// Put Version
	assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), fileSystem));
	
	// Get Traders mail and name
	getUserInformation(connection, recordSet, replaceAll(queries.queryGetUserInformation, "R_AREA", "Tesorer�a"), stringConnections.strConexionDataMart, traders);
	
	// Get My Rol
	userType = getUserType(connection, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
	
	//Ocultar panel de instrucciones
	showModules(userType);
	
	// Users to show Me
	if (compareString(userType, "GerencialT") || compareString(userType, "GerencialI")){
		usersToShowMe = getUsersToShowMe(replaceAll(queries.queryGetUsersByArea, "rUsuario", users.currentUser), stringConnections.strConexionDataMart, connection, recordSet);
	} else if (compareString(userType, "Administrador")){
		//usersToShowMeII = "";
	} else{
		usersToShowMe = getUsersToShowMeCurrentGeography(replaceAll(queries.queryGetUsersToShowII, "rUsuario", users.currentUser), stringConnections.strConexionDataMart, connection, recordSet);
		MainTrader = getUser(connection, recordSet, stringConnections.strConexionDataMart, replaceAll(queries.queryGetMainTrader,'R_USUARIOS', users.currentUser));
		UserName =  getUser(connection, recordSet, stringConnections.strConexionDataMart, replaceAll(queries.queryGetUserName,'R_USUARIOS', users.currentUser));
	}
	
	// Show connected user
	showUserConnected("#connected-user");
	
	// Insert Log
	insertLog(connection, "Contact WEB");

	//Contacts
	//Build the table 
	var main = (compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) ? "IN ('Ambos','Mesa')" : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")) ? "IN ('Ambos','Comex')" : "";
 	var query = replaceAll(replaceAll(queries.queryGetContacts, "R_USUARIOS", usersToShowMe),"R_MAIN", main);
	buildTable( headers.headersContacts, "","#contact-table");
	table = getContacts(connection, recordSet, stringConnections.strConexionContactos, query);
	contactTable = $('#contact-table').DataTable({ data: table, "lengthMenu": [[10, 15, 30, -1], [10, 15, 30, "Todos"]], "aaSorting": [], "deferRender": true});
	(compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) ? "" : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")) ? $(contactTable.column(7).header()).text('Consultor') : $(contactTable.column(7).header()).text('Trader / Consultor');
	(compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) ? $("#Comex").prop('disabled', true) : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")) ? $("#Mesa").prop('disabled', true) : $("#group").prop('disabled', true);
	putScrollOnTable("#contact-table");
	
	//Events
	addAllEvents();

});


function destroyTableContacts(selector, type){
	$(selector).DataTable().destroy();
	table = [];
	var grupo = compareString(userType, "Administrador") ? "" : getUsersToShowMeCurrentGeography(replaceAll(queries.queryGetUsersToShowII, "rUsuario", MainTrader), stringConnections.strConexionDataMart, connection, recordSet);
	var main = (compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) ? "IN ('Ambos','Mesa')" : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")) ? "IN ('Ambos','Comex')" : "";
	var query = replaceAll(replaceAll(queries.queryGetContacts, "R_USUARIOS", usersToShowMe),"R_MAIN", main);
	var queryGrupo = replaceAll(replaceAll(queries.queryGetContacts, "R_USUARIOS", grupo),"R_MAIN", main);
	buildTable( headers.headersContacts, "", selector);
	type == "user" ? table = getContacts(connection, recordSet, stringConnections.strConexionContactos, query) : type == "group" ? table = getContacts(connection, recordSet, stringConnections.strConexionContactos, queryGrupo) : alert("Error generando la tabla"); 
	contactTable = $('#contact-table').DataTable({ data: table ,"lengthMenu": [[10, 15, 30, -1], [10, 15, 30, "Todos"]], "aaSorting": [], "deferRender": true});
	(compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) ? "" : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")) ? $(contactTable.column(7).header()).text('Consultor') : $(contactTable.column(7).header()).text('Trader / Consultor');
	if(scroll)putScrollOnTable(selector);
}

