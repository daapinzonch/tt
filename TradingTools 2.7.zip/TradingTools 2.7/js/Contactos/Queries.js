function generateDate(sDay, sMonth, sYear){

	var min = 18, max = 100; nMonths = 11; minDay = 1; maxDay = 31;
	var year = (new Date()).getFullYear();
	var months = ["Ene", "Feb", "Mar", "Abr", "May", "Jun","Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
	
	for (var i = minDay; i <= maxDay; i++) {
		$('<option>', {value: ("0" + i).slice(-2), text: i}).appendTo(sDay);
	}


	for (var i = 0; i <= nMonths; i++) {
		$('<option>', {value: ("0" + (i+1)).slice(-2), text: months[i]}).appendTo(sMonth);
	}
	
	for (var i = min; i <= max; i++) {
		var years = year - i;
		$('<option>', {value: years, text: years}).appendTo(sYear);
	}	
}


function adressInformation(sCountries, sStates, sCities, sNomenclarute){	
	var nomenclature = ["Autopista", "Avenida", "Av.Calle", "Av.Carrera", "Bulevar", "Calle", "Carrera", "Carretera", "Circunvalar", "Diagonal", "Pasaje", "Paseo", "Peatonal", "Transversal", "Troncal", "Variante", "Via", "Kilometro" ];
	var valueCountry = $('#countries option:selected').attr('id');
	var valueState = $('#states option:selected').attr('id');
	
	for (var i = 0; i < countries.length; i++) {
		$('<option>', {value: countries[i].name, text: countries[i].name, id:countries[i].id}).appendTo(sCountries);
	}
	
	for (var i = 0; i < states.length; i++) {
		if(valueCountry == states[i].country_id){
			$('<option>', {value: states[i].name, text: states[i].name, id:states[i].id}).appendTo(sStates);
		}
	}
	
	for (var i = 0; i < cities.length; i++) {
			if(valueState == cities[i].state_id){
				$('<option>', {value: cities[i].name, text: cities[i].name}).appendTo(sCities);
			}
	}
	
	for (var i = 0; i < nomenclature.length; i++) {
		$('<option>', {value: nomenclature[i], text: nomenclature[i]}).appendTo(sNomenclarute);
	}
	
}


function getContacts (connection, recordSet, stringConnection, query){
	var data = [];
	var i = 0;
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var id = recordSet(0).Value;
			var nit = recordSet(1).Value;
			var contact = recordSet(2).Value;
			var operate = StringCommas(recordSet(3).Value);
			var name = recordSet(4).Value.replace(',',' '); 
			var job = recordSet(5).Value.split(',')[0].toUpperCase(); 
			var email = recordSet(6).Value.split(',')[0]; 
			var phone = recordSet(7).Value.split(',')[0]; 
			var trader = recordSet(9).Value;
			var consultor = recordSet(10).Value;
			var user = (compareString(userType, "TraderT") || compareString(userType, "CoordinadorT")) ? trader : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI")) ? consultor : trader +" / "+ consultor;
			var unity = recordSet(11).Value;
			var rate = recordSet(12).Value;
			var action = "<i title='Editar Contacto' data-toggle='tooltip' class='fa fa-pencil' id='editContact'></i> <i title='Eliminar Contacto' data-toggle='tooltip' class='fa fa-user-times' id='deleteContact'></i><div class='checkbox checkbox-circle checkbox-primary text-left' title='Seleccionar Email' data-toggle='tooltip'><input type='checkbox' name='email' class='styled' id='select' value='option1' aria-label='Single checkbox One'><label></label></div>";
			data.push( [nit + "<i value="+id+"></i>", contact, operate, name, job, email, phone, user, unity, rate, action] ); 

			recordSet.MoveNext();
		}

	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}
	
	return data;
}


function getCustomer(connection, recordSet, stringConnection, query){
	var info = [];
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			for (var i = 0; i < recordSet.Fields.Count; i++) {
				info[i] = recordSet(i).Value == null ? "" : recordSet(i).Value; 
			}
			recordSet.MoveNext();
		}	

	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}	

	return info;
}



//Selecciona la informacion del contacto para editarla
function getContactInfo (connection, recordSet, stringConnection, query){
	var final = [];
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			for (var i = 0; i < recordSet.Fields.Count; i++) {
				final[i] = recordSet(i).Value == null ? "" : recordSet(i).Value; 
			}
			recordSet.MoveNext();
		}	
	
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}	

	return final;
}


function getID (connection, recordSet, stringConnection, query){
	var ID = "";
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			ID = recordSet(0).Value;
			recordSet.MoveNext();
		}	
	
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}	

	return ID;
}


function duplicateValues (connection, recordSet, stringConnection, query){
	var array = ["",false];
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			array[0] = recordSet(0).Value;
			array[1] = true;
			recordSet.MoveNext();
		}	
	
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}	
	return array;
}



function createContact(connection, stringConnection, command ,query){
		
	if(!insert(query, stringConnection, connection, command)) {
		showBootstrapDialog("Informaci�n","Ocurri� un error al intentar crear el Contacto","DANGER","ALERT","NORMAL");
	}else {
		resetForm("#contact-form");
		$("#form-modal").modal("hide");
		var id = getID(connection, recordSet, stringConnections.strConexionContactos, queries.queryGetID);
		LogContact(connection, stringConnections.strConexionContactos, command, replaceAllArray(queries.queryInsertLog,['R_ID','R_TRADER','R_STATE'], [id, users.currentUser.toUpperCase(), "Cre�"]));
		showBootstrapDialog("Informaci�n","Se cre� correctamente el contacto","PRIMARY","ALERT","NORMAL");
	}
}

function LogContact(connection, stringConnection, command ,query){
		
	if(!insert(query, stringConnection, connection, command)) {
		showBootstrapDialog("Informaci�n","Ocurri� un error al intentar crear el Contacto","DANGER","ALERT","NORMAL");
	}
}

function editContact (connection, command, stringConnection, query, id){

	if (!update(query, stringConnection, connection, command)){
			showBootstrapDialog("Informaci�n","Ocurri� un error al intentar guardar el Contacto","DANGER","ALERT","NORMAL");
		} else{
			resetForm("#contact-form");
			$("#form-modal").modal("hide");
			LogContact(connection, stringConnections.strConexionContactos, command, replaceAllArray(queries.queryInsertLog,['R_ID','R_TRADER','R_STATE'], [id, users.currentUser.toUpperCase(), "Edit�"]));
			showBootstrapDialog("Informaci�n","Se edit� exitosamente el contacto","PRIMARY","ALERT","NORMAL");
		}
}

function deleteContact (connection, command, stringConnection, query, id){

	if (!update(query, stringConnection, connection, command)){
			showBootstrapDialog("Informaci�n","Ocurri� un error al intentar eliminar el Contacto","DANGER","ALERT","NORMAL");
		} else{
			resetForm("#contact-form");
			$("#form-modal").modal("hide");
			LogContact(connection, stringConnections.strConexionContactos, command, replaceAllArray(queries.queryInsertLog,['R_ID','R_TRADER','R_STATE'], [id, users.currentUser.toUpperCase(), "Elimin�"]));
			showBootstrapDialog("Informaci�n","Se Elimin� exitosamente el contacto","PRIMARY","ALERT","NORMAL");
		}
}



//Function that Convert JSON for Download 
function getDownload (connection, recordSet, stringConnection, query){
	var final = [];
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var rate = recordSet(0).Value;
			var nit = recordSet(1).Value;
			var contact = recordSet(2).Value;
			var main = recordSet(3).Value;
			var operate = replaceAll(StringCommas(recordSet(4).Value),',',';');
			var name = recordSet(5).Value.replace(',',' ').toUpperCase(); 
			var gender = recordSet(6).Value;
			var email = replaceAll(recordSet(7).Value,',',';'); 
			var phone = replaceAll(recordSet(8).Value,',',';'); 

			final.push({"Calificacion": rate, "Nit": nit, "Cliente":replaceAll(recordSet(2).Value,',',' '), "Principal": main, "Opera":operate, "Nombre":name, "Genero":gender, "Email":email, "Telefonos":phone})
			recordSet.MoveNext(); 	
		}

	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}

	return final;
}
// Function that Convert JSON for Download //
function downloadInformation(selectorTable, sheetName, fileName, rutaActual){
	try{
		var data = $(selectorTable).tableToJSON();		
		for (var i = 0; i < data.length; i++) {
			delete data[i]["Acci�n"];
		}

		if(typeof XLSX == 'undefined') XLSX = require('xlsx');
		var ws = XLSX.utils.json_to_sheet(data);
		var wb = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, sheetName);
		var wbout = XLSX.write(wb, {bookType:'csv', bookSST:false, type:'array'});
		var blob = new Blob([wbout], {type: "application/octet-stream"});
		saveAs(new Blob([wbout], {type:"application/octet-stream"}), fileName + ".csv"); // Use "FileSaver.js"

	} catch(e){
		showBootstrapDialog("Error", "Ocurri� un error en proceso de exportaci�n (" + e.message + ")." ,"PRIMARY", "ALERT", "NORMAL" );
	}
}


function downloadExcel(selector, filename, rutaActual){
	try{	
		var file = new ActiveXObject("Scripting.FileSystemObject");  
    	var excel = file.CreateTextFile(rutaActual, true);
    	var cadena, values;

		var data = $(selector).tableToJSON();	
		for (var i = 0; i < data.length; i++) {
			delete data[i]["Acci�n"];
		}

		excel.writeline(Object.keys(data[0]).toString())
		for (var i = 0; i < data.length; i++) {
			cadena = JSON.parse(JSON.stringify(data[i]).replace(/,(?!["{}[\]])/g, ";"));
			values = Object.keys(cadena).map(function (key) { return cadena[key]; });
			replaceAll(values[2],',',' '); 
			excel.writeline(values);
		}
		excel.close();

	} catch(e){
		showBootstrapDialog("Error", "Ocurri� un error en proceso de exportaci�n (" + e.message + ")." ,"PRIMARY", "ALERT", "NORMAL" );
	}
}


function getUser (connection, recordSet, stringConnection, query){
	var trader = "";
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			trader = recordSet(0).Value;
			recordSet.MoveNext();
		}	
	
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}	

	return trader;
}


function resetForm(selector){
	$(selector)[0].reset();
	$(selector).find(':input').each(function() {
		switch (this.type) {
			case 'email':
			case 'last-name':
			case 'name':
			case 'tel':
			case 'text':
			case 'textarea':
				$(this).val('');
				break;
			case 'checkbox':
			case 'radio':
				this.checked = false;
				$('input[name="principal"]').attr("required","");
				$('#F').attr("required","");
				$('#M').attr("required","");
				$('input:checkbox').attr('required','');
		}
	});

	formatPhone($("#phone"), 'PHONE');
	formatPhone($("#mobile"), 'MOBILE');
	nEmail = resetInputsForm(".email", nEmail)
	nPhone = resetInputsForm(".phone", nPhone);
	nMobile = resetInputsForm(".mobile", nMobile);
	nHobbie = resetInputsForm(".hobbie", nHobbie);
	$('#states').empty().append('<option disabled selected> Departamento </option>');
	$('#cities').empty().append('<option disabled selected> Ciudad </option>');
}


function rating(){
    $(".btnrating").on('click',(function(e) {
	
		var previous_value = $("#selected_rating").val();
		var selected_value = $(this).attr("data-attr");

		$("#selected_rating").val(selected_value);
		
		$(".selected-rating").empty();
		$(".selected-rating").html(selected_value);
		
		for (i = 1; i <= selected_value; ++i) {
			$("#rating-star-"+i).toggleClass('fa-star');
			$("#rating-star-"+i).toggleClass('fa-star-o');
		}
		
		for (ix = 1; ix <= previous_value; ++ix) {
			$("#rating-star-"+ix).toggleClass('fa-star');
			$("#rating-star-"+ix).toggleClass('fa-star-o');
		}
	
	}));	
}

function resetRating(selected_value){
	var previous_value = $("#selected_rating").val();
    $("#selected_rating").val(selected_value);

	$(".selected-rating").empty();
	$(".selected-rating").html(selected_value);

	if (selected_value == 0) {
		for (i = 1; i <= 5; ++i) {
			$("#rating-star-"+i).addClass('fa-star-o');
			$("#rating-star-"+i).removeClass('fa-star');
		}
	}
	else{
		for (i = 1; i <= selected_value; ++i) {
			$("#rating-star-"+i).toggleClass('fa-star');
			$("#rating-star-"+i).toggleClass('fa-star-o');
		}	
		for (ix = 1; ix <= previous_value; ++ix) {
			$("#rating-star-"+ix).toggleClass('fa-star');
			$("#rating-star-"+ix).toggleClass('fa-star-o');
	}
	}
}

function resetInputsForm(selector, variable){
	for(variable; variable>0; variable--){
		$( selector + variable + "").remove();
	}
	return variable;
}

function addInputValues(selector, arrayValues){
	$(selector).each(function() {
		Array.isArray(arrayValues) == true ? arrayValues.push(this.value) : arrayValues[this.value] = this.value;
	});
}

function checkboxValues(selector, array){
	for (var i = 0; i < selector.length; i++) {
		$("#" + selector[i]).is(":checked") == true ? array[i] = $("#" + selector[i]).val() : "";
	}
}

function addInputFormHTML(container, text, message, maxNumber, variable){

	if(variable >= maxNumber){
			showBootstrapDialog("Informaci�n", message, "WARNING", "ALERT", "SMALL");
		}
		else{
			if(text == "email"){
				nEmail = nEmail + 1;
				$(container).append("<div class='form-group col-md-12 email"+ nEmail +"'><div class='input-group'><div class='input-group-addon'><i class='fa fa-envelope'></i></div><input type='email' class='form-control emails' id='email"+ nEmail +"' placeholder='Email "+ nEmail +"'></div></div>");

			}
			else if(text == "phone"){
				nPhone = nPhone + 1;
				$(container).append("<div class='form-group col-md-12 phone"+ nPhone +"'><input type='tel' class='form-control phones'  id='phone"+ nPhone +"'></div>");
				formatPhone($("#phone"+ nPhone), 'PHONE');
			}
			else if(text == "mobile"){
				nMobile = nMobile + 1;
				$(container).append("<div class='form-group col-md-12 mobile"+ nMobile +"'><input type='tel' class='form-control mobiles'  id='mobile"+ nMobile +"'></div>");
				formatPhone($("#mobile"+ nMobile), 'MOBILE');
			}
			else if(text == "hobbie"){
				nHobbie = nHobbie + 1;
				$(container).append("<div class='form-group col-sm-6 col-md-6 hobbie"+ nHobbie +"'> <select class='form-control hobbies' id='hobbie"+ nHobbie +"'> <option value='Musica'> Musica </option> <option value='Deportes'> Deportes </option> <option value='Comida'> Comida </option> <option value='Planes'> Planes </option> <option value='Otros'> Otros </option> </select></div>");
				$(container).append("<div class='form-group col-sm-6 col-md-6 hobbie"+ nHobbie +"'> <input type='text' class='form-control hobbies-text' value='' id='text-hobbie' placeholder='Tipo de Hobbie "+ nHobbie +"'></div>");
			}
			else{
				alert("Error aprenda a programar");
			}
		}
}


function formatPhone(selector, type){
	$(selector).intlTelInput({
        allowExtensions: type == "PHONE" ? true : type == "MOBILE" ? false : alert("Tipo Inexistente"),
        autoFormat: true,
        autoHideDialCode: true,
        autoPlaceholder: true,
        defaultCountry: "co",
        nationalMode: false,
        numberType: type == "PHONE" ? "FIXED_LINE" : type == "MOBILE" ? "MOBILE" : alert("Tipo Inexistente"),
        onlyCountries: ['co', 'us', 'pa', 'pe', 'ca', 'ar', 'cl', 'bo', 'br', 'ec', 'es', 'fr', 'de', 'bs', 'mx', 'gb', 'it', 'do', 'uy'],
        preferredCountries: ['co', 'us','ca'],
        utilsScript: "libs/utils.js"
    });

	$(selector).change(function() {
		var isValid = $(selector).intlTelInput("isValidNumber");
		var empty = $(selector).val();
		empty == "" ? (selector)[0].setCustomValidity("") : isValid == false ? $(selector)[0].setCustomValidity("N�mero Invalido") : (selector)[0].setCustomValidity("");
	});

};


function requiredCheckbox (arraySelector){
	if ( (arraySelector[0].prop('checked') == true ||arraySelector[1].prop('checked') == true  || arraySelector[2].prop('checked')  == true  || arraySelector[3].prop('checked')  == true  || arraySelector[4].prop('checked') ) == true ){
		$('input:checkbox').removeAttr("required");
	}
	else{
		$('input:checkbox').attr('required','required');
	}
}


function StringCommas(string){
	string = string.replace(/,+/g, ','); //replace two commas with one comma
	string = string.replace(/^\s+|\s+$/g,''); //remove the spaces
	string = string.split(","); // change them into array
	string = string.filter(function(e){ return e.length});
   	string = string.join(',');
   	return string;
}

function arrayDiff (array1, array2) {
	var diff = array1.filter(function(obj) { return array2.indexOf(obj) == -1 });
	return diff;
}

function getEmails(){
	
	// $('#selectAll').click(function(){
 //      	$('#tooltipAll').attr('data-original-title','Desmarcar Todos');
	// 	$('td input:checkbox','table').prop('checked',false);
 //        if($(this).prop("checked") == true){

 //        	mails = [];
	//     	$('select[name = contact-table_length]').val(-1);
	// 	    contactTable.settings()[0]._iDisplayLength = -1;
	// 	    contactTable.draw();
	// 	  	$('#contact-table td input:checkbox').prop('checked',this.checked);
	// 		$('#contact-table tbody tr td:nth-child(6)').each( function(){
	// 		   mails.push($(this).text().trim());
	// 		   mails = mails.filter(function(e) { return e.trim() != ''; }); 
	// 		});
 //        }
 //        else if($(this).prop("checked") == false){
 //            mails = [];
 //        	$('select[name = contact-table_length]').val(10);
 //        	contactTable.settings()[0]._iDisplayLength = 10;
	// 	    contactTable.draw();
	// 	    $('#tooltipAll').attr('data-original-title','Seleccionar Todos');
 //        }
 //    });

	$('#selectAll').click(function(){

      	$('#tooltipAll').attr('data-original-title','Desmarcar Todos');
      	contactTable.$("input[type='checkbox']").prop('checked', false);
        if($(this).prop("checked") == true){
			mails = [];
		 	for (var i = 0; i < table.length; i++) {
				mails.push(table[i][5].trim());
				mails = mails.filter(function(e) { return e.trim() != ''; }); 
			}
        }
        else if($(this).prop("checked") == false){
            mails = [];
		    $('#tooltipAll').attr('data-original-title','Seleccionar Todos');
        }
    });


}




