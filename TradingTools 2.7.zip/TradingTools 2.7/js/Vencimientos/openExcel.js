function openExcel(selectorTable, tableToExport, isExpirations){

	if(confirm("Tenga en cuenta que la cantidad de registros a exportar depende del filtro aplicado en la tabla, \u00BFDesea continuar? \n\nTambi\u00E9n, el contenido del portapapeles se perder\u00E1.")){
		try{
		
		var idToJS = selectorTable.substring(1,selectorTable.length);
		
		$("body").append("<div class='col-xs-0' style='width=10px;heigth:10px'><table class='' id='" + idToJS + "'><table/></div>");
		$(selectorTable).html($(tableToExport).html());

		if(isExpirations){
			$(selectorTable + " thead tr th:last-child").html("");
			$(selectorTable + " .enviar").html("");
			$(selectorTable + " .footerFilter").html("");
		}
		
		var a = document.body.createTextRange();

		a.moveToElementText(document.getElementById(idToJS));
		a.select();
		a.execCommand('copy');
		$(selectorTable).remove();
		
		
			// Objeto ActiveX para utilizar Excel
			var Excel = new ActiveXObject("Excel.Application");
			var ExcelSheet = new ActiveXObject("Excel.Sheet");
			var Book = Excel.Workbooks.Add();

			Book.ActiveSheet.Paste;
		if(isExpirations){	
			//Ajustar estilos
			Book.ActiveSheet.Columns("A:Q").EntireColumn.WrapText = false;
			Book.ActiveSheet.Columns("A:Q").EntireColumn.Font.Name = "Arial";
			Book.ActiveSheet.Columns("A:Q").EntireColumn.Font.Size = 11;
			Book.ActiveSheet.Columns("A:Q").EntireColumn.RowHeight = 15;
			Book.ActiveSheet.Columns("B").EntireColumn.NumberFormat = "#";
			Book.ActiveSheet.Columns("T").EntireColumn.NumberFormat = "0000";
			Book.ActiveSheet.Columns("U").EntireColumn.Delete;
			// Book.ActiveSheet.Range("M1").HorizontalAlignment = 3;
			Book.ActiveSheet.Range("A1").Select;
		}
			Excel.Visible = true;
		} catch(e){
			alert(e.message);
		}
	}
}