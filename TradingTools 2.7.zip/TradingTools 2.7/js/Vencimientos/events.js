var wasSelectedCurrent = false;
var uniqueElement = '';
var operaciones = '';
/**************************************************************/
/****************************** EVENTS ************************/
/**************************************************************/

	
function removeElementCoincidence(array, coincidence){
	for(i=0; i<array.length; i++){
		if(array[i].search(coincidence) != -1){
			array.splice(i,1);
		}
	}
	return array;
}

// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});

//Seleccionar cualquier elemento
$("#swapVencimientos").on('click', ".select", function(e){
	if(hasClass($(this).parent().parent().parent().parent(),"DesactivadoEnviar")){//No permitir que se genere la tabla m�s de una vez para un mismo elemento
			$(this).parent().parent().parent().parent().removeClass("DesactivadoEnviar");
			$(this).parent().parent().parent().parent().addClass(" ActivadoEnviar");
			
		var nit = $(e.target).closest("tr").find('td:eq(1)').text();
		if(ids.indexOf(nit) == -1){
			ids.push(nit);
		}
	}
	
});

//Desmarcar cualquier elemento
$("#swapVencimientos").on('click', ".unselect", function(e){
	$(this).parent().parent().parent().parent().removeClass("ActivadoEnviar");
	$(this).parent().parent().parent().parent().addClass(" DesactivadoEnviar");
		var numOpeartion = $(e.target).closest("tr").find('td:eq(1)').text();
		removeElementCoincidence(ids,numOpeartion);
});

//Enviar elementos seleccionados
$("#swapVencimientos").on('click', ".enviarSeleccionadas", function(e){
	var newIds = ids;
	if(newIds.length > 0){
		// alert("Not ready yet: " + ids.length);
		
		
		var tabs = '';
		for(iterator = 0;iterator < newIds.length; iterator++){
			var inf = getInfoClient(newIds[iterator]);
			// var infT = getNitAndName(newIds[iterator]);
			// inf = compareString(inf, "")?  infT : inf;
			// var infoClient = 'informacion cliente';
			
			
			var fwd = getOperationsFWD(newIds[iterator]);
			// var fwd = 'forward tabla';
			var option = getOperationsOPT(newIds[iterator]);
			// var option = 'option tabla';
			var swap = getOperationSW(newIds[iterator]);
			// var swap = 'swap tabla';
			
			var tab = "<div style='width:800px;text-align:center'><table border='1' style='border-collapse:collapse;border:1px solid black;width:100% !important'><tbody style='text-align:center'>" + fwd + option + swap + "</tbody></table></div>";
			tabs += "<br><br><br><br><br><br><br>" + inf + "<br>" + tab;
		}
		
		operaciones = message + body + tabs;
		enviarVencimiento();
	}
	
});

//Enviar elemento actual
$("#swapVencimientos").on('click', ".enviarActual", function(e){
	
	//Obtener nit de cliente a consultar
	var identificacion = $(e.target).closest("tr").find('td:eq(1)').text();
	var tipo = ($(e.target).closest("tr").find('td:eq(0)').text()).toUpperCase();
	var info = getInfoClient(identificacion);
	var tab = "<div style='width:800px;text-align:center'><table border='1' style='border-collapse:collapse;border:1px solid black;width:70% !important'><tbody style='text-align:center'>" + getOperationsFWD(identificacion) + getOperationsOPT(identificacion) + getOperationSW(identificacion) + "</tbody></table></div>";
	// uniqueElement = getInfoClient(identificacion);
	
	// wasSelectedCurrent = true;
	operaciones = message + info + "<br>" + body + "<br>" + tab;
	// operaciones = "<div style='width:400px'>" + getOperationsFWD(identificacion) +  getOperationsOPT(identificacion) + getOperationSWAP(identificacion) + "</div>";
	
	enviarVencimiento();
});
