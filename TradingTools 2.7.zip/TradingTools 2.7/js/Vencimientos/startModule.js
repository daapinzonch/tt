/* ************************************************************************* */
/* ************************INICIAR P�GINA*********************************** */
/* ************************************************************************* */
var connection = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
var fileSystem = new ActiveXObject("Scripting.FileSystemObject");

	//Mostrar "Cargando..."
showMessageLoading("notificationTitle", "notificationBody");
showLoadingOverlay();

$(document).ready(function(){

	try{
	//Show version
		assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), fileSystem));	
		
	//	Coloca el nombre de usuario
		$("#user").html('Usuario conectado: <b>' + users.currentUser + '</b>');

		// Get User Rol
		userType = getUserType(connection, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
		// Show connected user
		showUserConnected("#connected-user");
		// Show modules for user
		showModules(userType);
	//	Inserta registro en Logs.accdb
		if(compareString(userType,"Administrador") || compareString(userType,"TraderT") || compareString(userType,"CoordinadorT") || compareString(userType,"GerencialT")){//Verificar que el usuario exista y sea trader "Tesorer�a"
		insertLog(connection,"Vencimientos WEB");
		

	//	Coloca la fecha del ultimo cargue en formato 'dd/mm/yyyy'
		$("#fecha").append('<a style="color:rgb(51,153,255);font-size:15px;"><b>' + (getMaxDate()) + '</b></a>');

	//	Construir tabla
		//$("#swapVencimientos").html(getSWAPOnly());
		buildTable(headers.headersExpirations, getSWAPOnly(), "#swapVencimientos");
		getAllSwap();
		getFlowsAndRates();
		getOtherExpirations();
		instanceTable("#swapVencimientos");
		putScrollOnTable("#swapVencimientos");

	//	Mostrar tabla
		$("#linkShowGraph").click();

	//	Exportar tabla a excel
		addLinkOnTable("#swapVencimientos_info", "#swapVencimientos_paginate", "exportExpirations", "<b>Exportar vencimientos</b>");

		$("#exportExpirations").on('click',	function(){
			openExcel("#exportar", "#swapVencimientos", true);//Pasar el id que se quiera (este no debe estar creado).
		});
		
		removeClass("#contentPage", "hide");
		}else{
			var text = "<h3 style='background: rgb(242, 242, 242); text-align: center; line-height: 25;'>Usted no se encuentra en nuestra base de datos, esta herramienta es de uso exclusivo para <b>Traders</b>.</h3>";
			$("body").append(text);
		}
		hideStartMessage("#loading", ".container");
		hideLoadingOverlay();
		}catch(e){
		alert('Fall�: ' + e.message);
		}
});
