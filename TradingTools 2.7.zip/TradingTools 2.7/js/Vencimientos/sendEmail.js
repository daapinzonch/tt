/**************************************************************/
/****************************  ENVIAR CORREO  *****************/
/**************************************************************/
	var filterValues;
	var tables = [];
	var tipos = [];
	var tableFWD;
	var tableSWAP;
	var tableOPT;
	var ids = [];
	var	rutaImg = "<img src='" + getLogoRoute().replace('html','img').replace('Vencimientos.html','logo.png') + "' width='40px' height='10px' style='width:40px;heigth:10px'>";
	var h =	"<h2 style='color:rgb(68,84,106);font-size:30px'>Divisi�n de Internacional y Tesorer�a</h2>" +
			"<h3 style='color:rgb(127,127,127);font-size:22px'>Vencimiento Operaciones</h3>";
	
	var message = "<div>" +
				"<div style='width:100%'>" +
					"<div class='element' style='width:60%;vertical-align:top;color:rgb(7,53,122);font-family:Arial;font-size:50px;font-weight:900;display:inline-block;font-variant: normal'>" +
					"</div>" +
					"<div class='element' style='text-align:right;font-family:Arial;display:inline-block'>" +
						// "<div style='float:left'>" + rutaImg + "</div>" + 
						"<table border='0' style='border-collapse:collapse;width:100%'><tbody><tr><td style='text-align:left'>" + rutaImg + "</td><td style='text-align:right'>" + h + "</td></tr></tbody></table>" +
					
					"</div>" +
					"<div style='width:100%;heigth:15px;background-color:rgb(68, 84, 106)'><br><br></div>" +
					"<div>" +
					"</div>" +
				"</div>" +
			"</div>" +
			"<div class='content' style='font-family:Arial;font-size:16px;color:black;font-weight:normal'>" +
				"<div style='width:100%;text-align:right'><b>Fecha:	</b>" + formatDate($.datepicker.formatDate('dd/mm/yyyy',(new Date())),true) + "</div>" +
				"<br>Estimado Cliente<br>" +
				"A continuaci�n encontrar� las operaciones de Derivados pr�ximas a vencerse con la Mesa de Distribuci�n<br><br>" +
			"</div>";
			
	var body = "<div class='content' style='font-family:Arial;font-size:16px;color:black;font-weight:normal'>" +
					"Recuerde que si desea hacer alguna modificaci�n a las condiciones inicialmente pactadas en estas operaciones, incluyendo cambios de modalidad o ajustes en la fecha de vencimiento, debe contactarse <b><u>v�a telef�nica</u></b> con su trader asignado como <b><u>m�nimo tres (3) d�as h�biles antes del vencimiento de las mismas</u></b>. Por su seguridad, el Banco <b>NO</b> tramitar� modificaciones recibidas por email o cualquier otro medio diferente al contacto directo a nuestras l�neas de atenci�n.� Al momento de contactarnos, su trader le informar� la viabilidad y el procedimiento a seguir para adelantar dichas modificaciones.<br><br><b>Recuerde que para el cumplimiento de las operaciones delivery (con entrega) debe radicar los documentos antes del mediod�a de la fecha de cumplimiento.</b> <br><br>Estamos atentos a apoyarlo ante cualquier duda o inquietud." +
				"</div>";
	var subject = "BANCO DE BOGOT� � Pr�ximos Vencimientos de Derivados";

function enviarVencimiento() {

	try{
				var network = new ActiveXObject('WScript.Network');
				var serverName = network.computerName;
				operaciones = "<div style='width:80%;margin-left:10%;margin-right:10%'>" + operaciones + "</div>";
		
			if (compareString(serverName, "ARIESTES02") || compareString(serverName, "ARIESTES01") || compareString(serverName, "WIN2012P02.banbta.net") || compareString(serverName, "WIN2012P02") || compareString(serverName, "win2012p02")){
				var cdoMsg = new ActiveXObject("CDO.Message");
				
				cdoMsg.From = "Internacional@bancodebogota.com.co";
				cdoMsg.To = (users.currentUser + '').toLowerCase() + "@bancodebogota.com.co";
				cdoMsg.Subject = subject;
								
				// cdoMsg.HTMLBody = "<span style='font-family: arial'>" + message + "<br><br>" + clientInfo + "<br><br>" + body + "<br><br></span><br><br>" + quitCommas(tables)	+ "<br><br>" + cdoMsg.HTMLBody;
				// cdoMsg.HTMLBody = operaciones + cdoMsg.HTMLBody;
				cdoMsg.HTMLBody = "<div style='text-align:center;'><table style='width:80%;margin-left:10%;margin-right:10%;border:1px solid black'><tbody><tr><td>" + operaciones + cdoMsg.HTMLBody + "</td></tr></body></table></div>";

				var namespace = "http://schemas.microsoft.com/cdo/configuration/";
				cdoMsg.Configuration.Fields.Item(namespace + "sendusing") = 2;
				cdoMsg.Configuration.Fields.Item(namespace + "smtpserver") = "outlook.bancodebogota.net";
				cdoMsg.Configuration.Fields.Item(namespace + "smtpserverport") = 25;
				cdoMsg.Configuration.Fields.Item(namespace + "sendusername") = "Internacional@bancodebogota.com.co";
				cdoMsg.Configuration.Fields.Update();
				
				cdoMsg.Send();
				/************************* MOSTRAR MENSAJE MODAL *****************/
				$("#contenidoModalInformacion").html("Un correo ha sido enviado a " + (users.currentUser).toLowerCase() + "@bancodebogota.com.co.");
				$("#tituloModalInformacion").html("<b>Env�o satisfactorio</b>");
				$('#modalInformacion').modal('show');
				/*****************************************************************/
			} else{
		
				// Crea y abre una instancia de Outlook
				var outlook = new ActiveXObject('Outlook.Application');
				// Abre una nueva ventana de correo
				var email = outlook.CreateItem(0);
				//Destinatario
				//email.Recipients.Add(users.currentUser).Type = 1;
				// Asunto
				email.Subject = subject;
				
				// Muestra el contenido del correo
				email.Display();
				// Coloca contenido en el correo
				email.HTMLBody = "<div style='text-align:center;'><table style='width:80%;margin-left:10%;margin-right:10%;border:1px solid black'><tbody><tr><td>" + operaciones + email.HTMLBody + "</td></tr></body></table></div>";
			}
				
	}catch(e){
		alert(e);
	} finally{
			//Almacenar valores de filtros secundarios, luego quitarlos de la tabla actual
			var sfArray = [];
			$(".secondFilter").each(function(){sfArray.push($(this).val())});
			$(".secondFilter").val("");
			$(".secondFilter").focusin();
			$(".secondFilter").focusout();
			
			//Almacenar valor de filtro principal, luego borrarlo de la tabla actual
			var filtroPrincipal = $("#swapVencimientos").DataTable().search();
			$("#swapVencimientos").DataTable().search("").draw();

			//Reiniciar clases
			var longitudeFilter = $("#swapVencimientos").DataTable().page.len();
			$("#swapVencimientos").DataTable().page.len(-1).draw();
			$(".ActivadoEnviar").addClass(" DesactivadoEnviar").removeClass("ActivadoEnviar");
			$("#swapVencimientos").DataTable().page.len(7).draw();
			
			//Reinicia arreglos usados
			tables = [];
			tipos = [];
			ids = [];
			
			//Poner filtros de nuevo
			$("#swapVencimientos").DataTable().search(filtroPrincipal).draw();
			$(".secondFilter").each(function(){$(this).val(sfArray.shift())});
			$(".secondFilter").focusin();
			$(".secondFilter").focusout();
			$("#swapVencimientos").DataTable().page.len(longitudeFilter).draw();
			
			//Desactivar "Enviar seleccionadas"
			addClass(".enviarSeleccionadas", " desactivado");
	}
}

//Obtener fecha en formato weekday, dd de mm de yyyy
function textDate(fDate){
	var dia = fDate.substring(0,2);
	var mes = fDate.substring(3,5);
	var a�o = fDate.substring(6,10);
	var fecha = new Date(mes + '/' + dia + '/' + a�o);
	
	var options = {
	weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
	};
	
	return fecha.toLocaleDateString('es-MX', options);
}

function formatDate(fdate, withStringMonths){
	var dia = fdate.substring(0,2);
	var mes = fdate.substring(3,5);
	var a�o = fdate.substring(6,10);
	
	fdate = mes + '/' + dia + '/' + a�o;
	
	var date = new Date(fdate);
	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var day = date.getDate();
	
		if (withStringMonths){
		validateNumberDigits(day);
		month = convertNumericMonthToStringMonth(month);
		
		return day + " " + month + " " + year;
	} else{
		return verifyDate(day, month, year);
	}
}

function quitCommas(array){
	var ret = '';
	
	for(i=0; i < array.length; i++){
		ret = ret + array[i];
	}
	return ret;
}

function getLogoRoute(){
	var rutaActual = location.pathname;
	
	rutaActual = rutaActual.substring(1, rutaActual.length);
	rutaActual = replaceAll(rutaActual, "/", "\\");
	rutaActual = replaceAll(rutaActual, "%20", " ");
	// rutaActual = replaceAll(rutaActual, "html\\Vencimientos.html", "img\\logo.png");
	
	return rutaActual;
}