function validateFlowType(flowType){
	flowType += '';
	return compareString(flowType, 'INT') ? "Inter�s" : compareString(flowType, 'XNL') ? "Capital" : compareString(flowType, 'IPR') ? "Inter�s proyectado" : compareString(flowType, 'PS') ? "Capital proyectado" : flowType;
}
function validateValue(operation){
	operation = (operation + '').toUpperCase() + '';
	return compareString(operation, 'PAY') ? "Banco Paga" : compareString(operation, 'REC') ? "Banco Recibe" : compareString(operation, 'BUY') || compareString(operation, 'COMPRA') ? "Banco Compra" : compareString(operation, 'SELL') || compareString(operation, 'VENTA') ? "Banco Vende" : compareString(operation, "NDF") ? "Non Delivery" : compareString(operation, "DF") ? "Delivery" : compareString(operation, "DEL") ? "Delivery" : compareString(operation, "ND") ? "Non Delivery" : operation;	
}
function formatCapitalLetter(value){
	value += '';
	var newValue = '';
	for(var k = 0;k < value.length;k++){
		if( k==0 ){
			newValue += (value.charAt(k)).toUpperCase();
		}else if(k > 0 && (value.charAt(k-1) == ' ' || value.charAt(k-1) == '-' || value.charAt(k-1) == '_' || value.charAt(k-1) == '	' || value.charAt(k-1) == '.')){
			newValue += (value.charAt(k)).toUpperCase();
		}else{
			newValue += (value.charAt(k)).toLowerCase();
		}
	}
	return newValue;
}
/*******************************************************************************/
/************************************  QUERIES  ********************************/
/*******************************************************************************/

//Obtener registros de Forward y Options
function getOtherExpirations(){
	
	try{
	//Conectar con base de datos en Access
	var strConn = stringConnections.strConnectionExpirations;
	var objConnection = new ActiveXObject("adodb.connection");
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = queries.queryGetOthers;
    recordSet.Open(strQuery, objConnection);
	
	var contenido = '';
		
		while(!recordSet.EOF){
			var bankPosition = formatCapitalLetter(validateValue(recordSet(9)));
			var idOperation = compareString(recordSet(0) + '', "FORWARD") ? "000" + recordSet(3) : recordSet(3) + "";
			var content= "<tr class='algo'>"
						  + "<td>" + formatCapitalLetter(validateValue(recordSet(0))) + '' + "</td>"
						  + "<td>" + recordSet(1) + "</td>"
						  + "<td>" + recordSet(2) + '' + "</td>"
						  + "<td>" + idOperation + "</td>"
						  + "<td>" + formatCapitalLetter(validateValue(recordSet(4))) + "</td>"
						  + "<td>" + formatCapitalLetter(validateValue(recordSet(5))) + "</td>"
						  + "<td>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(6))))),true) + '' + "</td>"
						  + "<td>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(7))))),true) + '' + "</td>"
						  + "<td>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(8))))),true) + '' + "</td>"
						  // + "<td>" + (compareString(recordSet(9) + '',"BUY") ? "BANCO COMPRA" : (compareString(recordSet(9) + '',"SELL") ? "BANCO VENTA" : recordSet(9) + '')) + "</td>"
						  + "<td>" + bankPosition + "</td>"
						  + "<td>" + recordSet(10) + '' + "</td>"
						  + "<td>" + addCommas(recordSet(11)) + '' + "</td>"
						  + "<td>" + '' + "</td>"
						  + "<td>" + addCommas(recordSet(12)) + '' + "</td>"
						  // + "<td>" + recordSet(12) + '' + "</td>"
						  + "<td>" + (compareString(recordSet(13) + '',"null") ? "" : recordSet(13) + '') + "</td>"
						  + "<td>" + (compareString(recordSet(14) + '',"null") ? "" : recordSet(14) + '') + "</td>"
						  + "<td>" + (compareString(recordSet(15) + '',"null") ? "" : recordSet(15) + '') + "</td>"
						  + "<td>" + (compareString(recordSet(16) + '',"null") ? "" : recordSet(16) + '') + "</td>"
						  
						  var select;
				  //compareString(recordSet(0) + '' , 'FORWARD') ? select = "<td class='enviar DesactivadoEnviar'><div class='btn-group'><span class='dropdown-toggle' style='cursor: pointer;' data-toggle='dropdown'><span title='Enviar �rdenes de Pago' class='fa fa-envelope'></span></span><ul class='dropdown-menu' role='menu' style='cursor: pointer;'><li><a class='seleccionarFWD' id='SFORWARD" + recordSet(3) + "'>Seleccionar</a></li><li><a class='deseleccionarFWD' id='DFORWARD" + recordSet(3) +"'>Desmarcar</a></li><li class='divider'></li><li><a class='enviarActual'>Enviar cliente actual</a></li><li><a class='enviarSeleccionadas desactivado'>Enviar ordenes seleccionadas</a></li></ul></div></td>" : select = "<td class='enviar DesactivadoEnviar'><div class='btn-group'><span class='dropdown-toggle' style='cursor: pointer;' data-toggle='dropdown'><span title='Enviar �rdenes de Pago' class='fa fa-envelope'></span></span><ul class='dropdown-menu' role='menu' style='cursor: pointer;'><li><a class='seleccionarOPT' id='SOPCIONES" + recordSet(3) + "'>Seleccionar</a></li><li><a class='deseleccionarOPT' id='DOPCIONES" + recordSet(3) + "'>Desmarcar</a></li><li class='divider'></li><li><a class='enviarActual'>Enviar cliente actual</a></li><li><a class='enviarSeleccionadas desactivado'>Enviar ordenes seleccionadas</a></li></ul></div></td>"
				  compareString(recordSet(0) + '' , 'FORWARD') ? select = "<td class='enviar DesactivadoEnviar'><div class='btn-group'><span class='dropdown-toggle' style='cursor: pointer;' data-toggle='dropdown'><span title='Enviar �rdenes de Pago' class='fa fa-envelope'></span></span><ul class='dropdown-menu' role='menu' style='cursor: pointer;'><li><a class='seleccionarFWD select' id='SFORWARD" + recordSet(3) + "'>Seleccionar</a></li><li><a class='deseleccionarFWD unselect' id='DFORWARD" + recordSet(3) +"'>Desmarcar</a></li><li class='divider'></li><li><a class='enviarActual'>Enviar cliente actual</a></li><li><a class='enviarSeleccionadas desactivado'>Enviar clientes seleccionadas</a></li></ul></div></td>" : select = "<td class='enviar DesactivadoEnviar'><div class='btn-group'><span class='dropdown-toggle' style='cursor: pointer;' data-toggle='dropdown'><span title='Enviar �rdenes de Pago' class='fa fa-envelope'></span></span><ul class='dropdown-menu' role='menu' style='cursor: pointer;'><li><a class='seleccionarOPT select' id='SOPCIONES" + recordSet(3) + "'>Seleccionar</a></li><li><a class='deseleccionarOPT unselect' id='DOPCIONES" + recordSet(3) + "'>Desmarcar</a></li><li class='divider'></li><li><a class='enviarActual'>Enviar cliente actual</a></li><li><a class='enviarSeleccionadas desactivado'>Enviar clientes seleccionadas</a></li></ul></div></td>"
				  content = content + select + "</tr>";
						
						
					compareString(recordSet(0)+'','OPCIONES') ? content = replaceAll(content, 'algo','') : content = replaceAll(content, 'algo',''); 
					  
			contenido = contenido + content;
			$("#swapVencimientos").append(content);
			recordSet.MoveNext();
		}
		
		
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
	}
}

//Obtener fecha de ls ultimos datos cargados en Vencimientos.accdb
 function getMaxDate(){
	try{
	var objConnection = new ActiveXObject("adodb.connection");
	var strConn = stringConnections.strConnectionExpirations;
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = queries.queryGetLastDate;
    recordSet.Open(strQuery, objConnection);
	var contenido = "";
	
		while(!recordSet.EOF){
			contenido = contenido + $.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(0))));
			recordSet.MoveNext();
		}
		
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
		return textDate(contenido);
	}
}

//Obtener registros unicos de SWAP
function getSWAPOnly(){
	
	try{
	var strConn = stringConnections.strConnectionExpirations;
	var objConnection = new ActiveXObject("adodb.connection");
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = queries.queryGetDistinctSWAP;
    recordSet.Open(strQuery, objConnection);
	
	// var contenido = "<thead><tr><th>Producto</th><th>Identificaci�n</th><th>Cliente</th><th>N�mero Operaci�n</th><th>Tipo</th><th>Modalidad</th><th>Inicio_flujo</th><th>Fin__flujo</th><th>Cum/to_flujo</th><th>PAY/REC</th><th>Moneda</th><th>Notional</th><th>Tasa operaci�n</th><th>Trader</th><th>Banca</th><th>Segmento</th><th>Unidad</th><th class='theadSend'>Enviar</th></tr></thead><tbody>";
	// var contenido = "<thead><tr><th>Producto</th><th>Identificaci�n</th><th>Cliente</th><th>N�mero Operaci�n</th><th>Tipo</th><th>Modalidad</th><th>Inicio_flujo</th><th>Fin__flujo</th><th>Cum/to_flujo</th><th>Posici�n Banco</th><th>Moneda</th><th>Notional</th><th>Tasa operaci�n</th><th>Trader</th><th>Banca</th><th>Segmento</th><th>Unidad</th><th class='theadSend'>Enviar</th></tr></thead><tbody>";
	var contenido = "<tbody>";
		
		while(!recordSet.EOF){
			
			
			// var table = '<table style="text-align: center; width:100%;margin:0px;padding:0px" border=1><tbody><tr><td>ffff1</td></tr><tr><td>ffff2</td></tr></tbody></table>';  
			var table = '<table ><tbody><tr><td>ffff1</td></tr><tr><td>ffff2</td></tr></tbody></table>';  
			/**/
			var tablePAYREC = "<table style='width:100%;' id='" + recordSet(3) + "PAYREC' class='secondTable' border='0'><tbody></tbody></table>";
			var tableCCY = "<table style='width:100%;' id='" + recordSet(3) + "CCY' 	  class='secondTable' border='0'><tbody></tbody></table>";
			var tableNOT = "<table style='width:100%;' id='" + recordSet(3) + "NOTIONAL'  class='secondTable' border='0'><tbody></tbody></table>";
			var tableFLOWP = "<table border='0' style='width:100%;' id='" + recordSet(3) + "FLOWPAY' class='secondTable'><tbody></tbody></table>";
			var tableFLOWR = "<table border='0' style='width:100%;' id='" + recordSet(3) + "FLOWREC' class='secondTable'><tbody></tbody></table>";
			var tableRATEP = "<table border='0' style='width:100%;' id='" + recordSet(3) + "RATEPAY' class='secondTable'><tbody></tbody></table>";
			var tableRATER = "<table border='0' style='width:100%;' id='" + recordSet(3) + "RATEREC' class='secondTable'><tbody></tbody></table>";
			/**/
			var content= "<tr class=''>"
						  + "<td class='tdContent'>" + formatCapitalLetter(validateValue(recordSet(0))) + '' + "</td>"
						  + "<td class='tdContent'>" + recordSet(1) + '' + "</td>"
						  + "<td class='tdContent'>" + recordSet(2) + '' + "</td>"
						  + "<td class='tdContent'>" + recordSet(3) + '' + "</td>"
						  + "<td class='tdContent'>" + formatCapitalLetter(validateValue(recordSet(4))) + '' + "</td>"
						  + "<td class='tdContent'>" + formatCapitalLetter(validateValue(recordSet(5))) + '' + "</td>"
						  + "<td class='tdContent'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(6))))),true) + '' + "</td>"
						  + "<td class='tdContent'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(7))))),true) + '' + "</td>"
						  + "<td class='tdContent'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(8))))),true) + '' + "</td>"
						  + "<td class='tdContent' style=' text-align:center;'>" + tablePAYREC + "</td>"
						  + "<td class='tdContent' style=' text-align:center;'>" + tableCCY + "</td>"
						  + "<td class='tdContent' style=' text-align:center;'>" + tableNOT + "</td>"
						  + "<td class='tdContent' style=' text-align:center;'>" + tableFLOWP + tableFLOWR + "</td>"
						  + "<td class='tdContent' style=' text-align:center;'>" + tableRATEP + tableRATER + "</td>"
						  + "<td class='tdContent'>" + (compareString(recordSet(9) + '', 'null') ? "" : recordSet(9) + '') + "</td>"
						  + "<td class='tdContent'>" + (compareString(recordSet(10) + '', 'null') ? "" : recordSet(10) + '') + "</td>"
						  + "<td class='tdContent'>" + (compareString(recordSet(11) + '', 'null') ? "" : recordSet(11) + '') + "</td>"
						  + "<td class='tdContent'>" + (compareString(recordSet(12) + '', 'null') ? "" : recordSet(12) + '') + "</td>"
						  
						  + "<td class='DesactivadoEnviar enviar tdContent'><div class='btn-group'><span class='dropdown-toggle' style='cursor: pointer;' data-toggle='dropdown'><span title='Enviar �rdenes de Pago' class='fa fa-envelope'></span></span><ul class='dropdown-menu' role='menu' style='cursor: pointer;'><li><a class='seleccionarSWAP select' id='SSWAP" + recordSet(3) + "'>Seleccionar</a></li><li><a class='deseleccionarSWAP unselect' id='DSWAP" + recordSet(3) + "'>Desmarcar</a></li><li class='divider'></li><li><a class='enviarActual'>Enviar cliente actual</a></li><li><a class='enviarSeleccionadas desactivado'>Enviar clientes seleccionadas</a></li></ul></div></td>"
						  + "</tr>";
					  
			contenido = contenido + content;
			recordSet.MoveNext();
		}
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();

		var tfoot = "<tfoot class='footerFilter'><tr>";
		for(i = 0;i < 19; i++){tfoot = tfoot + "<td></td>";}
		
		return contenido + "</tbody>" + tfoot + "</tr></tfoot>";
	}
}

//Obtener todos los registros SWAP y ubicarlos donde corresponde
function getAllSwap(){
		try{
	var strConn = stringConnections.strConnectionExpirations;
	var objConnection = new ActiveXObject("adodb.connection");
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = queries.queryGelAllSWAP;
    recordSet.Open(strQuery, objConnection);
	
		
		while(!recordSet.EOF){
			

			var PR = validateValue(recordSet(1));
			
			//Para que al exportar a Excel no deje espacios en blanco
			var totalRows = parseInt(getNumberRows(recordSet(0) + ''));
			if(totalRows == 4){
				// $("#" + recordSet(0) + "PAYREC").append("<tr><td>" + PR + "</td></tr><tr style='display:none'><td>" + PR + "</td></tr>");
				// $("#" + recordSet(0) + "PAYREC").append("<tr><td>" + PR + "</td></tr>");
				// $("#" + recordSet(0) + "CCY").append("<tr><td>" + recordSet(2) + "</td></tr><tr style='display:none'><td>" + recordSet(2) + "</td></tr>");
				// $("#" + recordSet(0) + "CCY").append("<tr><td>" + recordSet(2) + "</td></tr>");
				// $("#" + recordSet(0) + "NOTIONAL").append("<tr><td>" + addCommas(recordSet(3)) + "</td></tr><tr style='display:none'><td>" + addCommas(recordSet(3)) + "</td></tr>");
				$("#" + recordSet(0) + "NOTIONAL").append("<tr><td rowspan='2'>" + addCommas(recordSet(3)) + "</td><tr>");
				$("#" + recordSet(0) + "PAYREC").append("<tr><td rowspan='2'>" + PR + "</td><tr>");
				$("#" + recordSet(0) + "CCY").append("<tr><td rowspan='2'>" + recordSet(2) + "</td><tr>");
			}else{
				$("#" + recordSet(0) + "PAYREC").append("<tr><td>" + PR + "</td></tr>");
				$("#" + recordSet(0) + "CCY").append("<tr><td>" + recordSet(2) + "</td></tr>");
				$("#" + recordSet(0) + "NOTIONAL").append("<tr><td>" + addCommas(recordSet(3)) + "</td></tr>");
			}

			recordSet.MoveNext();
		}
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
	}
}
function getFlowsAndRates(){
	try{
		var strConn = stringConnections.strConnectionExpirations;
		var objConnection = new ActiveXObject("adodb.connection");
		
		objConnection.Open(strConn);
		var recordSet = new ActiveXObject("ADODB.Recordset");
		var strQuery = queries.queryGelAllSRates;
		recordSet.Open(strQuery, objConnection);
		
			
			while(!recordSet.EOF){

				$("#" + recordSet(0) + "FLOW" + recordSet(1)).append("<tr><td style='width:10%;padding-left:5px;padding-right:10px'>" + "<b>" + recordSet(3) + "</b>" +"</td><td style='width:80%;text-align:right'>" + addCommas(parseFloat(recordSet(4)).toFixed(2)) + "</td><td style='padding-left:10px;width:10%;padding-right:5px'>" + recordSet(5) +"</td></tr>");
				$("#" + recordSet(0) + "RATE" + recordSet(1)).append("<tr><td>" + recordSet(2) + "</td></tr>");
		
				
				recordSet.MoveNext();
			}
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
	}
}


function getInfoClient(nit){
	
	var strConn = stringConnections.strConnectionExpirations;
	var objConnection = new ActiveXObject("adodb.connection");
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = replaceAll((queries.queryGetInfoClient), "rNit", nit);
    recordSet.Open(strQuery, objConnection);
	
	var clientInfo = "";
	
	try{
	
			while(!recordSet.EOF){
			
			var email = compareString(recordSet(2) + '','null') ? 'E-mail no encontrado' : recordSet(2) + '';
			var gerente = compareString(recordSet(3) + '','null') ? 'Gerente no encontrado' : formatCapitalLetter(recordSet(3)) + '';
			var unidad = compareString(recordSet(4) + '','null') ? 'Unidad no encontrada' : recordSet(4) + '';
			var banca = compareString(recordSet(5) + '','null') ? 'Banca no encontrada' : recordSet(5) + '';
			var segmento = compareString(recordSet(6) + '','null') ? 'Segmento no encontrado' : recordSet(6) + '';
			var region = compareString(recordSet(7) + '','null') ? 'Regi�n no encontrada' : recordSet(7) + '';
			var trader = compareString(recordSet(8) + '','null') ? 'Trader no encontrado' : recordSet(8) + '';
			
			
				clientInfo += "<div style='text-align:center'>" +
									"<table border='0' style='font-family:Arial;border-collapse:collapse'>" +
										"<tr>" +
											"<th colspan='2' style='text-align:center;font-weight:normal;font-size:17'><b>" + recordSet(0) + "</b></th>" +
										"</tr>" +
										"<tr>" +
											"<td colspan='2' style='text-align:center'>" + recordSet(1) + "</td>" +
										"</tr>" +
										
										"<tr>" +
											"<td colspan='2' style='text-align:center'>" + email + "</td>" +
										"</tr>" +
										
										"<tr style='padding-bottom:0em'>" +
											"<th>Gerente:</th>" +
											"<td>" + gerente + ' -- ' + unidad + "</td>" +
										"</tr>" +
										"<tr style='padding-bottom:0em'>" +
											"<th>Geograf�a:</th>" +
											"<td>" + banca + ' / ' + segmento + ' / ' + region + "</td>" +
										"</tr>" +
										"<tr style='padding-bottom:0em'>" +
											"<th>Trader:</th>" +
											"<td>" + trader + "</td>" +
										"</tr>" +
									"</table>" +
								"</div>";
			
				recordSet.MoveNext();
			}
			
			
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
		return clientInfo;
	}
}
	
	// var wasCurrentElement = false;
function getOperationsFWD(nit){
	
	// wasCurrentElement = true;
	var strConn = stringConnections.strConnectionExpirations;
	var objConnection = new ActiveXObject("adodb.connection");
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = replaceAll((queries.queryGetOperationsFWD), "rNit", nit);
	var strQuery = replaceAll(strQuery, "rProducto" , "FORWARD");
    recordSet.Open(strQuery, objConnection);
	
	var clientOperations = "";
	var count = 0;
	try{
	
		// var fwdOperation = "<tr style='width:100%;background:rgb(51,122,183)'><th colspan='10' style='font-size:18;height:35px;color:white'>FORWARD</th></tr><tr style='background-color:rgb(245,245,245);color: rgb(32,56,100);font-size:15'><i><th style='padding:7px'>N�mero<br>Operaci�n</th><th style='padding:7px'>Monto</th><th style='padding:7px'>Par</th><th style='padding:7px'>Modalidad</th><th style='padding:7px'>Operaci�n</th><th style='padding:7px'>Tasa<br>Forward</th><th style='padding:7px'>Fecha<br>de Cierre</th><th style='padding:7px'>Fecha<br>Vencimiento</th><th style='padding:7px'>Fecha<br>Cumplimiento</th><th style='padding:7px'>Moneda<br>Cumplimiento</th></tr></i></thead><tbody>";
		var fwdOperation = "<tr style='width:100%;background:rgb(51,122,183)'><th colspan='13' style='font-size:18;height:35px;color:white'>FORWARD</th></tr><tr style='background-color:rgb(245,245,245);color: rgb(32,56,100);font-size:15'><i><th style='padding:7px'>N�mero<br>Operaci�n</th><th style='padding:7px'>Monto</th><th colspan='2' style='padding:7px'>Par</th><th style='padding:7px'>Modalidad</th><th style='padding:7px'>Operaci�n</th><th style='padding:7px'>Tasa<br>Forward</th><th colspan='2' style='padding:7px'>Fecha<br>de Cierre</th><th colspan='2' style='padding:7px'>Fecha<br>Vencimiento</th><th colspan='2' style='padding:7px'>Fecha<br>Cumplimiento</th></tr></i></tr>";
			
			while(!recordSet.EOF){
			
					var PR = validateValue(recordSet(5));
					fwdOperation += "<tr style='text-align:center'>" +
									"<td style='padding:7px'>" + "000" + recordSet(1) + "</td>" +
									"<td style='padding:7px'>" + addCommas(recordSet(2) + '') + "</td>" +
									"<td colspan='2' style='padding:7px'>" + recordSet(3) + "</td>" +
									"<td style='padding:7px'>" + validateValue(recordSet(4)) + "</td>" +
									// "<td>" + recordSet(5) + "</td>" +
									"<td style='padding:7px'>" + PR + "</td>" +
									"<td style='padding:7px'>" + addCommas(recordSet(7)) + "</td>" +
									"<td colspan='2' style='padding:7px'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(8))))),true) + "</td>" +
									"<td colspan='2' style='padding:7px'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(9))))),true) + "</td>" +
									"<td colspan='2' style='padding:7px'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(10))))),true) + "</td>" +
									// "<td style='padding:7px'>" + recordSet(6) + "</td>" +
									"</tr>";
				count++;
				recordSet.MoveNext();
			}
			// fwdOperation += "</body></table></div>";
			fwdOperation += "";
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
		return count != 0 ? fwdOperation + "": "";
	}
}

function getOperationsOPT(nit){
	
	// wasCurrentElement = true;
	var strConn = stringConnections.strConnectionExpirations;
	var objConnection = new ActiveXObject("adodb.connection");
	
    objConnection.Open(strConn);
	var recordSet = new ActiveXObject("ADODB.Recordset");
	var strQuery = replaceAll((queries.queryGetOperationsOPT), "rNit", nit);
	var strQuery = replaceAll(strQuery, "rProducto" , "OPCIONES");
    recordSet.Open(strQuery, objConnection);
	
	var clientOperations = "";
	var count = 0;
	try{
	
		// var optOperation = "<tr style='width:100%;background:rgb(51,122,183)'><th colspan='10' style='font-size:18;height:35px;color:white'>OPCIONES</th></tr><tr style='background-color:rgb(245,245,245);color: rgb(32,56,100);font-size:15'><i><th style='padding:7px'>N�mero<br>Operaci�n</th><th style='padding:7px'>Monto</th><th style='padding:7px'>Operaci�n</th><th style='padding:7px'>Tipo</th><th style='padding:7px'>Modalidad</th><th style='padding:7px'>Strike</th><th style='padding:7px'>Fecha<br>Inicio</th><th style='padding:7px'>Fecha<br>Vencimiento</th><th style='padding:7px'>Fecha<br>Cumplimiento</th><th style='padding:7px'>Moneda<br>Cumplimiento</th></i></tr>";
		var optOperation = "<tr style='width:100%;background:rgb(51,122,183)'><th colspan='13' style='font-size:18;height:35px;color:white'>OPCIONES</th></tr><tr style='background-color:rgb(245,245,245);color: rgb(32,56,100);font-size:15'><i><th style='padding:7px'>N�mero<br>Operaci�n</th><th style='padding:7px'>Monto</th><th colspan='2' style='padding:7px'>Operaci�n</th><th style='padding:7px'>Tipo</th><th style='padding:7px'>Modalidad</th><th style='padding:7px'>Strike</th><th colspan='2' style='padding:7px'>Fecha<br>de Cierre</th><th colspan='2' style='padding:7px'>Fecha<br>Vencimiento</th><th colspan='2' style='padding:7px'>Fecha<br>Cumplimiento</th></i></tr>";
			
			while(!recordSet.EOF){
			
					
					optOperation += "<tr style='text-align:center'>" +
									"<td style='padding:7px'>" + recordSet(1) + "</td>" +
									"<td style='padding:7px'>" + addCommas(recordSet(2) + '') + "</td>" +
									"<td colspan='2' style='padding:7px'>" + validateValue(recordSet(3)) + "</td>" +
									"<td style='padding:7px'>" + formatCapitalLetter(recordSet(4)) + "</td>" +
									"<td style='padding:7px'>" + formatCapitalLetter(recordSet(5)) + "</td>" +
									"<td style='padding:7px'>" + addCommas(recordSet(6)) + "</td>" +
									"<td colspan='2' style='padding:7px'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(8))))),true) + "</td>" +
									"<td colspan='2' style='padding:7px'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(9))))),true) + "</td>" +
									"<td colspan='2' style='padding:7px'>" + formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSet(10))))),true) + "</td>" +
									// "<td style='padding:7px'>" + recordSet(7) + "</td>" +
									"</tr>";
				count++;
				recordSet.MoveNext();
			}
			// optOperation += "</body></table></div>";
			optOperation += "";
	}catch(e){
		alert(e.message);
	}finally{
		recordSet.close();
		objConnection.close();
		return count != 0 ? optOperation + "" : "";
	}
}

function getOperationSW(nit){
	
	// wasCurrentElement = true;
	var strConnSW = stringConnections.strConnectionExpirations;
	var objConnectionSW = new ActiveXObject("adodb.connection");
	
    objConnectionSW.Open(strConnSW);
	var recordSetSW = new ActiveXObject("ADODB.Recordset");
	var strQuerySW = replaceAll((queries.queryGetTotalRows), "rNit", nit);
    recordSetSW.Open(strQuerySW, objConnectionSW);
	var multipleRows = "<tr style='width:100%;background:rgb(51,122,183)'><th colspan='13' style='font-size:18;height:35px;color:white'>SWAP</th><tr style='background-color:rgb(245,245,245);color: rgb(32,56,100);font-size:15'><i>"
			+ "<th  style='padding:7px'>N�mero<br>Operaci�n</th>"
			+ "<th style='padding:7px'>Operaci�n</th>"
			+ "<th colspan='2'style='padding:7px'>Monto</th>"
			+ "<th style='padding:7px'>Tipo</th>"
			+ "<th style='padding:7px'>Modalidad</th>"
			+ "<th colspan='3' style='padding:7px'>Flujo</th>"
			+ "<th style='padding:7px'>Tasa</th>"
			+ "<th style='padding:7px'>Fecha<br>de Cierre</th>"
			+ "<th style='padding:7px'>Fecha<br>Vencimiento</th>"
			+ "<th style='padding:7px'>Fecha<br>Cumplimiento</th>"
			+ "</i></tr>";
	var count = 0;
	try{


			while(!recordSetSW.EOF){
				multipleRows += getDataOperation(recordSetSW(0) + '', parseInt(recordSetSW(1)+''));
			count++;
			recordSetSW.MoveNext();
			}
			
	}catch(e){
		alert(e.message);
	}finally{
		recordSetSW.close();
		objConnectionSW.close();
		return count != 0 ? multipleRows : "";
	}
}	

function getDataOperation(nOperation, nRows){
	
	// wasCurrentElement = true;
	var strConnSWO = stringConnections.strConnectionExpirations;
	var objConnectionSWO = new ActiveXObject("adodb.connection");
	
    objConnectionSWO.Open(strConnSWO);
	var recordSetSWO = new ActiveXObject("ADODB.Recordset");
	var strQuerySWO = replaceAll((queries.queryGetDataOperation), "rOperation", nOperation);
    recordSetSWO.Open(strQuerySWO, objConnectionSWO);
	var count = 0;
	 
	var row = "";
			
	try{

			while(!recordSetSWO.EOF){
				var NOper = recordSetSWO(0),//N�mero de Operaci�n 
					PoR = validateValue(recordSetSWO(1)),//PAY o REC 
					Nal = addCommas(parseFloat(recordSetSWO(2)).toFixed(2)),//Notional 
					TiP = formatCapitalLetter(recordSetSWO(3)),//Tipo producto (CCS o IRS) 
					Mod = validateValue(recordSetSWO(4)),//Modalidad 
					TiF = validateFlowType(recordSetSWO(5)),// Tipo flujo
					Fl = addCommas(parseFloat(recordSetSWO(6)).toFixed(2)),//Flujo
					Ts = recordSetSWO(7),//Tasa
					If = formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSetSWO(8))))),true),//Inicio flujo
					Ff = formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSetSWO(9))))),true),//Fin flujo
					Cf = formatDate(($.datepicker.formatDate('dd/mm/yy',(new Date(recordSetSWO(10))))),true),//Cumplimiento flujo
					MM = recordSetSWO(11),//Moneda monto
					MF = recordSetSWO(12); //Moneda flujo
				
				if(nRows == 4){
					if(count == 0){
						row += "<tr style='text-align:center'><td style='padding:7px' rowspan='4'>" + NOper + "</td><td style='padding:7px' rowspan='2'>" + PoR + "</td><td style='padding:7px' rowspan='2'>" + Nal + "</td><td style='padding:7px' rowspan='2'>" + MM + "</td><td style='padding:7px' rowspan='4'>" + TiP + "</td><td style='padding:7px' rowspan='4'>" + Mod + "</td><td style='padding:7px' >" + TiF + "</td><td style='padding:7px' >" + Fl + "</td><td style='padding:7px' >" + MF + "</td><td style='padding:7px' >" + Ts + "</td><td style='padding:7px' rowspan='4'>" + If + "</td><td style='padding:7px' rowspan='4'>" + Ff + "</td><td style='padding:7px' rowspan='4'>" + Cf + "</td></tr>";
					}else if(count == 1){
						row += "<tr style='text-align:center'><td style='padding:7px'>" + TiF + "</td><td style='padding:7px'>" + Fl + "</td><td style='padding:7px'>" + MF + "</td><td style='padding:7px'>" + Ts + "</td></tr>";
					}else if(count == 2){
						row += "<tr style='text-align:center'><td style='padding:7px' rowspan='2'>" + PoR + "</td><td style='padding:7px' rowspan='2'>" + Nal + "</td><td style='padding:7px' rowspan='2'>" + MM + "</td><td style='padding:7px'>" + TiF + "</td><td style='padding:7px'>" + Fl + "</td><td style='padding:7px'>" + MF + "</td><td style='padding:7px'>" + Ts + "</td></tr>";
					}else if(count == 3){
						row += "<tr style='text-align:center'><td style='padding:7px'>" + TiF + "</td><td style='padding:7px'>" + Fl + "</td><td style='padding:7px'>" + MF + "</td><td style='padding:7px'>" + Ts + "</td></tr>";
					}
				}else if(nRows == 2){
					if(count == 0){
						row += "<tr style='text-align:center'><td style='padding:7px' rowspan='2'>" + NOper + "</td><td style='padding:7px'>" + PoR + "</td><td style='padding:7px'>" + Nal + "</td><td style='padding:7px'>" + MM + "</td><td style='padding:7px' rowspan='2'>" + TiP + "</td><td style='padding:7px' rowspan='2'>" + Mod + "</td><td style='padding:7px'>" + TiF + "</td><td style='padding:7px'>" + Fl + "</td><td style='padding:7px'>" + MF + "</td><td style='padding:7px'>" + Ts + "</td><td style='padding:7px' rowspan='2'>" + If + "</td><td style='padding:7px' rowspan='2'>" + Ff + "</td><td style='padding:7px' rowspan='2'>" + Cf + "</td></tr>";
					}else if(count == 1){
						row += "<tr style='text-align:center'><td style='padding:7px'>" + PoR + "</td><td style='padding:7px'>" + Nal + "</td><td style='padding:7px'>" + MM + "</td><td style='padding:7px'>" + TiF + "</td><td style='padding:7px'>" + Fl + "</td><td style='padding:7px'>" + MF + "</td><td style='padding:7px'>" + Ts + "</td></tr>";
				}
					}
			recordSetSWO.MoveNext();
			count++;
			}
	}catch(e){
		alert(e.message);
	}finally{
		recordSetSWO.close();
		objConnectionSWO.close();
		return count != 0 ? row : "";
	}
}

function getNumberRows(rOperation){
	// rOperation += '';
	var result = "";
	try{
		var strConnCount = stringConnections.strConnectionExpirations;
		var objConnectionCount = new ActiveXObject("adodb.connection");
		
		objConnectionCount.Open(strConnCount);
		var recordSetCount = new ActiveXObject("ADODB.Recordset");
		var strQueryCount = replaceAll((queries.queryGetNumberRows),"rOperation", rOperation);
		recordSetCount.Open(strQueryCount, objConnectionCount);
		
			
			while(!recordSetCount.EOF){
				result += recordSetCount(0);
				recordSetCount.MoveNext();
			}
	}catch(e){
		alert(e.message);
	}finally{
		recordSetCount.close();
		objConnectionCount.close();
		//alert(result);
		return result;
	}
}