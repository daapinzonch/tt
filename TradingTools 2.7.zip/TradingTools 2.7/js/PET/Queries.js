function reactiveCustomer(connection, command, recordSet, stringConnection, nit){
	var query = replaceAll(queries.queryUpdateReactiveCustomers, 'R_NIT', nit);	
	var query2 = replaceAll(queries.queryDeleteReactiveCustomers, 'R_NIT', nit);
	
	if (develop){
		console.log("Query actualiza Descartado 0:  " + query);
		console.log("Query Elimina:  " + query2);
	} else{
		if (!update(query, stringConnection, connection, command)){
			alert("Error al intentar Reactivar este Cliente");
		} else{
			if(!deleteDB(query2, stringConnections.strConnectionPET, connection)){
				alert("Error al intentar Reactivar este Cliente");
			} else{
				$("#discard-customers-table").DataTable().destroy();
				resetModal([["#discard-customers-table", "container"]]);
				buildTable(["Fecha Desc", "Nit", "Cliente", "Trader", "Observacion", "Acci�n"], getDiscardCustomers(connection, recordSet, stringConnections.strConnectionPET, replaceAll(queries.queryDiscardCustomers, 'R_USUARIOS', usersToShowMe)), "#discard-customers-table");
				$("#discard-customers-table").DataTable({"ordering": false});
				showBootstrapDialog("Informaci�n", "Se reactiv� satisfactoriamente el cliente, Por favor actualice el m�dulo para ver reflejado este cambio", "PRIMARY", "ALERT", "NORMAL");
			}
		}
	}
}

function updateVisitStatus(connection, command, recordSet, stringConnection, selector){
	var nit = $(selector).parent().parent().children().eq(1).text().trim();
	var status = $(selector).text().trim();
	
	var statuses = ["En Proceso", "Declinada", "Realizada"];
	var nextStatusIndex = statuses.indexOf(status) == statuses.length - 1 ? 0 : statuses.indexOf(status) + 1
	var nextStatus = statuses[nextStatusIndex];
	var query = replaceAll(replaceAll(queries.queryUpdateVisitStatus, "R_NIT", nit), "R_ESTADO", nextStatus);
	
	if (develop){
		console.log("Query actualiza estado de visita: " + query);
	} else{
		if (!update(query, stringConnection, connection, command)){
			alert("Error al intentar actualizar el estado de la visita");
		} else{
			$(selector).html(nextStatus + " <i class='fa fa-refresh'></i>");
		}
	}
}

function searchCustomer(nit){
	var spreads = [];
	var status = true;
	
	var query = replaceAll(queries.queryDetalleCliente, 'R_NIT', nit);
	//showBootstrapDialog("Informaci�n", query ,"DANGER", "ALERT", "NORMAL");
	getGeographyInformation(connection, recordSet, stringConnections.strConexionDataMart, query);

	query = replaceAll(queries.queryPptoCliente, 'R_NIT', nit);
	getBudget(connection, recordSet, stringConnections.strConnectionPET, query);
	
	query = replaceAll(queries.queryinfoPetCliente, 'R_CRITERIO', "Nit='" + nit + "'");
	getCustomerInformation(connection, recordSet, stringConnections.strConnectionPET, query, "");
	
	query = replaceAll(queries.queryinfoPetCliente, 'R_CRITERIO', "Nit_Grupo='" + $("#group-nit-info-modal").text().trim() + "'");
	getCustomerInformation(connection, recordSet, stringConnections.strConnectionPET, query, "group-");
	
	query = replaceAll(queries.queryStrategiesInfo, 'R_NIT', nit);
	getStrategiesInfo(connection, recordSet, stringConnections.strConnectionPET, query);
	
	query = replaceAll(queries.querySpreads, 'R_NIT', nit);
	//showBootstrapDialog("Informaci�n", query ,"DANGER", "ALERT", "NORMAL");
	spreads = getSpreads(connection, recordSet, stringConnections.strConexionDataMart, query);
	showSpreads(spreads);
}

function discardCustomer(){
		var idTable = "#" + $("#hidden-id-modal").attr('class');
		var type = $("#hidden-type-modal").attr('class');
		var nit = $("#discard-nit-modal").text();
		var strategy = "DescartadoCliente";
		var reason = $("#discard-type-modal").val();
		var observation = compareString($("#discard-reason-customer-modal").val(), "Otra, cual?") || compareString($("#discard-reason-bank-modal").val(), "Otra, cual?") ? $("#discard-observation-modal").val() : (compareString(reason, "Cliente") ? $("#discard-reason-customer-modal").val() : (compareString(reason, "Banco") ? $("#discard-reason-bank-modal").val() : "NULL"));
		var area = "Tesorer�a";
		var query1 = replaceAll(queries.queryDespriorizarCliente, "R_NIT", nit);
		var query2 = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracion, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
		
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea descartar este cliente?", "DANGER", "CONFIRM", "SMALL", function(result){if(result){ 
			if (develop){
				console.log("Query desprioriza likes (descarte): " + query1);
				console.log("Query descartado en valoracion (descarte): " + query2);
			} else{
				if (!update(query1, stringConnections.strConnectionPET, connection, command)){
					alert("Error al intentar actalizar DescarteClientes");
				} else{
					if (!insert(query2, stringConnections.strConnectionPET, connection)){
						alert("Error al intentar insertar DescarteClientes");
					} else{
						destroyPetTable(idTable, type);
						removeClass("#hidden-id-modal", $("#hidden-id-modal").attr('class'));
						removeClass("#hidden-type-modal", $("#hidden-type-modal").attr('class'));
						$("#discard-modal").modal('hide');
						showBootstrapDialog("Informaci�n", "El cliente se descart� exitosamente", "PRIMARY", "ALERT", "NORMAL");
					}
				}
			}
		
		}});
}

function activeStrategy(selector){
	var strategy = $(selector).parent().attr("value");
	var nit = $(selector).parent().parent().children().eq(0).text().trim();
	var type = $(selector).attr("value");
	var s1 = compareString(strategy, "Cobertura") ? 1 : 0;
	var s2 = compareString(strategy, "Swap_IBR") ? 1 : 0;
	var s3 = compareString(strategy, "Sinteticos") ? 1 : 0;
	var s4 = compareString(strategy, "Opciones") ? 1 : 0;
	var s5 = compareString(strategy, "Internet") ? 1 : 0;
	var s6 = compareString(strategy, "Divisas") ? 1 : 0;
	var trader = (users.currentUser).toUpperCase();
	
	var query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryCrearEstrategia, 'R_NIT', nit), 'R_COBERTURA', s1), 'R_SWAP_IBR', s2), 'R_OPCIONES', s4), 'R_INTERNET', s5), 'R_SINTETICOS', s3), 'R_DIVISAS', s6), 'R_TRADER', trader);
	
	if (develop){
		console.log("Query inserta en habilitaciones: " + query);
		console.log("Query actualiza peso: " + replaceAll(queries.queryAumentaPeso, 'R_NIT', nit));
	} else{
		if (!insert(query, stringConnections.strConnectionPET, connection)){
			alert("Ocurri� un error al intentar habilitar esta estrategia");
		} else{
			query = replaceAll(queries.queryAumentaPeso, 'R_NIT', nit);
			
			if (!update(query, stringConnections.strconnectionPET, connection, command)){
				alert("error al intentar actalizar el nuevo peso del cliente");
			}
			
			$(selector).parent().html("<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>");
		}
	}
}

function scheduleVisit(selector){
	var row = $(selector).parent().parent().children();
	
	var nit = row.eq(0).text().trim();
	var customer = row.eq(1).text();
	var type = row.eq(2).text();
	var trader = row.eq(4).text();
	var visit = row.eq(5).children().eq(0).val();
	var date = row.eq(6).children().eq(0).val();
	var state = "En Proceso";
	var area = "Tesoreria";
	var error = validateDateInput(date);

	if (develop){
		console.log("Query Actualiza Campo Agendados:  " + replaceAll(queries.queryUpdateSchedule, 'R_NIT', nit));
		console.log("Query Sin replace: " + queries.queryInsertSchedule);
		console.log("Query Inserta Visita:  " + replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryInsertSchedule, 'R_NIT', nit), 'R_CLIENTE', customer), 'R_FECHA', date), 'R_TRADER', trader), 'R_VISITA', visit), 'R_ESTADO', state), 'R_AREA', area));
	} else{
		if (!compareString(error, "")){
			showBootstrapDialog("Informaci�n", error, "WARNING", "ALERT", "NORMAL");
		} else{
			var query = replaceAll(queries.queryUpdateSchedule, 'R_NIT', nit);
			
			if (!update(query, stringConnections.strConnectionPET, connection, command)){
				alert("Error al intentar actualizar la agenda de este Cliente");
			} else{
				query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryInsertSchedule, 'R_NIT', nit), 'R_CLIENTE', customer), 'R_FECHA', date), 'R_TRADER', trader), 'R_VISITA', visit), 'R_ESTADO', state), 'R_AREA', area);
				
				if (!insert(query, stringConnections.strConnectionPET, connection, command)){
					alert("Error al intentar Agendar la visita de este Cliente");
				} else{
					var nits = [];
					
					$("#schedule-customers-table").DataTable().destroy();
					resetModal([["#schedule-customers-table", "container"]]);
					buildTable(["Nit", "Cliente", "Tipo", "Estrategia", "Trader", "Tipo Visita", "Fecha Estimada", "Acci�n"], getScheduleCustomers(connection, recordSet, stringConnections.strConnectionPET, replaceAll(queries.queryScheduleCustomers, 'R_USUARIOS', usersToShowMe), nits), "#schedule-customers-table");
					instanceDatepickers(nits);
					$("#schedule-customers-table").DataTable({"ordering": false});
					showBootstrapDialog("Informaci�n", "Se cre� la visita satisfactoriamente", "PRIMARY", "ALERT", "NORMAL");
					$("#schedule-customers-modal").modal("show");		
					
				}
			}
			
		}
	}
}

function deleteVisits(connection, command, recordSet, stringConnection, nit){
	var query = replaceAll(queries.queryUpdateVisits, 'R_NIT', nit);	
	var query2 = replaceAll(queries.queryDeleteVisits, 'R_NIT', nit);
	
	if (develop){
		console.log("Query Actualiza Agendados 0:  " + query);
		console.log("Query Elimina:  " + query2);
	} else{
		if (!update(query, stringConnection, connection, command)){
			alert("Error al intentar Actualizar esta visita");
		} else{
			if(!deleteDB(query2, stringConnection, connection)){
				alert("Error al intentar Eliminar esta visita");
			} else{
				$("#visits-table").DataTable().destroy();
				resetModal([["#visits-table", "container"]]);
				buildTable(["Fecha Creaci�n", "Nit", "Cliente", "Fecha Estimada", "Trader", "Tipo Visita", "Estado", "Acci�n"], getVisits(connection, recordSet, stringConnection, replaceAll(queries.queryVisits, 'R_USUARIOS', replaceAll(replaceAll(usersToShowMe, "AND ", ""), "PET_NitEstrategias.", ""))), "#visits-table");
				$("#visits-table").DataTable({"ordering": false});
		
				$("#visits-modal").modal("show");
				showBootstrapDialog("Informaci�n", "Se elimin� satisfactoriamente esta visita", "PRIMARY", "ALERT", "NORMAL");
			}
		}
	}
}

function getCustomerInformation(connection, recordSet, stringConnection, query, type){
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			addClass($("#" + type + "exp-camb"), recordSet(3).Value < 0 ? "error" : "");
			addClass($("#" + type + "wallet-sha"), recordSet(5).Value < 0 ? "error" : "");
		
			$("#" + type + "impo").text(!compareString(isInvalid(recordSet(0).Value + "", ""), "") ? addCommas(parseFloat(recordSet(0).Value.toFixed(0))) : "");
			$("#" + type + "expo").text(!compareString(isInvalid(recordSet(1).Value + "", ""), "") ? addCommas(parseFloat(recordSet(1).Value.toFixed(0))) : "");
			$("#" + type + "cart-ibr").text(!compareString(isInvalid(recordSet(2).Value + "", ""), "") ? addCommas(parseFloat(recordSet(2).Value.toFixed(0))) : "");
			$("#" + type + "exp-camb").text(!compareString(isInvalid(recordSet(3).Value + "", ""), "") ? addCommas(parseFloat(recordSet(3).Value.toFixed(0))) : "");
			$("#" + type + "vol-neg").text(!compareString(isInvalid(recordSet(4).Value + "", ""), "") ? addCommas(parseFloat(recordSet(4).Value.toFixed(0))) : "");
			$("#" + type + "wallet-sha").text(!compareString(isInvalid(recordSet(5).Value + "", ""), "") ? addCommas(parseFloat(recordSet(5).Value.toFixed(0))) : "");
			$("#" + type + "cart-ml").text(!compareString(isInvalid(recordSet(6).Value + "", ""), "") ? addCommas(parseFloat(recordSet(6).Value.toFixed(0))) : "");
			$("#" + type + "cart-me").text(!compareString(isInvalid(recordSet(7).Value + "", ""), "") ? addCommas(parseFloat(recordSet(7).Value.toFixed(0))) : "");

			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
}

function getDiscardCustomers(connection, recordSet, stringConnection, query){
	var tbody = "<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var date = new Date(recordSet(2).Value);
			var dateFormat = date.getDate() + " " + convertNumericMonthToStringMonth(date.getMonth() + 1) + " " + date.getFullYear();
			var nit = recordSet(0).Value.trim();
			var customer = recordSet(1).Value;
			var observations = recordSet(3).Value;
			var trader = recordSet(4).Value;
			var action = "<a class='reactive'>Reactivar <i class='fa fa-undo'></i></a>";
			
			tbody = tbody + "<tr><td>" + dateFormat + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + trader + "</td><td>" + observations + "</td><td>" + action + "</td></tr>";
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return tbody;
}

function getScheduleCustomers(connection, recordSet, stringConnection, query, nits){
	var tbody = "<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			nits.push(recordSet(0).Value.trim());
			
			var nit = recordSet(0).Value.trim();
			var customer = recordSet(1).Value.trim();
			var type = recordSet(2).Value.trim();
			var trader = recordSet(3).Value.trim();
			var strategies = recordSet(4).Value.trim();
			var visit = "<select class='form-control'><option>Teleconferencia</option><option>Webex</option><option>Presencial</option></select>"
			var date = "<input type='text' id='" + nit + "' class='form-control' placeholder='Selecciona Fecha'>"
			var action = "<a class='schedule'>Agendar <i class='fa fa-calendar'></i></a><br><a class='pipeline' href='Pipeline.html???" + strategies + "???" + nit + "' target='_blank'>Pipeline <i class='fa fa-bar-chart-o'></i></a>";
	
			tbody = tbody + "<tr><td>" + nit + "</td><td>" + customer + "</td><td>" + type + "</td><td>" + strategies + "</td><td>" + trader + "</td><td>"  + visit + "</td><td>" + date + "</td><td>" + action + "</td></tr>";
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return tbody;
}

function getVisits(connection, recordSet, stringConnection, query){
	var tbody = "<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var creationDate = (new Date(recordSet(0).Value));
			var creationDateFormat = creationDate.getDate() + " " + convertNumericMonthToStringMonth(creationDate.getMonth() + 1) + " " + creationDate.getFullYear();
			var nit = recordSet(1).Value;
			var customer = recordSet(2).Value;
			var estimatedDate = recordSet(3).Value;
			var estimatedDate = (new Date(recordSet(3).Value));
			var estimatedDateFormat = estimatedDate.getDate() + " " + convertNumericMonthToStringMonth(estimatedDate.getMonth() + 1) + " " + estimatedDate.getFullYear();
			var trader = recordSet(4).Value;
			var visit = recordSet(5).Value;
			var status = "<a class='status'>" + recordSet(6).Value + " <i class='fa fa-refresh'></i></a>";
			var action = "<a class='delete-visit'>Eliminar <i class='fa fa-times'></i></a>";
			
			tbody = tbody + "<tr><td>" + creationDateFormat + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + estimatedDateFormat + "</td><td>" + trader + "</td><td>" + visit + "</td><td>" + status + "</td><td>" + action + "</td></tr>";
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return tbody;
}

function getStrategiesInfo(connection, recordSet, stringConnection, query){
	var strategies = [];
	var reasons = [];
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		var cobertura = recordSet(0).Value;
		var swap = recordSet(1).Value;
		var opciones = recordSet(2).Value;
		var internet = recordSet(3).Value;
		var sinteticos = recordSet(4).Value;
		var divisas = recordSet(5).Value;
		
		var coberturaEnabled = recordSet(8).Value;
		var swapEnabled = recordSet(9).Value;
		var opcionesEnabled = recordSet(10).Value;
		var internetEnabled = recordSet(11).Value;
		var sinteticosEnabled = recordSet(12).Value;
		var divisasEnabled = recordSet(13).Value;

		while (!recordSet.EOF){
			if(!compareString(recordSet(6).Value, "No")) strategies.push(recordSet(6).Value);
			if(!compareString(recordSet(7).Value, "No")) reasons.push(recordSet(7).Value);

			recordSet.MoveNext();
		}

		// Put All Strategies
		[[cobertura, coberturaEnabled, "Cobertura"],[swap, swapEnabled, "Swap IBR"], [opciones, opcionesEnabled, "Opciones"], [internet, internetEnabled, "Internet"], [sinteticos, sinteticosEnabled, "Sint�ticos"], [divisas, divisasEnabled, "Divisas"]].forEach(function(e){$("#stra-apply").append(e[0] == 0 ? "" : (e[1] == 1 ? "<span class='info'>" + e[2] + " (H)</span><br>" : "<span class='info'>" + e[2] + "</span><br>"))});
		
		// Put Priorizate/Despriorizate Strategies
		for (var i = 0; i < strategies.length; i++){
			//$(reasons[i] == "Descartado" ? "#stra-desprio" : (reasons[i] == "AceptadoTrader" ? "#stra-prio" : "")).append("<span class='info'> "+ strategies[i] +" </span><br>")
			reasons[i] == "Descartado" ? $("#stra-desprio").append("<span class='info error'> "+ strategies[i] +" </span><br>") : reasons[i] == "AceptadoTrader" ? $("#stra-prio").append("<span class='info'> "+ strategies[i] +" </span><br>") : "";
		}
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

function getSpreads(connection, recordSet, stringConnection, query){
	var spreads = [];

	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
	
		while (!recordSet.EOF){
			spreads.push([recordSet(0).Value, (compareString(recordSet(1).Value, "No Internet") ? "" : recordSet(1).Value), parseFloat(Math.round(recordSet(2).Value * 100) / 100).toFixed(2), parseFloat(Math.round(recordSet(3).Value * 100) / 100).toFixed(2), parseFloat(Math.round(recordSet(4).Value * 100) / 100).toFixed(2)]);
			
			recordSet.MoveNext();
		}
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return spreads;
}

function getBudget(connection, recordSet, stringConnection, query){
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			addClass($("#brecha-ing-div"), recordSet(4).Value < 0 ? "error" : "");
			addClass($("#brecha-ing-der"), recordSet(5).Value < 0 ? "error" : "");
			
			$("#ppto-ing-div").text(!compareString(isInvalid(recordSet(0).Value + "", ""), "") ? addCommas(parseFloat(recordSet(0).Value.toFixed(0))) : "");
			$("#ppto-ing-der").text(!compareString(isInvalid(recordSet(1).Value + "", ""), "") ? addCommas(parseFloat(recordSet(1).Value.toFixed(0))) : "");
			$("#ejec-ing-div").text(!compareString(isInvalid(recordSet(2).Value + "", ""), "") ? addCommas(parseFloat(recordSet(2).Value.toFixed(0))) : "");
			$("#ejec-ing-der").text(!compareString(isInvalid(recordSet(3).Value + "", ""), "") ? addCommas(parseFloat(recordSet(3).Value.toFixed(0))) : "");
			$("#brecha-ing-div").text(!compareString(isInvalid(recordSet(4).Value + "", ""), "") ? addCommas(parseFloat(recordSet(4).Value.toFixed(0))) : "");
			$("#brecha-ing-der").text(!compareString(isInvalid(recordSet(5).Value + "", ""), "") ? addCommas(parseFloat(recordSet(5).Value.toFixed(0))) : "");
			$("#cumpl-ing-div").text(!compareString(isInvalid(recordSet(6).Value + "", ""), "") ? addCommas(parseFloat(recordSet(6).Value.toFixed(0))) : "");
			$("#cumpl-ing-der").text(!compareString(isInvalid(recordSet(7).Value + "", ""), "") ? addCommas(parseFloat(recordSet(7).Value.toFixed(0))) : "");
			
			recordSet.MoveNext();
		}
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

function getStrategies(connection, recordSet, stringConnection, query, type){
	var strategiesHtml = "<tbody>";
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var nit = recordSet(0).Value;
			var customer = recordSet(1).Value;
			var ppto = recordSet(3).Value <= 80 ? "<i class='fa fa-circle ppto-bad' data-toggle='tooltip' data-placement='left' title= "+ recordSet(3).Value.toFixed(2) + '%' + "></i>" : ( recordSet(3).Value < 100 ? "<i class='fa fa-circle ppto-regular' data-toggle='tooltip' data-placement='left' title= "+ recordSet(3).Value.toFixed(2) + '%' + "></i>" : (recordSet(3).Value >= 100 ? "<i class='fa fa-circle ppto-good' data-toggle='tooltip' data-placement='left' title= "+ recordSet(3).Value.toFixed(2) + '%' + "></i>" : ""));
			var strategy1 = recordSet(2).Value == 9999 ? "<i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : (recordSet(2).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>");
			var strategy2 = recordSet(4).Value == 9999 ? "<i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(4).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var strategy3 = recordSet(5).Value == 9999 ? "<i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(5).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var strategy4 = recordSet(6).Value == 9999 ? " <i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(6).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var strategy5 = recordSet(7).Value == 9999 ? " <i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(7).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'> <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var strategy6 = recordSet(11).Value == 9999 ? "<i class='hidden'>2</i> <i class='fa fa-check-square-o done' title='Evaluado'></i>" : recordSet(11).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'> <i class='fa fa-plus' title='Habilitar'></i> <i class='hidden'>1</i></a>";
			var weightUser = recordSet(8).Value;
			var weight = recordSet(9).Value;
			var trader = recordSet(10).Value;
			var observations = "<textarea class='form-control observations' rows='1'>" + recordSet(13).Value + "</textarea>"; 
			var GeoTrader = recordSet(14).Value;
			var GeoUnity = recordSet(15).Value;
			var priorization = recordSet(16).Value;
			var action = "<a class='ban' value='" + type + "'>Descartar <i class='fa fa-ban'></i></a> <br> <a class='save hide' value='" + type + "'>Guardar <i class='fa fa-save'></i></a>";
			var strategyNames = ["Cobertura", "Swap_IBR", "Sinteticos", "Opciones", "Internet", "Divisas"];

			strategiesHtml = type == "N" ? strategiesHtml + "<tr value='false'><td><a class='search'>" + nit + "</a></td><td>" + customer + "</td><td>" + ppto + " </td><td value='" + strategyNames[0] + "'>" + strategy1 + "</td><td value='" + strategyNames[1] + "'>" + strategy2 + "</td><td value='" + strategyNames[2] + "'>" + strategy3 + "</td><td value='" + strategyNames[4] + "'>" + strategy5 + "</td><td value='" + strategyNames[5] + "'>" + strategy6 + "</td><td>" + GeoTrader + "</td><td>" + GeoUnity + "</td><td>" + priorization + "</td><td>" + observations + "</td><td>" + action + "</td></tr>" : strategiesHtml + "<tr value='false'><td><a class='search'>" + nit + "</a></td><td>" + customer + "</td><td>" + ppto + " </td><td value='" + strategyNames[0] + "'>" + strategy1 + "</td><td value='" + strategyNames[1] + "'>" + strategy2 + "</td><td value='" + strategyNames[2] + "'>" + strategy3 + "</td><td value='" + strategyNames[3] + "'>" + strategy4 + "</td><td value='" + strategyNames[4] + "'>" + strategy5 + "</td><td value='" + strategyNames[5] + "'>" + strategy6 + "</td><td>" + GeoTrader + "</td><td>" + GeoUnity + "</td><td>" + priorization + "</td><td>" + observations + "</td><td>" + action + "</td></tr>";
		
			recordSet.MoveNext();
		}
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}
	
	return strategiesHtml + "</tbody>";
}

function consultItems(connection, recordSet, stringConnection, query){
	var myItems = "";
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
	
		while (!recordSet.EOF){
			myItems = myItems + "<option>" + recordSet(0).Value + "</option>";
			recordSet.MoveNext();
		}
	} catch(e){	
		alert("Ocurri� un error a obtener los items de las listas desplegables")
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return myItems;
}

function insertLikes(connection, nit){
	for (var i = 0; i < selections.likes.length; i++){
		if (compareString(selections.likes[i].Nit, nit)){
			var strategy = selections.likes[i].Estrategia;
			var reason = "AceptadoTrader";
			var observation = "Dado por el Traders";
			var area = "Tesorer�a";
			var query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracion, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
			
			if (develop){
				console.log("Query inserta likes: " + query);
			} else {
				if (!insert(query, stringConnections.strConnectionPET, connection)){
					alert("Ocurri� un error al intentar almacenar las priorizaciones like");
				}
			}
		}
	}
}

function insertDislikes(connection, nit){
	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			var strategy = selections.dislikes[i].Estrategia;
			var reason = "Descartado";
			var observation = "Dado por el Trader";
			var area = "Tesorer�a";
			var query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracion, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
			
			if (develop){
				console.log("Query inserta dislikes: " + query);
			} else{
				if (!insert(query, stringConnections.strConnectionPET, connection)){
					alert("Ocurri� un error al intentar almacenar las priorizaciones dislike");
				}
			}
		}
	}
}

function priorizateCustomers(connection, nit){
	var totalNits = []
	var uniqueNits = [];
	
	for (var i = 0; i < selections.likes.length; i++){
		totalNits.push(selections.likes[i].Nit);
	}
	
	deleteDuplicates(totalNits, uniqueNits);
	
	for (var i = 0; i < uniqueNits.length; i++){
		if (compareString(uniqueNits[i], nit)){
			var query = replaceAll(queries.queryPriorizarCliente, "R_NIT", nit);
			
			if (develop){
				console.log("Query prioriza likes: " + query);
			} else{
				if (!update(query, stringConnections.strConnectionPET, connection, command)){
					alert("Ocurri� un error al intentar actualizar nit en priorizacion");
				}
			}
			
			break;
		}
	}
}

function validateDislikes(connection, nit){
	var strategyDislikesCount = 0;

	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			strategyDislikesCount = strategyDislikesCount + 1;
		}
	}
	
	var traderWeight = 0;
	
	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			var query = replaceAll(queries.queryPesoCliente, "R_NIT", nit);
			var newTraderWeight = 0;
			
			traderWeight = getTraderWeight(connection, recordSet, stringConnections.strConnectionPET, query);
			newTraderWeight = (traderWeight - strategyDislikesCount);
			
			query = replaceAll(replaceAll(queries.queryPesoTrader, "R_NIT", nit), "R_PESOTRADER", newTraderWeight);
			
			if (develop){
				console.log("Query actualiza peso: " + query);
			} else{
				if (!update(query, stringConnections.strConnectionPET, connection, command)){
					alert("Ocurri� un error al intentar actualizar PesoTrader");
				}
			}
			
			if(traderWeight == 0){
				query = replaceAll(queries.queryDespriorizarCliente, "R_NIT", nit);
				
				if (develop){
					console.log("Query desprioriza dislikes: " + query);
				} else{
					if (!update(query, stringConnections.strConnectionPET, connection, command)){
						alert("Ocurri� un error al intentar despriorizar cliente");
					}
				}
				
				var strategy = "DescartadoCliente";
				var reason = "No aplican estrategias";
				var observation = "Trader: No aplican estrategias";
				var area = "Tesorer�a";
				
				query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracion, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
				
				if (develop){
					console.log("Query inserta no aplican estrategias: " + query);
				} else{
					if (!insert(query, stringConnections.strConnectionPET, connection)){
						alert("Ocurri� un error al intentar insertar DescartadoCliente");
					}
				}
			}
			
			break;
		}
	}
}

function getTraderWeight(connection, recordSet, stringConnection, query){
	var weight = 0;
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		weight = recordSet(1).value == 0 ? recordSet(0).value : recordSet(1).value;
	} catch(e){
		alert("Ocurri� un error al intentar obtener el peso del cliente (" + e.message + ")");
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return weight;
}

function insertObservations(connection, nit, observations){
	var obs = replaceAll(replaceAll(replaceAll(observations, '\n', ' '), '\t', ' '), '\r', '');
	var query = replaceAll(replaceAll(queries.queryUpdateObservations, "R_NIT", nit), "R_OBSERVACIONES", obs);
			
	if (develop){
		console.log("Query actualiza observationes: " + query);
	} else{
		if (!update(query, stringConnections.strConnectionPET, connection, command)){
			alert("Ocurri� un error al intentar actualizar observaciones");
		}
	}
}

function getGeographyInformation(connection, recordSet, stringConnection, query) {
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);	

		while (!recordSet.EOF){

			$("#nit-info-modal").text(recordSet(0).Value);
			$("#customer-info-modal").text(recordSet(1).Value);
			$("#unit-info-modal").text(recordSet(2).Value);
			$("#bank-info-modal").text(recordSet(3).Value);
			$("#segment-info-modal").text(recordSet(4).Value);
			$("#region-info-modal").text(recordSet(5).Value);
			$("#trader-info-modal").text(recordSet(6).Value);
			$("#type-info-modal").text(recordSet(7).Value);
			$("#group-nit-info-modal").text(recordSet(8).Value);
			$("#group-name-info-modal").text(recordSet(9).Value);
			$("#type-customer").text(recordSet(10).Value);
			$("#cash").text(recordSet(11).Value);
			var deadline = new Date(recordSet(12).Value + "");
			$("#deadline-date").text(deadline == 'Invalid Date' ? "" : deadline.getDate() + " " + convertNumericMonthToStringMonth(deadline.getMonth() + 1) + " " + deadline.getFullYear());
			$("#priorization-modal").text(recordSet(13).Value);

			recordSet.MoveNext();
		}

	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

function countStrategies (connection, recordSet, stringConnection, query){
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);	
		
		while (!recordSet.EOF){
			$("#maintenance-tab").children().eq(0).text($("#maintenance-tab").children().eq(0).text() + " (" + recordSet(1).Value + ")"); 
			$("#news-tab").children().eq(0).text($("#news-tab").children().eq(0).text() + " (" + recordSet(2).Value + ")"); 
			$("#deepening-tab").children().eq(0).text($("#deepening-tab").children().eq(0).text() + " (" + recordSet(3).Value + ")"); 
			$("#reactivation-tab").children().eq(0).text($("#reactivation-tab").children().eq(0).text() + " (" + recordSet(4).Value + ")"); 
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
}


//Function that Convert JSON for Download
function reportDownload (connection, recordSet, stringConnection, query){
	var report = [];
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var date = new Date(recordSet(0));
			var nit = recordSet(1).Value;
			var customer = recordSet(2).Value;
			var strategy = recordSet(3).Value;
			var type = recordSet(4).Value;
			var unity = recordSet(5).Value;
			var trader = recordSet(6).value;
			var bank = recordSet(7).Value;
			var segment = recordSet(8).Value;
			var region = recordSet(9).Value;
			var prioritized = recordSet(10).Value;
			var visit = recordSet(11).Value;
			var stateVisit = recordSet(12).Value;
			var visitMade = recordSet(13).Value;
			var registerPipeline = recordSet(14).Value;
			var closeOperation = recordSet(15).Value; 
			report.push({"FechaActualizacion":date, "Nit":nit, "Cliente":customer, "Estrategia":strategy, "Tipo":type, "Unidad":unity, "Trader":trader, "Banca":bank, "Segmento":segment, "Region":region, "Priorizado": prioritized, "Visita Agendada":visit, "Estado Visita":stateVisit, "Registro Pipeline":registerPipeline, "Operacion Cerrada":closeOperation})
			recordSet.MoveNext(); 	
		}

	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}

	return report;
}


function dataToExcel(data, sheetName, fileName){
	try{		
		if(typeof XLSX == 'undefined') XLSX = require('xlsx');
		var ws = XLSX.utils.json_to_sheet(data);
		var wb = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, sheetName);
		var wbout = XLSX.write(wb, {bookType:'xlsx', bookSST:false, type:'array'});
		var blob = new Blob([wbout], {type: "application/octet-stream"});
		saveAs(new Blob([wbout], {type:"application/octet-stream"}), fileName + ".xlsx"); // Use "FileSaver.js"

	} catch(e){
		showBootstrapDialog("Error", "Ocurri� un error en proceso de exportaci�n (" + e.message + ")." ,"PRIMARY", "ALERT", "NORMAL" );
	}
}

