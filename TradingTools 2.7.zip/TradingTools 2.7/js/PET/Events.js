// Add events
function addAllEvents(){
	// Botones tab
		
	$("#news-button").on('click', function(){
		addClass(".news-get-container", " hide");
		removeClass(".news-table-container", " hide");
		//showBootstrapDialog("Informaci�n", replaceAll(replaceAll(queries.queryClientes, "R_TIPO", "N"), "R_USUARIOS", usersToShowMe), "PRIMARY", "ALERT", "NORMAL" );
		buildTable(headers.headersStrategiesN, getStrategies(connection, recordSet, stringConnections.strConnectionPET, replaceAll(replaceAll(queries.queryClientes, "R_TIPO", "N"), "R_USUARIOS", usersToShowMe), "N"), "#news-table");
		$("#news-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#news-table");
		PutAllCustomers("#news-table","N");
	});

	$("#deepening-button").on('click', function(){
		addClass(".deepening-get-container", " hide");
		removeClass(".deepening-table-container", " hide");
		buildTable(headers.headersStrategiesP, getStrategies(connection, recordSet, stringConnections.strConnectionPET, replaceAll(replaceAll(queries.queryClientes, "R_TIPO", "P"), "R_USUARIOS", usersToShowMe), "P"), "#deepening-table");
		$("#deepening-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#deepening-table");
		PutAllCustomers("#deepening-table","P");
	});
	
	$("#reactivation-button").on('click', function(){
		addClass(".reactivation-get-container", " hide");
		removeClass(".reactivation-table-container", " hide");
		buildTable(headers.headersStrategiesR, getStrategies(connection, recordSet, stringConnections.strConnectionPET, replaceAll(replaceAll(queries.queryClientes, "R_TIPO", "R"), "R_USUARIOS", usersToShowMe), "R"), "#reactivation-table");
		$("#reactivation-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#reactivation-table");
		PutAllCustomers("#reactivation-table","R");
	});
	
	$("#maintenance-button").on('click', function(){
		addClass(".maintenance-get-container", " hide");
		removeClass(".maintenance-table-container", " hide");
		buildTable(headers.headersStrategiesM, getStrategies(connection, recordSet, stringConnections.strConnectionPET, replaceAll(replaceAll(queries.queryClientes, "R_TIPO", "M"), "R_USUARIOS", usersToShowMe), "M"), "#maintenance-table");
		$("#maintenance-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#maintenance-table");
		PutAllCustomers("#maintenance-table","M");
	});
		
	//Reporte PET
	$("#report-button").on('click', function (){ 

		showBootstrapDialog("Confirmaci�n", "Esta seguro que desea descargar el reporte, �Desea continuar?", "DANGER", "CONFIRM", "NORMAL", function(result){if(result){ 
			var data = reportDownload(connection, recordSet, stringConnections.strConnectionPET, queries.queryReportPet);
			dataToExcel(data, "Reporte_PET", "Reporte_PET_" + users.currentUser.toUpperCase());
		}});

	});


	// Like/Dislike/Ban
	$("#news-table, #deepening-table, #reactivation-table,#maintenance-table").on('click', '.like', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var strategy = $(this).parent().attr("value");
		var type = $(this).parent().parent().parent().parent().attr("value");
		
		if (hasClass($(this), "like-selected")){
			for (var i = 0; i < selections.likes.length; i++){
				if (compareString(selections.likes[i].Nit, nit) && compareString(selections.likes[i].Estrategia, strategy)){
					selections.likes.splice(i, 1);
					break;
				}
			}
			removeClass($(this), "like-selected");
			removeClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		} else{
			for (var i = 0; i < selections.dislikes.length; i++){
				if (compareString(selections.dislikes[i].Nit, nit) && compareString(selections.dislikes[i].Estrategia, strategy)){
					selections.dislikes.splice(i, 1);
					break;
				}
			}
			selections.likes.push({"Nit":nit, "Estrategia":strategy});
			removeClass($(this).parent().children("i").eq(1), "dislike-selected");
			addClass($(this), "like-selected");
			addClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		}
	});
	
	$("#news-table, #deepening-table, #reactivation-table,#maintenance-table").on('click', '.dislike', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var strategy = $(this).parent().attr("value");
		var type = $(this).parent().parent().parent().parent().attr("value");
	
		if (hasClass($(this), "dislike-selected")){
			for (var i = 0; i < selections.dislikes.length; i++){
				if (compareString(selections.dislikes[i].Nit, nit) && compareString(selections.dislikes[i].Estrategia, strategy)){
					selections.dislikes.splice(i, 1);
					break;
				}
			}
		
			removeClass($(this), "dislike-selected");
			removeClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		} else{
			for (var i = 0; i < selections.likes.length; i++){
				if (compareString(selections.likes[i].Nit, nit) && compareString(selections.likes[i].Estrategia, strategy)){
					selections.likes.splice(i, 1);
					break;
				}
			}
		
			selections.dislikes.push({"Nit":nit, "Estrategia":strategy});
		
			removeClass($(this).parent().children("i").eq(0), "like-selected");
			addClass($(this), "dislike-selected");
			addClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		}
	});
	
	// Active strategies
	$("#news-table, #deepening-table, #reactivation-table,#maintenance-table").on('click', '.active-strategy', function (){
		var selector = $(this);
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea habilitar esta estrategia?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			activeStrategy(selector);
		}});
	});
	
	// Show modal for discard
	$("#reactivation-table, #maintenance-table, #news-table, #deepening-table").on('click', '.ban', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var customer = $(this).parent().parent().children().eq(1).text().trim();
		
		$("#discard-nit-modal").text(nit);
		$("#discard-customer-modal").text(customer);
		$("#discard-type-modal").val("Banco");
		$("#discard-observation-modal").val("");
		removeClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
		addClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
		$("#discard-reason-bank-modal").val("Plazo");
		addClass("#hidden-id-modal", $(this).parent().parent().parent().parent().attr('id'));
		addClass("#hidden-type-modal", $(this).attr('value'));
		$("#discard-modal").modal('show');
	});
	
	$("#reactivation-table, #maintenance-table, #news-table, #deepening-table").on('click', '.search', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		resetModal([[".graphs-container", "container"],["#stra-apply", "container"],["#stra-prio", "container"],["#stra-desprio", "container"],["#impo", "text"],["#cart-ibr", "text"],["#exp-camb", "text"],["#vol-neg", "text"],["#wallet-sha", "text"],["#cart-ml", "text"],["#cart-me", "text"],["#monto-dtf", "text"],["#ppto-ing-div", "text"],["#ppto-ing-der", "text"],["#ejec-ing-der", "text"],["#ejec-ing-div", "text"],["#brecha-ing-div", "text"],["#brecha-ing-der", "text"],["#cumpl-ing-div", "text"],["#cumpl-ing-der", "text"]]);
		searchCustomer(nit);
		$("#customer-information-modal").modal('show');
	});
	
	// Validate Type Discard Value
	$("#discard-type-modal").on('change', function(){
		var valor = $("#discard-type-modal").val();
		
		if (compareString(valor, "Cliente")){
			removeClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
			addClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
		} else if(compareString(valor, "Banco")){
			removeClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
			addClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
		} else{
			addClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
			addClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
		}
	});
	
	// Validate Reason Discard Value
	$("#discard-reason-customer-modal, #discard-reason-bank-modal").on('change',function(){
		var valor = $(this).val();
		
		if (compareString(valor, "Otra, cual?")){
			removeClass($("#discard-observation-modal").parent().parent().parent(), "hide");
		} else {
			addClass($("#discard-observation-modal").parent().parent().parent(), "hide");
		}
	});
	
	// Discard Customer
	$("#discard-button").on('click', function(){
		discardCustomer();
	});
	
	// Insert Priorization/Depriorization & Observations
	$("#reactivation-table, #maintenance-table, #news-table, #deepening-table").on('click', '.save', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var tableSelector = "#" + $(this).parent().parent().parent().parent().attr("id");
		var type = $(this).attr("value");	
		var observations = type == 'N' ? $(this).parent().parent().children().eq(11).children().eq(0).val() : $(this).parent().parent().children().eq(12).children().eq(0).val();
		
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea guardar los cambios hechos de este cliente?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			insertLikes(connection, nit);
			insertDislikes(connection, nit);
			priorizateCustomers(connection, nit);
			validateDislikes(connection, nit);
			resetSelections(nit);
			if(!compareString(observations, "")) insertObservations(connection, nit, observations);
			destroyPetTable(tableSelector, type);
			showBootstrapDialog("Informaci�n", "Los cambios se aplicaron exitosamente", "PRIMARY", "ALERT", "NORMAL" );

		}});				
	});
	
	// Show Search Modal
	$("#search-button").on('click', function(){
		resetModal([["#nit-search-modal", "input"]]);
		$("#search-modal").modal('show');
	});
	
	$("#search-modal").on('shown.bs.modal', function () {
		$('#nit-search-modal').focus();
	});
	
	// Show Customer Information Modal
	$("#search-button-modal").on('click', function(){
		var nit = $("#nit-search-modal").val().trim();
		
		resetModal([[".graphs-container", "container"],["#stra-apply", "container"],["#stra-prio", "container"],["#stra-desprio", "container"],["#impo", "text"],["#cart-ibr", "text"],["#exp-camb", "text"],["#vol-neg", "text"],["#wallet-sha", "text"],["#cart-ml", "text"],["#cart-me", "text"],["#monto-dtf", "text"],["#ppto-ing-div", "text"],["#ppto-ing-der", "text"],["#ejec-ing-der", "text"],["#ejec-ing-div", "text"],["#brecha-ing-div", "text"],["#brecha-ing-der", "text"],["#cumpl-ing-div", "text"],["#cumpl-ing-der", "text"]]);
		
		if (!compareString(nit, "")){
			searchCustomer(nit)
			
			$(".A�oAnterior").text((new Date()).getFullYear()- 1)
			$(".A�oActual").text((new Date()).getFullYear())
			$("#search-modal").modal('hide');
			$("#customer-information-modal").modal('show');
		} else{
			showBootstrapDialog("Informaci�n", "Por favor ingrese un nit para realizar la b�squeda", "WARNING", "ALERT", "NORMAL");
		}
	});
	
	// Show Discard Customers Modal
	$("#open-discard-customers-button").on('click', function(){
		var query = replaceAll(queries.queryDiscardCustomers, 'R_USUARIOS', usersToShowMe);
		
		resetModal([["#discard-customers-table", "container"]]);
		buildTable(["Fecha Desc", "Nit", "Cliente", "Trader", "Observacion", "Acci�n"], getDiscardCustomers(connection, recordSet, stringConnections.strConnectionPET, query), "#discard-customers-table");
		$("#discard-customers-table").DataTable({"ordering": false});
		$("#discard-customers-modal").modal("show");
	});
	
	$("#discard-customers-modal, #schedule-customers-modal, #visits-modal").on('hidden.bs.modal', function (){
		$("#" + replaceAll($(this).attr('id'), "modal", "table")).DataTable().destroy();
	});
	
	// Show Schedule Customers Modal
	$("#open-schedule-customers-button").on('click', function(){
		var query = replaceAll(queries.queryScheduleCustomers, 'R_USUARIOS', usersToShowMe);
		var nits = [];
		
		resetModal([["#schedule-customers-table", "container"]]);
		buildTable(["Nit", "Cliente", "Tipo", "Estrategia", "Trader", "Tipo Visita", "Fecha Estimada", "Acci�n"], getScheduleCustomers(connection, recordSet, stringConnections.strConnectionPET, query, nits), "#schedule-customers-table");
		instanceDatepickers(nits);
		$("#schedule-customers-table").DataTable({"ordering": false});
		$("#schedule-customers-modal").modal("show");				
	});
	
	// Show Visits Modal
	$("#open-visits-button").on('click', function(){
		var query = replaceAll(queries.queryVisits, 'R_USUARIOS', replaceAll(replaceAll(usersToShowMe, "AND ", ""), "PET_NitEstrategias.", ""));
		resetModal([["#visits-table", "container"]]);
		buildTable(["Fecha Creaci�n", "Nit", "Cliente", "Fecha Estimada", "Trader", "Tipo Visita", "Estado", "Acci�n"], getVisits(connection, recordSet, stringConnections.strConnectionPET, query), "#visits-table");
		$("#visits-table").DataTable({"ordering": false});
		
		$("#visits-modal").modal("show");
	});
	
	// Reactivate Customer
	$("#discard-customers-table").on('click', '.reactive', function (){
		var nit = $(this).parent().parent().children().eq(1).text().trim();
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea reactivar este cliente?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			reactiveCustomer(connection, command, recordSet, stringConnections.strConnectionPET, nit);
		}});	
	});
	
	// Schedule Customer
	$("#schedule-customers-table").on('click', '.schedule', function (){
		var selector = $(this);
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea agendar este cliente?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			scheduleVisit(selector);
		}});	
	});

	// Delete Visit
	$("#visits-table").on('click', '.delete-visit', function (){
		var nit = $(this).parent().parent().children().eq(1).text().trim();
		showBootstrapDialog("Confirmaci�n", "�Est� seguro que desea eliminar esta visita?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			deleteVisits(connection, command, recordSet, stringConnections.strConnectionPET, nit);
		}});
	});
	
	// Change Visit Status
	$("#visits-table").on('click', '.status', function (){
		updateVisitStatus(connection, command, recordSet, stringConnections.strConnectionPET, $(this));
	});
	
	// Allow Only Numeric Values For All Numeric Inputs 
	$("#nit-search-modal").keydown(function (e){allowNumericValues(e)});
	
	// When Enter Key is pressed, button too
	$('#nit-search-modal').keydown(function(e){if (e.keyCode == 13) {$('#search-button-modal').click()}});
	
	// Customer Observations on Table
	$('#news-table, #deepening-table, #reactivation-table, #maintenance-table').on('keyup', '.observations', function (){
		var type = $(this).parent().parent().parent().parent().attr("value");
		validateChangesOnTextArea($(this));
		validateChangesOnRow($(this).parent().parent(),type);
	});
	
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});
	
	// Tooltips
	$('.has-tooltip').tooltip({
		selector: "[data-toggle=tooltip]",
		container: "body"
	});
}