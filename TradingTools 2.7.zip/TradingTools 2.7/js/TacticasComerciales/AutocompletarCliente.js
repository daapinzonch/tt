// Autocompleta el cliente en su campo dependiendo del nit ingresado en el combo nit
function autocompletarCliente(){
	var nit = $('#nits').val();
	var consulta = reemplazarTodos(queries.consultaCliente, "rNit", nit + "");
	var bd = stringConnections.strConexionDataMart;
	
	var cliente = consultarDatamart(consulta, bd);
		
	if (cliente.localeCompare("No hay resultados") == 0){
		$("#nombreCliente").val("No se encontr� cliente para el nit introducido");
		$("#nombreCliente").prop('disabled', false);
		
		validacionCampos[4] = false;
		mostrarEstadoCampo(validarCliente(), "nombreCliente", "divCliente");
	} else {
		cliente = reemplazarTodos(cliente, "<option>", "");
		cliente = reemplazarTodos(cliente, "</option>", "");
		
		$("#nombreCliente").val(cliente);
		$("#nombreCliente").prop('disabled', true);
		
		validacionCampos[4] = true;
		mostrarEstadoCampo(validarCliente(), "nombreCliente", "divNombreCliente");
	}
}