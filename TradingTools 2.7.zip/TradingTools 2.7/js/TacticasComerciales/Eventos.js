function cargarEventos(){
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/*************************************** ON CLICK **************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	// Actualiza la hora del formulario
	$("#botonAbrirFormulario").on('click',function(){
		mostrarHoraActual("horaActual");
		$("#tradersConsultoresResponsables").val(users.currentUser);
		validacionCampos[6] = true;
		mostrarOcultarCampos($("#tiposTactica").val());
	});
	
	// Autocompleta el cliente teniendo en cuenta el nit ingresado
	$("#botonAutocompletarCliente").on('click',function(){
		autocompletarCliente();
	});
	
	// Reinicia los valores del formulario cuando se cierre el modal
	$('#botonCerrarModal').on('click', function (e){
		$("#botonReiniciarValores").click();
		validacionCampos = [false, true, false, false, false, true, false, true, true, true, true, true];
		$("#nombreCliente").prop('disabled', false);
	});
	
	// Reinicia todos los campos, combos, estados del formulario
	$('#botonReiniciarValores').on('click', function (e){
		$("#cliente").prop('disabled', false);
		desactivarBotonEnviar();
		eliminarCombos();
		cargarCombos();
		instanciarCombos();
		vaciarCombo("nits");
		reiniciarFormulario();
		reiniciarValidacionCampos();
		adecuarFormularioParaConsultores();
		mostrarOcultarCampos($("#tiposTactica").val());
	});
	
	// Insertar t�ctica
	$('#botonInsertarTactica').on('click', function (e){
		var datos = obtenerDatosIngresados();
		comprobarUsuarioSube(datos, $("#tradersConsultoresResponsables").val());
	});
	
	// Exportar t�cticas a Excel
	$('#botonExportarExcel').on('click', function (e){
		exportTable("#tablaResultados", "T�cticas", "T�cticas_" + users.currentUser);
	});
	
	// Vac�a el input de carga masiva
	$('#botonAbrirFormularioCargaMasiva').on('click', function (e){
		reiniciarInputsCargueMasivo();
		$("#panelInfoMasiva").addClass(" hide");
		$('#linkEstructura').prop('disabled', false);
		$('#linkEstructura').html("aqu�");
	});
	
	// Seleccionar un archivo para cargue masivo
	$('#botonExaminar').on('click', function (e){
		$("#inputFile").click();
	});
	
	// Cargar m�ltiples t�cticas
	$('#botonCargueMasivo').on('click', function (e){
		$("#panelInfoMasiva").removeClass(" hide");
		mostrarMensajeValidandoCampos();
		
		setTimeout(function() {
			datosParaSubirDesdeExcel = obtenerDatosASubir();
		}, 100);
		
		$("#tituloInfoMasiva").html("<b>Ingresando t�cticas...</b>");
		$("#contInfoMasiva").html("Espere mientras sus t�cticas son cargadas, esto podr�a tomar unos minutos.");
		
		setTimeout(function() {
			if ((datosParaSubirDesdeExcel.substring(0, 8)).localeCompare("<b>Error") != 0){
				insertarTacticasMasivas(datosParaSubirDesdeExcel);
				$("#tituloInfoMasiva").html("<b>T�cticas ingresadas</b>");
				$("#contInfoMasiva").html("De un total de <b>" + filasCargadas + "</b> t�cticas se cargaron <b>" + (filasCargadas - tacticasRepetidas) + "</b> nuevas y <b>" + tacticasRepetidas + "</b> duplicadas.");
				reiniciarInputsCargueMasivo();
				$('#linkEstructura').prop('disabled', false);
				$('#linkEstructura').html("aqu�");
			} else{
				$("#panelInfoMasiva").removeClass(" panel-success");
				$("#panelInfoMasiva").addClass(" panel-danger");
				$("#tituloInfoMasiva").html("<b>Error</b>");
				$("#contInfoMasiva").html(datosParaSubirDesdeExcel);
			}
		}, 100);
	});
	
	// Mostrar estructura para cargue masivo
	$('#linkEstructura').on('click', function (e){
		mostrarEstructuraparaCargue();
		$('#linkEstructura').prop('disabled', true);
		$('#linkEstructura').html("generado");
	});
	
	// Muestra el tour cuando el bot�n de ayuda es presionado
	$("#instrucciones").on('click',function(){
		window.scrollTo(0, 0);
		mostrarTour();
	});
	
	$('#tablaResultados').on('click', '.linkModalidadPresencial', function (e){
		$(this).text("Virtual");
		$(this).removeClass("linkModalidadPresencial");
		$(this).addClass("linkModalidadVirtual");
		actualizarModalidad("Virtual", e.target.id);
	});
	
	$('#tablaResultados').on('click', '.linkModalidadVirtual', function (e){
		$(this).text("Presencial");
		$(this).removeClass("linkModalidadVirtual");
		$(this).addClass("linkModalidadPresencial");
		actualizarModalidad("Presencial", e.target.id);
	});
	
	$('#liRestricciones').on('click', function (e){
		$("#submodalCargueMasivoTacticas").removeClass("modal-dialog2");
		$("#submodalCargueMasivoTacticas").addClass("modal-dialog3");
	});
	
	$('#liRecomendaciones').on('click', function (e){
		$("#submodalCargueMasivoTacticas").removeClass("modal-dialog3");
		$("#submodalCargueMasivoTacticas").addClass("modal-dialog2");
	});
	
	$("#botonBuscarCoincidencias").on('click', function (e){
		var nit = $('#nits').val();
		var consulta = reemplazarTodos(queries.consultaNits, "rNit", nit);
		var bd = stringConnections.strConexionDataMart;
		var longitud = $('#nits').val().length;
		var coincidencias = consultarDatamart(consulta, bd);
		
		if (compareString(coincidencias, "No hay resultados")){
			alert("No se encontraron coincidencias para este nit.");
		} else{
			eliminarCombo("nits");
			cargarCombo(coincidencias, "nits");
			instanciarCombo("nits");
			$('#nits').val(nit);
			$('#nits').focus();
			moverCursorUltimaPosicion("nits", longitud);
		}
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/*************************************** FOCUS OUT *************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	
	// Valida el campo "Tipo de T�ctica" cada vez que deje de tener el foco
	$('#contenedorComboTiposTactica').focusout(function (){
		mostrarValidacionDeCampos(validarTipoTactica(), "tiposTactica", "contenedorComboTiposTactica", "Tipo de t�ctica", "labelTipoTactica", 0);
	});
	
	// Valida el campo "Fecha de t�ctica" cada vez que deje de tener el foco
	$("#fechaTactica").focusout(function (){
		mostrarValidacionDeCampos(validarFechaTactica(), "fechaTactica", "divFechaTactica", "Fecha de t�ctica", "labelFechaTactica", 2);
	});
	
	// Valida el campo "Nits" cada vez que deje de tener el foco
	$("#contenedorComboNit").focusout(function (){
		mostrarValidacionDeCampos(validarNit(), "nits", "contenedorComboNit", "Nit", "labelNits", 3);
	});
	
	// Valida el campo "Nombre de Cliente" cada vez que deje de tener el foco
	$("#divNombreCliente").focusout(function (){
		mostrarValidacionDeCampos(validarCliente(), "nombreCliente", "divNombreCliente", "Nombre cliente", "labelNombreCliente", 4);
	});
	
	// Valida el campo "N�mero de Asistentes" cada vez que deje de tener el foco
	$("#divNumeroAsistentesCliente").focusout(function (){
		mostrarValidacionDeCampos(validarNumeroAsistentes(), "numeroAsistentesCliente", "divNumeroAsistentesCliente", "N�mero de asistentes del cliente", "labelNumeroAsistentesCliente", 5);
	});
	
	// Valida el campo "Trader / Consultor Responsable" cada vez que deje de tener el foco
	$('#contenedorComboTradersConsultoresResponsables').focusout(function (){
		mostrarValidacionDeCampos(validarTraderConsultorResponsable(), "tradersConsultoresResponsables", "contenedorComboTradersConsultoresResponsables", "Trader o Consultor responsable", "labelTradersConsultoresResponsables", 6);
	});
	
	// Valida el campo "Trader Asistente" cada vez que deje de tener el foco
	$('#contenedorComboTraders').focusout(function (){
		mostrarValidacionDeCampos(validarTraderAsistente(), "traders", "contenedorComboTraders", "Trader", "labelTraders", 7);
	});
	
	// Valida el campo "Consultor Asistente" cada vez que deje de tener el foco
	$('#contenedorComboConsultores').focusout(function (){
		mostrarValidacionDeCampos(validarConsultorAsistente(), "consultores", "contenedorComboConsultores", "Consultor", "labelConsultores", 8);
	});
	
	// Valida el campo "Otro Asistente" cada vez que deje de tener el foco
	$('#contenedorComboOtros').focusout(function (){
		mostrarValidacionDeCampos(validarOtroAsistente(), "otros", "contenedorComboOtros", "Otro", "labelOtros", 9);
	});
	
	// Valida el campo "Tema evento, capacitaci�n o visita" cada vez que deje de tener el foco
	$('#contenedorComboTemaEventoCapacitacionVisita').focusout(function (){
		mostrarValidacionDeCampos(validarTema(), "temaEventoCapacitacionVisita", "contenedorComboTemaEventoCapacitacionVisita", "Tema de evento, capacitaci�n o visita", "labelTemaEventoCapacitacionVisita", 10);
	});
	
	// Valida el campo "Observaciones" cada vez que deje de tener el foco
	$('#comentarios').focusout(function (){
		mostrarValidacionDeCampos(validarComentariosForm(), "comentarios", "divComentarios", "Observaciones", "labelComentarios", 11);
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/**************************************** FOCUS IN *************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	
	$("#radioPresencial").focusin( function(){
		$("#labelRadio2").removeClass(" btn-success");
		$("#labelRadio2").addClass(" btn-default");
		$("#labelRadio1").removeClass(" btn-default");
		$("#labelRadio1").addClass(" btn-success");
		$("#labelRadio1").addClass(" active");
	});
	
	$("#radioVirtual").focusin( function(){
		$("#labelRadio1").removeClass(" btn-success");
		$("#labelRadio1").addClass(" btn-default");
		$("#labelRadio2").removeClass(" btn-default");
		$("#labelRadio2").addClass(" btn-success");
		$("#labelRadio2").addClass(" active");
	});
	
	$("#radioVirtual").focusin( function(){
		$("#tradersConsultoresResponsables").val(users.currentUser);
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/***************************************** CHANGE **************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	// Seleccionar un archivo para cargue masivo
	$('#inputFile').on('change', function (e){
		rutaArchivoParaCargue = this.value;
		validarRuta();
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/********************************* SELECT.EDITABLE-SELECT ******************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	// Cuando se seleccione una opci�n del combo nits, trae el cliente
	$('#contenedorComboTiposTactica').on('select.editable-select', function (e){
		reiniciarRadioButtons();
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/***************************************** KEY DOWN ************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	// Solo permite ingresar valores n�mericos al campo de nits
	$("#contenedorComboNit").keydown(function (e) {
        permitirValoresNumericos(e);
    });
	
	// Solo permite ingresar valores n�mericos al campo de n�mero de asistentes
	$("#divNumeroAsistentesCliente").keydown(function (e) {
        permitirValoresNumericos(e);
    });
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/******************************************* KEY UP ************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	// Coloca opciones en el combo nits mientras que la longitud escrita sea igual a 5
	$('#contenedorComboNit').keyup(function (e){
		var longitud = $('#nits').val().length;
		var estadoBoton = longitud > 6 ? false : true;
		
		$("#botonBuscarCoincidencias").prop("disabled", estadoBoton);
		
		if (e.keyCode == 8){
			if (longitud == 6 || longitud == 0){
				vaciarCombo("nits");
				$('#nits').val($('#nits').val());
				moverCursorUltimaPosicion("nits", longitud);
			}
		}
	});
	
	/***************************************************************************************************/
	/***************************************************************************************************/
	/******************************************* MODALS ************************************************/
	/***************************************************************************************************/
	/***************************************************************************************************/
	
	$('.modal').on('hidden.bs.modal', function (e){
		if ($('.modal').hasClass('in')){
			$('body').addClass('modal-open');
		}
	});
}