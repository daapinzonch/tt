function actualizarModalidad(nuevaModalidad, id){
	var consulta = queries.consultaActualizarModalidad;
	var strConexion = stringConnections.strConexionFailedOperations;
	
	consulta = reemplazarTodos(consulta, "rModalidad", nuevaModalidad);
	consulta = reemplazarTodos(consulta, "rId", id);
	
	actualizarModalidadBD(consulta, strConexion);
}