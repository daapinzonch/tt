function mostrarEstructuraparaCargue(){
	try{
		// Objeto ActiveX para utilizar Excel
		var Excel = new ActiveXObject("Excel.Application");
		var ExcelSheet = new ActiveXObject("Excel.Sheet");
		var Book = Excel.Workbooks.Add();
		
		Excel.Visible = true;
		
		Book.ActiveSheet.Cells(1, 1).Value = "Tipo t�ctica";
		Book.ActiveSheet.Cells(1, 2).Value = "Modalidad";
		Book.ActiveSheet.Cells(1, 3).Value = "D�a de t�ctica";
		Book.ActiveSheet.Cells(1, 4).Value = "Mes de t�ctica";
		Book.ActiveSheet.Cells(1, 5).Value = "A�o de t�ctica";
		Book.ActiveSheet.Cells(1, 6).Value = "Nit";
		Book.ActiveSheet.Cells(1, 7).Value = "Nombre cliente";
		Book.ActiveSheet.Cells(1, 8).Value = "Responsable";
		Book.ActiveSheet.Cells(1, 9).Value = "Tema t�ctica";
		Book.ActiveSheet.Cells(1, 10).Value = "No. Asistentes";
		Book.ActiveSheet.Cells(1, 11).Value = "Observaciones";
		Book.ActiveSheet.Cells(1, 12).Value = "Origen";
		Book.ActiveSheet.Columns("A:J").EntireColumn.AutoFit;
	} catch(e){
		alert(e.message);
	}
}