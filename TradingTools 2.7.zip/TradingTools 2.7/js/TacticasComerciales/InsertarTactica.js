function obtenerDatosIngresados(){
	var fechaAux = $("#fechaTactica").val();
	var dia = fechaAux.substring(0,2);
	var mes = fechaAux.substring(3,5);
	var a�o = fechaAux.substring(6,10);
	var fechaActual = obtenerFechaActual(0, false);
	var horaActual = obtenerHoraActual(false);
	var tipoTacticaConvertido = compareString($("#tiposTactica").val(), "Capacitaci�n") ? "Capacitaci�n y evento" : $("#tiposTactica").val();
	
	datosParaValidar = "";
	tacticasRepetidas = 0;

	var tipoTactica = obtenerIdCombo(idsTipoTacticaArr, reemplazarTodos(itemsTipoTacticaCompletas, "<option>", "").split("</option>"), tipoTacticaConvertido);
	var modalidad = obtenerModalidad();
	var fechaRegistro = obtenerFechaHoraActual(fechaActual.split("/")[2] + "-" + fechaActual.split("/")[1] + "-" + fechaActual.split("/")[0], horaActual);
	var fechaTactica = a�o + "/" + mes + "/" + dia;
	var nit = $("#nits").val();
	var nombreCliente = $("#nombreCliente").val();
	var responsable = $("#tradersConsultoresResponsables").val();
	var tema = obtenerIdCombo(idsTemaTacticaArr, reemplazarTodos(itemsTemaTactica, "<option>", "").split("</option>"), $("#temaEventoCapacitacionVisita").val());
	var numeroAsistentes = validarAsistentes($("#numeroAsistentesCliente").val());
	var traderAsistente = validarNull($("#traders").val());
	var consultorAsistente = validarNull($("#consultores").val());
	var otroAsistente = validarNull($("#otros").val());
	var observaciones = $("#comentarios").val();
	var origen = obtenerOrigen(responsable);
	
	tema = (tema.localeCompare("") == 0) ? 0 : parseInt(tema);
	
	datosParaValidar = datosParaValidar + "Modalidad='" + modalidad + "' AND IdTipoTactica=" + parseInt(tipoTactica) + " AND FechaTactica=#" + fechaTactica + "# AND Nit='" + nit + "' AND NombreCliente='" + nombreCliente + "' AND IdTemaTactica=" + tema + "AND NumeroAsistentes=" + numeroAsistentes + " AND Realiza='" + responsable + "' AND Observaciones='" + observaciones + "';";
	alert(parseInt(tipoTactica) + ", '" + modalidad + "', '" + fechaRegistro + "', '" + fechaTactica + "', '" + nit + "', '" + nombreCliente + "', '" + responsable + "', " + parseInt(tema) + ", " + numeroAsistentes + ", '" + traderAsistente + "', '" + consultorAsistente + "', '" + otroAsistente + "', '" + observaciones + "', '" + origen + "', false, '" + users.currentUser + "'");
	return parseInt(tipoTactica) + ", '" + modalidad + "', '" + fechaRegistro + "', '" + fechaTactica + "', '" + nit + "', '" + nombreCliente + "', '" + responsable + "', " + parseInt(tema) + ", " + numeroAsistentes + ", '" + traderAsistente + "', '" + consultorAsistente + "', '" + otroAsistente + "', '" + observaciones + "', '" + origen + "', false, '" + users.currentUser + "'";
}

function comprobarUsuarioSube(datos, responsableSeleccionado){
	if (users.currentUser.localeCompare(responsableSeleccionado) != 0){
		if (confirm("Ingresar� una t�ctica comercial para alguien que no es usted, �Desea continuar?")){
			insertarTactica(datos, datosParaValidar);
			a();
		}
	} else{
		insertarTactica(datos, datosParaValidar);
		a();
	}
}

function a(){
	//ocultarModalformulario();

	if (tacticasRepetidas > 0){
		mostrarModalTacticaRepetida();
	} else{
		mostrarModalIngresoTactica();
	}

	validacionCampos = [false, true, false, false, false, true, false, true, true, true, true, true];
	$("#nombreCliente").prop('disabled', false);
	$("#botonReiniciarValores").click();
	actualizarTabla();
	
	/*if (confirm("�Desea continuar registrando t�cticas comerciales?")){
		$('#modalInf').modal('hide');
		$("#botonAbrirFormulario").click();
	}*/
}

function obtenerOrigen(responsable){
	if (isInArray(responsable + "", correoTradersUpper)){
		return "Tesorer�a";
	} else if(isInArray(responsable + "", correoConsultoresUpper)){
		return "Internacional";
	}
}

function actualizarTabla(){
	$('#tablaResultados').dataTable().fnDestroy();
	$('#tablaResultados').html("");
	var datosTabla = consultarTacticas(queries.consultaTacticas + usuariosaMostrar, stringConnections.strConexionFailedOperations);
	// Crea, llena y muestra la tabla
	construirTabla(headers.encabezadosTablaTacticas, datosTabla);
	instanciarTabla();
}

function mostrarModalIngresoTactica(){
	$("#contenidoModalInf").html("La t�ctica fue ingresada satisfactoriamente.");
	$("#tituloModalInf").html("T�ctica agregada");
	$('#modalInf').modal('show');
}

function mostrarModalTacticaRepetida(){
	$("#contenidoModalInf").html("La t�ctica no se ingres� porque ya exist�a.");
	$("#tituloModalInf").html("T�ctica duplicada");
	$('#modalInf').modal('show');
}

function validarNull(valor){
	if (valor == null || valor.localeCompare("null") == 0 || valor.localeCompare(undefined) == 0){
		valor = "";
	}
	
	return valor;
}

function validarAsistentes(num){
	if (num.localeCompare("") == 0){
		return 0;
	} else{
		return parseInt(num);
	}
}

function obtenerIdCombo(idsArr, items, valor){
	for (i = 0; i < idsArr.length; i++){
		if (items[i].localeCompare(valor) == 0){
			return idsArr[i];
		}
	}
	
	return "";
}

function obtenerModalidad(){
	var radioPresencial = $("#labelRadio1");
	var radioVirtual = $("#labelRadio2");

	if (radioPresencial.hasClass("active")){
		return "Presencial";
	} else if (radioVirtual.hasClass("active")){
		return "Virtual";
	}
	
	return "";
}