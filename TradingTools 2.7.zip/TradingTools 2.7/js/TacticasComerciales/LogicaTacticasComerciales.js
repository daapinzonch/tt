/***************************************************************************************************/
/***************************************************************************************************/
/*************************************** VARIABLES *************************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Objetos ActiveX BD
var conexion = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
var command = new ActiveXObject("ADODB.Command");
// Objeto ActiveX para detectar el usuario actual
var red = new ActiveXObject("WScript.Network");
// Objeto ActiveX para acceder a los archivos del sistema
var objetoDeArchivos = new ActiveXObject("Scripting.FileSystemObject");
// Traders y Correo Traders
var tradersUpper = [];var tradersNormal = [];
var correoTradersUpper = [];var correoTradersNormal = [];
var consultoresUpper = [];var consultoresNormal = [];
var correoConsultoresUpper = [];var correoConsultoresNormal = [];
// Usuarios a mostrar tacticas
var usuariosaMostrar = "";
// Ids combos
var idsTipoTactica = "";
var idsTipoTacticaArr = [];
var idsTemaTactica = "";
var idsTemaTacticaArr = [];
// Items de los combos
var itemsTipoTactica = "";
var itemsTipoTacticaCompletas = "";
var itemsTraderConsultorResponsable = "";
var itemsTipoAsistente = "";
var itemsTemaTactica = "";
var itemsTrader = "";
var itemsConsultor = "";
var usuarioActualHomogenizado = "";
var cargoUsuarioActual = "";
var userType = "";
// Arreglos de meses para convertir de numero a texto
var mesesNum = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
var mesesComp = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
// Arreglos para convertir un numero a una celda
var numerosCeldas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
var letrasCeldas = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"];
// Almacena errores de los campos
var error = "";
var erroresCargueMasivo = ["", "", "", "", "", "", "", "", "", "", ""];
// Almacena las validaciones de los campos del formulario
var validacionCampos = [false, true, false, false, false, true, false, true, true, true, true, true];
// Almacena las validaciones de los campos de excel
var validacionCamposExcel = [false, false, false, false, false, false, false, false, false, false, false];
// Almacena la hora que ue se abrio el formulario
var horaFormulario = "";
// Ruta archivo seleccionado para cargue masivo
var rutaArchivoParaCargue = "";
// Variables para cargue masivo
var datosParaSubirDesdeExcel = "";
var datosParaValidar = "";
var filasCargadas = 0;
var tacticasRepetidas = 0;

/***************************************************************************************************/
/***************************************************************************************************/
/******************************** INICIO LOGICA TACTICAS *******************************************/
/***************************************************************************************************/
/***************************************************************************************************/
showMessageLoading("tituloNotificacion", "cuerpoNotificacion");
showLoadingOverlay();

$(document).ready(function() {
	// Put current version
	assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), objetoDeArchivos));
	// Obtiene los traders y los consultores con su correo
	getTradersConsultantsNameAndMail(conexion, recordSet, queries.queryGetTraders, stringConnections.strConexionDataMart, tradersUpper, correoTradersUpper, tradersNormal, correoTradersNormal);
	getTradersConsultantsNameAndMail(conexion, recordSet, queries.queryGetConsultants, stringConnections.strConexionDataMart, consultoresUpper, correoConsultoresUpper, consultoresNormal, correoConsultoresNormal);
	
	usuarioActualHomogenizado = homogenizarUsuario();
	// Get current user type
	userType = getUserType(conexion, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
	// Show modules for user
	showModules(userType);
	// Inserta log cada vez que el usuario ingrese a la p�gina
	insertLog(conexion, "T�cticas Comerciales WEB");
	// Show connected user
	showUserConnected("#connected-user");
	// Users to show Me
	if (compareString(userType, "GerencialT") || compareString(userType, "GerencialI")){
		usuariosaMostrar = consultarUsuariosaMostrar(replaceAll(queries.queryGetUsersByArea, "rUsuario", users.currentUser), stringConnections.strConexionDataMart);
	} else if (compareString(userType, "Administrador")){
		usuariosaMostrar = "";
	} else{
		usuariosaMostrar = consultarUsuariosaMostrar(replaceAll(queries.queryGetUsersToShow, "rUsuario", users.currentUser), stringConnections.strConexionDataMart);
	}
	// Consulta los items de los combos
	obtenerItemsCombos();
	// Agrega los items consultados a los combos
	cargarCombos();
	// Crea y muestra los combos editables
	instanciarCombos();
	// Obtiene ids para insertar a BD
	idsTipoTacticaArr = obtenerIds(idsTipoTactica);
	idsTemaTacticaArr = obtenerIds(idsTemaTactica);
	// Consulta tacticas para mostrarlas
	var datosTabla = consultarTacticas(queries.consultaTacticas + usuariosaMostrar, stringConnections.strConexionFailedOperations);
	// Crea, llena y muestra la tabla
	construirTabla(headers.encabezadosTablaTacticas, datosTabla);
	instanciarTabla();
	// Add Horizontally Scroll on datatable
	putScrollOnTable("#tablaResultados");
	// Change Inputs for consultants
	if (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI") || compareString(userType, "GerencialI")){
		try{
			removeMultiplesOptionsEditableSelect("#tiposTactica", [6, 5, 4, 3, 2, 1]);
			removeMultiplesOptionsEditableSelect("#temaEventoCapacitacionVisita", [4, 3, 1, 0]);
			addOptionEditableSelect("#tiposTactica", "Capacitaci�n");
			assignValue("#temaEventoCapacitacionVisita", "Producto Comercio Exterior");
			validacionCampos[10] = true;
		} catch(e){}
	}
	// Pone a la escucha a los campos del formulario
	cargarEventos();
	// Crea y muestra un DatePicker
	instanciarDatePicker("fechaTactica");
	//Carga la tabla de cumplea�os
	cargarCumplea�os();
	// Oculta el mensaje de inicio
	$("#loading").addClass(' hide');
	$("#contenedorBoton").removeClass(' hide');
	$("#contenedorTabla").removeClass(' hide');
	$("#contenedorTablaCumple").removeClass(' hide');
	// Hide Loading Overlay
	hideLoadingOverlay();
});

/***************************************************************************************************/
/***************************************************************************************************/
/*********************************** FUNCIONES USUARIO *********************************************/
/***************************************************************************************************/
/***************************************************************************************************/

// Convierte un usuario FANGEL1 a F_Angel
function homogenizarUsuario() {
    if (jQuery.inArray(users.currentUser, correoTradersUpper) !== -1) {
        return tradersNormal[correoTradersUpper.indexOf(users.currentUser)];
    } else if (jQuery.inArray(users.currentUser, correoConsultoresUpper) !== -1) {
        return consultoresNormal[correoConsultoresUpper.indexOf(users.currentUser)];
    } else {
        return "";
    }
}

/***************************************************************************************************/
/***************************************************************************************************/
/********************************** FUNCIONES GENERALES ********************************************/
/***************************************************************************************************/
/***************************************************************************************************/
//Carga la tabla de cumplea�os
function cargarCumplea�os(){
	var conexion2 = new ActiveXObject("ADODB.Connection");
	var recordSet2 = new ActiveXObject("ADODB.Recordset");
	conexion.Open(stringConnections.strConexionContactos); 
	recordSet.Open(queries.consultarCumple, conexion);
	var usuariosCumple = [];
	var texto = "";
	while (recordSet.EOF == false){
		// var usuario = new usuario();
		var nit = recordSet(0).Value+"";
		//pasamos a minuscula para que el css ponga las letras capitales
		var nombres = (recordSet(1).Value.split(',')[0]+"").toLowerCase();
		var apellidos = (recordSet(1).Value.split(',')[1] +"").toLowerCase();
		var fecha = recordSet(2).Value+"";
		var dia = fecha.split(',')[0];
		var mes = fecha.split(',')[1];
		mes = cambiarMesLetras(mes);
		var ano = fecha.split(',')[2];
		var email1 = recordSet(3).Value.split(',')[0]+"";
		var email2 = recordSet(3).Value.split(',')[1]+"";
		var query2 = "SELECT DISTINCT UsuarioRol.correo, Clientes.Nombre FROM (Clientes INNER JOIN Geografia ON Clientes.Unidad = Geografia.Unidad) INNER JOIN UsuarioRol ON Geografia.Trader = UsuarioRol.Nombre WHERE Clientes.Nit = '"+nit+"'";
		conexion2.Open(stringConnections.strConexionDataMart); 
		recordSet2.Open(query2, conexion2);
		try{
			var traderCliente = recordSet2(0).Value+"";
			var NombreCliente = recordSet2(1).Value+"";
			if (compareString(userType, "Administrador")){
				//console.log(NombreCumpleCliente(nit));
				texto = "<tr><td style='display:none;'>"+nit+"</td><td style='display:none;'>"+email1+"</td><td style='display:none;'>"+email2+"</td><td>"+NombreCliente+"</td><td>"+nombres+" "+apellidos+"</td><td>"+dia+"/"+mes+"/"+ano+"</td><td><button id='btnEnviarCumple'>Enviar correo</button></td></tr>"
				$('#tablaResultadosCumple').html($('#tablaResultadosCumple').html()+texto);
			}else{
				if(traderCliente == users.currentUser){
					texto = "<tr><td style='display:none;'>"+nit+"</td><td style='display:none;'>"+email1+"</td><td style='display:none;'>"+email2+"</td><td>"+NombreCliente+"</td><td>"+nombres+" "+apellidos+"</td><td>"+dia+"/"+mes+"/"+ano+"</td><td><button id='btnEnviarCumple'>Enviar correo</button></td></tr>"
					$('#tablaResultadosCumple').html($('#tablaResultadosCumple').html()+texto);
				}
			}
		}catch(e){};
		recordSet2.Close(); 
		conexion2.Close();
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	};
//Cambiar mes numero a mes letra (3 primeras) formato mm
function cambiarMesLetras(mes){
	if(mes=='01'){
		return 'Ene'
	}else if(mes=='02'){
		return 'Feb'
	}else if(mes=='03'){
		return 'Mar'
	}else if(mes=='04'){
		return 'Abr'
	}else if(mes=='05'){
		return 'May'
	}else if(mes=='06'){
		return 'Jun'
	}else if(mes=='07'){
		return 'Jul'
	}else if(mes=='08'){
		return 'Ago'
	}else if(mes=='09'){
		return 'Sep'
	}else if(mes=='10'){
		return 'Oct'
	}else if(mes=='11'){
		return 'Nov'
	}else if(mes=='12'){
		return 'Dic'
	}else{return ''}

};
//Mostrar modal enviar correo
var nitCumple = "";
$('#tablaResultadosCumple').on('click',"#btnEnviarCumple",function(e){
	nitCumple = obtenerNitCumplea(e);
	//console.log(nitCumple);
	var email1= obteneremail1Cumplea(e);
	//console.log(email1);
	var email2= obteneremail2Cumplea(e);
	if(email1=="undefined" && email2=="undefined"){
		$("#Correo-To").val("");
	}else if(email1!="undefined"){
		$("#Correo-To").val(email1);
	}else if(email2!="undefined"){
		$("#Correo-To").val(email2);	
	}else{
		$("#Correo-To").val("");
	}
		$("#Correo-From").val(users.currentUser+"@bancodebogota.com.co");
		$("#Correo-Body").val("");
	$('#modalCumple').modal('show');
});
$("#btnEnviarCorreoCumple").on('click',function(){
	//enviar correo con los datos del modal
	var ruta = getLogoCumple();
	abrirOutlookCumple(ruta);
	$('#modalCumple').modal('hide');
	$('#modalConfirmCumple').modal('show');
});
$("#btnSiEnvio").on('click',function(){

	var fechaActual = obtenerFechaActual(0, false);
	var horaActual = obtenerHoraActual(false);
	var dia = fechaActual.substring(0,2);
	var mes = fechaActual.substring(3,5);
	var ano = fechaActual.substring(6,10);
	var tipoTacticaConvertido = "6";
	var nombre = NombreCumpleCliente(nitCumple);
	var datos = tipoTacticaConvertido+", '', '"+ano+"-"+mes+"-"+dia+" "+horaActual+"', '"+ano+"-"+mes+"-"+dia+"', '"+nitCumple+"', '"+nombre+"', '"+users.currentUser+"', 0, 0, '', '', '', '', 'Tesorer�a', false,'"+users.currentUser+"'";
	var consulta = queries.consultaInsertarTactica;
	consulta = reemplazarTodos(consulta,"datos",datos);
	conexion.Open(stringConnections.strConexionFailedOperations);
	try{
		conexion.Execute(consulta);
	} catch(e){
		$("#panelInfoMasiva").removeClass(" panel-success");
		$("#panelInfoMasiva").addClass(" panel-danger");
		$("#tituloInfoMasiva").html("<b>Error inesperado</b>");
		$("#contInfoMasiva").html("Ocurri� un error inesperado mientras se ingresaban las t�cticas");
		alert(e.message);
	}
	conexion.Close();
	$('#modalConfirmCumple').modal('hide');
	$("#modalConfirmRegistroTacticaCumple").modal('show');
});
$("#btnNoEnvio").on('click',function(){
	$('#modalConfirmCumple').modal('hide');
});
function NombreCumpleCliente(nit){
	var consulta = reemplazarTodos(queries.consultaCliente, "rNit", nit + "");
	var bd = stringConnections.strConexionDataMart;
	var cliente = consultarDatamart(consulta, bd);
	cliente = reemplazarTodos(cliente, "<option>", "");
	cliente = reemplazarTodos(cliente, "</option>", "");
	return cliente;
}
function getLogoCumple(){
	var rutaActual = location.pathname;
	rutaActual = rutaActual.substring(1, rutaActual.length);
	rutaActual = replaceAll(rutaActual, "/", "\\");
	rutaActual = replaceAll(rutaActual, "%20", " ");
	// rutaActual = replaceAll(rutaActual, "html\\Vencimientos.html", "img\\logo.png");
	return rutaActual;
}

function reemplazarTodos(texto, textoaBuscar, textoaReemplazar){
	return texto.replace(new RegExp(textoaBuscar, "g"), textoaReemplazar);
}
function obtenerNitCumplea(evento){
		var nit = $(evento.target).closest("tr").find('td:eq(0)').text();
		return nit.trim();
}
function obteneremail1Cumplea(evento){
		var email = $(evento.target).closest("tr").find('td:eq(1)').text();
		return email.trim();
}
function obteneremail2Cumplea(evento){
		var email = $(evento.target).closest("tr").find('td:eq(2)').text();
		return email.trim();
}
function abrirOutlookCumple(rutaImg){
	var	rutaImg = "<img src='" + getLogoCumple().replace('html','img').replace('TacticasComerciales.html','cumple.png') + "'style='width:auto;heigth:auto'>";
	var stringConnection = stringConnections.strConexionDataMart;
	var network = new ActiveXObject('WScript.Network');
	var serverName = network.computerName;
	
	try {
		if (compareString(serverName, "ARIESTES02") || compareString(serverName, "ARIESTES01") || compareString(serverName, "WIN2012P02.banbta.net") || compareString(serverName, "WIN2012P02") || compareString(serverName, "win2012p02")){
			var cdoMsg = new ActiveXObject("CDO.Message");
			cdoMsg.From = $("#Correo-From").val();
			cdoMsg.To = $("#Correo-To").val();
			var textoCuerpo=reemplazarTodos($("#Correo-Body").val(), "\n", "<br>");
			cdoMsg.Subject = "�Feliz Cumplea�os! - Banco de Bogot�";
			cdoMsg.HTMLBody = "<span style='font-family: arial'>Estimado cliente,<br><br>"+textoCuerpo+"<br><br></span>"+rutaImg+"<br><br>";
			var namespace = "http://schemas.microsoft.com/cdo/configuration/";
			cdoMsg.Configuration.Fields.Item(namespace + "sendusing") = 2;
			cdoMsg.Configuration.Fields.Item(namespace + "smtpserver") = "outlook.bancodebogota.net";
			cdoMsg.Configuration.Fields.Item(namespace + "smtpserverport") = 25;
			cdoMsg.Configuration.Fields.Item(namespace + "sendusername") = "Internacional@bancodebogota.com.co";
			cdoMsg.Configuration.Fields.Update();
			cdoMsg.Send();
			$("#contenidoModalInformacion").html("Un correo ha sido enviado a " + users.currentUser + "@bancodebogota.com.co.");
			$("#tituloModalInformacion").html("<b>Env�o satisfactorio</b>");
			$('#modalInformacion').modal('show');
		} else{
			var to = $("#Correo-To").val();
			// Crea y abre una instancia de Outlook
			var outlook = new ActiveXObject('Outlook.Application');
			// Abre una nueva ventana de correo
			var email = outlook.CreateItem(0);
			var textoCuerpo=reemplazarTodos($("#Correo-Body").val(), "\n", "<br>");
			// Agrega Destinatarios
			email.Recipients.Add(to);
			// Asunto
			email.Subject = "�Feliz Cumplea�os! - Banco de Bogot�";
			// Muestra el contenido del correo
			email.Display();
			// Coloca contenido en el correo
			email.HTMLBody = "<span style='font-family: arial'>Estimado cliente,<br><br>"+textoCuerpo+"<br><br></span>"+rutaImg+email.HTMLBody;
		}
	} catch(e) {
		alert(e.message);
		$('#tituloModalError').html('<b>Error</b>');
		$('#contenidoModalError').html('Ocurri� un error al intentar el env�o.');
		$('#modalError').modal('show');
	}
}

// Muestra hora en que se abrio el formulario
function mostrarHoraActual(id){
	var fechaActual = obtenerFechaActual(0, true);
	var horaActual = obtenerHoraActual(true);
	var fechaHoraActuales = obtenerFechaHoraActual(fechaActual, horaActual);
	
	horaFormulario = "<b>" + fechaHoraActuales + "</b>";

	$("#" + id).html(horaFormulario);
}

function obtenerIds(ids){
	ids = reemplazarTodos(ids, "<option>", "");
	return ids.split("</option>");
}

// Reemplaza todas las coincidencias en una cadena por otro otro valor
function reemplazarTodos(texto, textoaBuscar, textoaReemplazar){
	return texto.replace(new RegExp(textoaBuscar, "g"), textoaReemplazar);
}

// Solo permite ingresar valores n�mericos en un campo
function permitirValoresNumericos(e){
	if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 || (e.keyCode === 86 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode === 67 && (e.ctrlKey === true || e.metaKey === true)) || (e.keyCode >= 35 && e.keyCode <= 40)) {
			 return;
	}
	if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
		e.preventDefault();
	}
}

// Mueve el cursor a la �ltima posici�n
function moverCursorUltimaPosicion(id, longitud){
	$('#' + id).focus();
	$('#' + id)[0].setSelectionRange(longitud * 2, longitud * 2);
}

/***************************************************************************************************/
/***************************************************************************************************/
/************************** FUNCIONES DE REINICIO DEL FORMULARIO ***********************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Reinicia los radio buttons de modalidad cada vez que se cambie de opci�n
function reiniciarRadioButtons(){
	$("#labelRadio1").removeClass(" btn-success");
	$("#labelRadio2").removeClass(" btn-success");
	$("#labelRadio1").addClass(" btn-default");
	$("#labelRadio2").addClass(" btn-default");
	$("#labelRadio1").removeClass(" active");
	$("#labelRadio2").removeClass(" active");
}

// Reinicia los estados de validaci�n y los errores de los campos
function reiniciarFormulario(){
	reiniciarEstadosValidacion();
	reiniciarLabels();
}

// Reinicia los estados de validaciones de todos los campos del formulario
function reiniciarEstadosValidacion(){
	var clases = ["has-error", "errorInput", "has-success", "successInput"];
	var ids = ["contenedorComboTiposTactica", "contenedorRadios", "divFechaTactica", "contenedorComboNit", "divNombreCliente", "divNumeroAsistentesCliente", "contenedorComboTradersConsultoresResponsables", "contenedorComboTraders", "contenedorComboConsultores", "contenedorComboOtros", "contenedorComboTemaEventoCapacitacionVisita", "divComentarios", "labelTipoTactica", "labelModalidad", "labelFechaTactica", "labelNits", "labelNombreCliente", "labelNumeroAsistentesCliente", "labelTradersConsultoresResponsables", "labelTraders", "labelConsultores", "labelOtros", "labelTemaEventoCapacitacionVisita", "labelComentarios", "nits", "nombreCliente", "numeroAsistentesCliente", "comentarios"];
	
	removerClases(clases, ids);
}

// Eliminar las clases de error o de correcto para todos los campos del formulario
function removerClases(clases, ids){
	for (i = 0; i < ids.length; i++){
		for (j = 0; j < clases.length; j++){
			$("#" + ids[i]).removeClass(" " + clases[j]);
		}
	}
}

// Reinicia todos los labels a su valor por defecto
function reiniciarLabels(){
	$("#labelTipoTactica").html("Tipo de t�ctica");
	$("#labelModalidad").html("Modalidad");
	$("#labelFechaTactica").html("Fecha de t�ctica");
	$("#labelNits").html("Nit");
	$("#labelNombreCliente").html("Nombre cliente");
	$("#labelNumeroAsistentesCliente").html("N�mero de asistentes del cliente");
	$("#labelTradersConsultoresResponsables").html("Trader o Consultor responsable");
	$("#labelTraders").html("Trader");
	$("#labelConsultores").html("Consultor");
	$("#labelOtros").html("Otro");
	$("#labelTemaEventoCapacitacionVisita").html("Tema de evento, capacitaci�n o visita");
	$("#labelComentarios").html("Tasa Otro Banco");
	$("#labelComentarios").html("Observaciones");
}

// Reinicia los valores de validaci�n al cerrar o reiniciar el formulario
function reiniciarValidacionCampos(){
	validacionCampos = [false, true, false, false, false, true, false, true, true, true, true, true];
}

function reiniciarInputsCargueMasivo(){
	$("#liRecomendaciones").addClass("active");
	$("#liRestricciones").removeClass("active");
	$("#recomendaciones").addClass("active");
	$("#restricciones").removeClass("active");
	$("#recomendaciones").addClass("in");
	$("#restricciones").removeClass("in");
	$("#inputFile").val("");
	$("#inputSinArchivos").val("");
	$("#divBotonCargueMasivoActivado").addClass(" hide");
	$("#divBotonCargueMasivoDesactivado").removeClass("hide");
	validacionCamposExcel = [false, false, false, false, false, false, false, false, false, false, false];
}

function adecuarFormularioParaConsultores(){
	if (compareString(userType, "Consultor")){
		removeMultiplesOptionsEditableSelect("#tiposTactica", [6, 5, 4, 3, 2, 1]);
		removeMultiplesOptionsEditableSelect("#temaEventoCapacitacionVisita", [4, 3, 1, 0]);
		addOptionEditableSelect("#tiposTactica", "Capacitaci�n");
	}
}

/***************************************************************************************************/
/***************************************************************************************************/
/******************************** INSTANCIAS PLUGINS JQUERY ****************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Crea e instancia la tabla
function instanciarTabla(){
	$('#tablaResultados tfoot td').each(function (){$(this).html('<input class="secondFilter" type="text" placeholder="Buscar"/>')});
	
	var myDataTable = $('#tablaResultados').DataTable({
		"lengthMenu": [[7, 15, 30, -1], [7, 15, 30, "Todos"]]
    });
	
	myDataTable.columns().eq(0).each(function (index){
		$('input', myDataTable.column(index).footer()).on('keyup change focusout', function (){
			myDataTable.column(index) .search( this.value ) .draw();
			validateSecondFilter($(this));
		});
	});
}

// Contruye la tabla de las operaciones fallidas
function construirTabla(encabezados, datosTabla){
	var thead = "<thead id='thead'><tr>";
	var tbody = datosTabla;
	
	for(i = 0; i < encabezados.length; i++){
		thead = thead + "<th>" + encabezados[i] + "</th>";
	}
	
	thead = thead + "</tr></thead>";
	
	$("#tablaResultados").append(thead);
	$("#tablaResultados").append(tbody);
}

function instanciarDatePicker(id){
	var date = new Date();
	var day = date.getDate();
	var year = date.getFullYear();
	var month = date.getMonth();
	var maximumDays = day > 8 ? day - 1 : day + 27;

	$("#" + id).datepicker({
		dateFormat : 'dd/mm/yy',
		changeMonth : true,
		//minDate: "-1m",
		minDate: new Date(year, month - 1, '01'),
		changeYear : true,
		beforeShowDay: $.datepicker.noWeekends,
		yearRange: '-1y:c+nn',
		prevText: 'Anterior',
		nextText: 'Siguiente',
		onSelect: function(dateText, inst){
					error = "";
					mostrarValidacionDeCampos(validarFechaTactica(), "fechaTactica", "divFechaTactica", "Fecha de t�ctica", "labelFechaTactica", 2);
				},
		//minDate: maximumDays * -1,
		currentText: 'Hoy',
		monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
		monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
		dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi�rcoles', 'Jueves', 'Viernes', 'S�bado'],
		dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mi�;', 'Juv', 'Vie', 'S�b'],
		dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'S�'],
		maxDate: '-d'
	});
}