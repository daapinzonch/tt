// Variable que almacenar� las diferentes cosultas que se utilizar�n
var consulta = "";

/***************************************************************************************************/
/***************************************************************************************************/
/****************************** CONSULTAS FAILEDOPERATIONS DB **************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Consulta los items de cada combo
function obtenerItemsCombo(consulta, bd){
	conexion.Open(bd);
	recordSet.Open(consulta, conexion);
	
	var items = "";
	
	while (recordSet.EOF == false){
		items = items + "<option>" + recordSet(0) + "</option>";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	return items;
}

// Consulta las t�cticas de un periodo de 1 mes atras
function consultarTacticas(consulta, bd){
	var tacticas = (reemplazarTodos(itemsTipoTacticaCompletas, "<option>", "")).split("</option>");
	
	conexion.Open(bd);
	recordSet.Open(consulta, conexion);
		
	var tbody = "<tbody>";
	var tfoot = "<tfoot><tr>";
	
	for (i = 0; i < 9; i++){tfoot = tfoot + "<td></td>"}
	
	while (recordSet.EOF == false){
		var fecha = new Date(recordSet("FechaTactica"));
		var fechaConFormato = $.datepicker.formatDate('yy/mm/dd', fecha);
		var tbody = tbody + 
					"<tr>" +
						"<td>" + fechaConFormato + "</td>" +
						"<td>" + tacticas[idsTipoTacticaArr.indexOf(recordSet("IdTipoTactica").Value + "")] + "</td>" +
						validarModalidadTraida(recordSet("Modalidad").Value, recordSet("Id").Value) +
						"<td>" + recordSet("Nit") + "</td>" +
						"<td>" + recordSet("NombreCliente") + "</td>" +
						"<td>" + recordSet("Realiza") + "</td>" +
						"<td>" + recordSet("Observacion") + "</td>" + 
						"<td>" + recordSet("UsuarioSubio") + "</td>" + 
						"<td>" + recordSet("Origen") + "</td>" + 
					"</tr>";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	tbody = tbody + "</body>";
	tfoot = tfoot + "</tr></tfoot>";
	
	return tbody + tfoot;
}

function consultarUsuariosaMostrar(query, stringConnection){
	conexion.Open(stringConnection);
	recordSet.Open(query, conexion);
	
	var usuarios = "";
	var entro = false;
	
	while (recordSet.EOF == false){
		entro = true;
		usuarios = usuarios + "'" + recordSet(0).Value + "',";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	return entro ? " AND Realiza IN(" + usuarios.substring(0, usuarios.length - 1) + ")" : "";
}

function insertarTactica(datos, datosParaValidar){
	if (!validarSiTacticaExisteEnBD(datosParaValidar)){
		conexion.Open(stringConnections.strConexionFailedOperations);
		var consulta = queries.consultaInsertarTactica;
		
		consulta = reemplazarTodos(consulta, "datos", datos);
		try{
			conexion.Execute(consulta);
		} catch(e){
			$("#panelInfoMasiva").removeClass(" panel-success");
			$("#panelInfoMasiva").addClass(" panel-danger");
			$("#tituloInfoMasiva").html("<b>Error inesperado</b>");
			$("#contInfoMasiva").html("Ocurri� un error inesperado mientras se ingresaban las t�cticas");
			alert(e.message);
		}
		
		conexion.Close();
	}else{
		tacticasRepetidas = tacticasRepetidas + 1;
	}
}

// Valida si el una t�ctica ya existe en la base de datos
function validarTacticaYaExiste(consulta, bd){
	var yaExiste = false;
	
	conexion.Open(bd);
	try{
		recordSet.Open(consulta, conexion);
	
		while (recordSet.EOF == false){
			yaExiste = true;
			
			recordSet.MoveNext();
		}
		
		recordSet.Close();
	} catch(e){alert("Error validando");}
	
	conexion.Close();
	
	return yaExiste;
}

function actualizarModalidadBD(consulta, bd){
	conexion.Open(bd);
	command.ActiveConnection = conexion;
	command.CommandText = consulta;
	
	try{
		command.Execute();
	} catch(e){
		alert("Ocurri� un error al intentar actualizar en la base de datos");
	}
	
	conexion.Close();
}

/***************************************************************************************************/
/***************************************************************************************************/
/********************************** CONSULTAS DATAMART DB ******************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Consulta los traders, correo traders, consultores y correo consultores
function obtenerTradersOConsultoresConCorreo(consulta, bd, tradersConsultoresArregloUpper, correosArregloUpper, tradersConsultoresArregloNormal, correosArregloNormal){
	conexion.Open(bd);
	recordSet.Open(consulta, conexion);
	
	while (recordSet.EOF == false){
		tradersConsultoresArregloUpper.push((recordSet(0).Value).toUpperCase());
		correosArregloUpper.push((recordSet(1).Value).toUpperCase());
		tradersConsultoresArregloNormal.push(recordSet(0).Value);
		correosArregloNormal.push(recordSet(1).Value);
		
		recordSet.MoveNext();
	}
	
	recordSet.Close();
	conexion.Close();
}

// Consulta los nits que empiecen por un nit especifico
function consultarDatamart(consulta, bd){
	conexion.Open(bd);
	recordSet.Open(consulta, conexion);
	
	var valores = "";
	
	while (recordSet.EOF == false){
		valores = valores + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	
	if (valores.localeCompare("") == 0){
		valores = "No hay resultados";
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	return valores;
}