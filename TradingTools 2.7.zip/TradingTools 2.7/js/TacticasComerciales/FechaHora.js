// Obtiene la hora actual
function obtenerHoraActual(conFormato){
	var horaActual = new Date();
	var formato = obtenerFormatoHora(horaActual);
	
	horaActual = validarHora(horaActual);
	
	if (conFormato){
		horaActual = horaActual + " " + formato;
	}
	
	return horaActual;
}

// Obtiene la fecha actual
function obtenerFechaActual(numeroDias, mesEnLetras){
	var horaActual = new Date();
	var a�o = horaActual.getFullYear();
	var mes = horaActual.getMonth() + 1;
	var dia = horaActual.getDate() - numeroDias;
	
	if (mesEnLetras){
		validarNumero(dia);
		mes = convertirMesALetras(mes);
		
		return dia + " " + mes + " " + a�o;
	} else{
		return revisarFecha(dia, mes, a�o);
	}
}

// Convierte un mes numerico a un mes en letras (Ej: 01 -> Ene)
function convertirMesALetras(mes){
	for (i = 0; i < mesesNum.length; i++){
		if (mes == (i + 1)){
			mes = mesesComp[i];
		}
	}
	
	return mes;
}

// valida si el d�a y mes son menores que 10 y les agrega un 0 antes
function revisarFecha(dia, mes, a�o){
	dia = validarNumero(dia);
	mes = validarNumero(mes);
	
	return dia + "/" + mes + "/" + a�o;
}

// Valida si un n�mero es menor a 10 y le agrega un cero a la izquierda
function validarNumero(num){
	if (num < 10){
		num = "0" + num;
	}
	
	return num;
}

// Obtiene la fecha y la hora actuales
function obtenerFechaHoraActual(fechaActual, horaActual){
	return fechaActual + " " + horaActual;
}

// Valida si una hora es am o pm
function obtenerFormatoHora(hora){
	var formato = "";

	if (hora.getHours() < 12){
		formato = "am";
	} else {
		formato = "pm";
	}
	
	return formato;
}

// valida si los segunods, minutos y horas son menores que 10 y les agrega un 0 antes
function validarHora(hora){
	var horas = "";
	var minutos = "";
	var segundos = "";

	if(hora.getHours() < 10){
		horas = horas + "0" + hora.getHours();
	} else{
		horas = horas + hora.getHours();
	}
	
	if(hora.getMinutes() < 10){
		minutos = minutos + "0" + hora.getMinutes();
	} else{
		minutos = minutos + hora.getMinutes();
	}
	
	if(hora.getSeconds() < 10){
		segundos = segundos + "0" + hora.getSeconds();
	} else{
		segundos = segundos + hora.getSeconds();
	}
	
	return horas + ":" + minutos + ":" + segundos;
}