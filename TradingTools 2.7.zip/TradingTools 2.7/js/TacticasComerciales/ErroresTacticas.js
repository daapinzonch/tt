function obtenerErrorVacio(){return "(No puede estar vac�o)"}
function obtenerErrorNoPertenece(){return "(Valor no pertenece a la lista desplegable)"}
function obtenerErrorAmbosRadios(){return "(Solo una opci�n puede estar seleccionada)"}
function obtenerErrorNingunRadio(){return "(Ning�na opci�n se encuentra seleccionada)"}
function obtenerErrorPunto(){return "(El valor no debe tener puntos)"}
function obtenerErrorCaracterInvalido(caracter){return "(El caracter '" + caracter + "' no es v�lido)"}
function obtenerErrorCambiarValor(){return "(Debe cambiarse este valor)"}
function obtenerErrorTieneEspacios(){return "(No debe tener espacios)"}
function obtenerErrorLongitudFecha(){return "(Debe contener 10 caracteres, recuerde que la estructura es mm/dd/aaaa)"}
function obtenerErrorFechaNoEsNumerica(){return "(El d�a, mes y a�o deben ser n�mericos)"}
function obtenerErrorFechaSinSlash(){return "(La fecha debe tener '/' como separador)"}
function obtenerErrorDiaInvalido(){return "(El d�a debe estar entre 1-31)"}
function obtenerErrorMesInvalido(){return "(El mes debe estar entre 1-12)"}
function obtenerErrorFechaFutura(){return "(La fecha no puede ser mayor que la fecha actual)"}
function obtenerErrorFechaDiferenteA�o(){return "(La fecha debe ser de este a�o)"}
function obtenerErrorDiferenciaUnMes(){return "(La diferencia de meses no debe ser mayor a 1)"}
function obtenerErrorPlazoMaximoSiguienteMes(){return "(El ingreso permite hasta 8 d�as del siguiente mes)"}
function obtenerErrorTama�o(num){return "(El tama�o no debe superar los " + num + " d�gitos)"}
function obtenerErrorEstaVacio(){return "No debe estar vac�a."}
function obtenerErrorValorEscritoTipoTactica(){return "Verique que el valor escrito sea <b>Visita</b>, <b>Informe de Mercado</b>, <b>Chat - Bloomberg</b>, <b>Capacitaci�n y evento</b>, <b>Tarjeta de Cumplea�os</b> o <b>Tarjeta de Navidad</b>."}
function obtenerErrorModalidadNoVacia(){return "Para los tipos de t�ctica <b>Informe de Mercado</b>, <b>Chat - Bloomberg</b>, <b>Tarjeta de Cumplea�os</b> y <b>Tarjeta de Navidad</b> la modalidad debe estar vac�a."}
function obtenerErrorTemaNoVacio(){return "Para los tipos de t�ctica <b>Informe de Mercado</b>, <b>Chat - Bloomberg</b>, <b>Tarjeta de Cumplea�os</b> y <b>Tarjeta de Navidad</b> el tema debe estar vac�o."}
function obtenerErrorNumeroAsistentesNoVacio(){return "Para los tipos de t�ctica <b>Visita</b>, <b>Informe de Mercado</b>, <b>Chat - Bloomberg</b>, <b>Tarjeta de Cumplea�os</b> y <b>Tarjeta de Navidad</b> el n�mero de asistentes debe estar vac�o."}
function obtenerErrorValorEscritoModalidad(){return "El valor escrito debe ser <b>Presencial<b> o <b>Virtual</b>."}
function obtenerErrorValorEscritoTema(){return "El valor escrito debe ser <b>Cartera</b>, <b>Captaci�n</b>, <b>Producto Comercio Exterior</b>, <b>Otro</b> o <b>Productos Mesa de Dinero</b>."}
function obtenerErrorFechaMayor(){return "La fecha no puede ser mayor que la actual."}
function obtenerErrorFechaIncorrecta(){return "Estructura de fecha incorrecta, recuerde que el formato es <b>dd/mm/aaaa</b>."}
function obtenerErrorPuntosComas(){return "El valor escrito no debe contener puntos ni comas."}
function obtenerErrorNoEsNumerico(){return "El valor debe ser numerico"}
function obtenerErrorNoExiteTraderConsultor(){return "Debe coincidir con el usuario de red del trader o consultor</b>"}
function obtenerErrorExcedeTama�o(num){return "Debe contener m�ximo " + num + " caracteres."}
function obtenerErrorNombreConComilla(){return "No puede tener el caracter '."}
function obtenerErrorValorEscritoOrigen(){return "Verique que el valor escrito sea <b>Tesorer�a</b> o <b>Internacional</b>."}