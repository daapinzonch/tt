// Obtiene los datos desde el archivo de excel subido
function obtenerDatosASubir(){
	var Excel = new ActiveXObject("Excel.Application");
	Excel.Visible = false;
	var excelFile = Excel.Workbooks.Open(rutaArchivoParaCargue);
	var excel_sheet = excelFile.Worksheets("Hoja1");
	var datos = "";
	var datosTratados = "";
	var fila = 2;
	var tacticasSonValidas = false;
	var errorCelda = "";
	
	datosParaValidar = "";
	filasCargadas = 0;
	tacticasRepetidas = 0;
	
	try{
		while (true){
			if (excel_sheet.Cells(fila, 3).Value == null && excel_sheet.Cells(fila, 4).Value == null){
				break;
			}
			
			datos = "";
			
			for (i = 1; i < 13; i++){
				datos = datos + excel_sheet.Cells(fila, i).Value + "?";
			}
			
			datosTratados = datosTratados + tratarDatos(datos);
			
			if (!validarEstados()){
				errorCelda = obtenerErrorCamposExcel(fila);
				tacticasSonValidas = false;
				break;
			} else{
				filasCargadas = filasCargadas + 1;
				tacticasSonValidas = true;
			}
			
			validacionCamposExcel = [false, false, false, false, false, false, false, false, false, false, false];
			erroresCargueMasivo = ["", "", "", "", "", "", "", "", "", "", "", ""];
			
			fila = fila + 1;
		}
	} catch(e){
		alert(e.message);
	}
	
	Excel.Application.Quit();
	
	if (tacticasSonValidas){
		return datosTratados.substring(0, datosTratados.length - 1);
	} else{
		return errorCelda;
	}
}

function tratarDatos(datos){
	var datosArr = datos.split("?");
	
	var tipoTacticaExcel = validarTipoTacticaExcel(datosArr[0]);
	var modalidadExcel = validarModalidadExcel(datosArr[1], tipoTacticaExcel);
	var fechaActual = obtenerFechaRegistroTactica();
	var fechaExcel = validarFechaExcel(datosArr[2], datosArr[3], datosArr[4]);
	var nitExcel = validarNitExcel(datosArr[5]);
	var clienteExcel = validarClienteExcel(datosArr[6]);
	var responsableExcel = validarResponsableExcel(datosArr[7]);
	var temaExcel = validarTemaExcel(datosArr[8], tipoTacticaExcel);
	var numAsistentesExcel = validarNumeroAsistentesExcel(datosArr[9], tipoTacticaExcel);
	var observacionesExcel = validarObservacionesExcel(datosArr[10]);
	var origen = validarOrigenExcel(datosArr[11]);
	
	datosParaValidar = datosParaValidar + "Modalidad='" + modalidadExcel + "' AND IdTipoTactica=" + tipoTacticaExcel + " AND FechaTactica=#" + fechaExcel + "# AND Nit='" + nitExcel + "' AND NombreCliente='" + clienteExcel + "' AND IdTemaTactica=" + temaExcel + " AND Realiza='" + responsableExcel + "' AND Observaciones='" + observacionesExcel + "';";
	
	return parseInt(tipoTacticaExcel) + ", '" + modalidadExcel + "', '" + fechaActual + "', '" + fechaExcel + "', '" + nitExcel + "', '" + clienteExcel.toUpperCase() + "', '" + responsableExcel + "', " + parseInt(temaExcel) + ", " + numAsistentesExcel + ", '', '', '', '" + observacionesExcel + "', '" + origen + "', true, '" + users.currentUser + "'" + ";";
}

function insertarTacticasMasivas(datos){
	try{
		var filas = datos.split(";");
		var filasParaConsulta = datosParaValidar.split(";");
		var contadorRepetidas = 0;
	
		for (i = 0; i < filas.length; i++){
			insertarTactica(filas[i], filasParaConsulta[i]);
		}
	} catch(e){
		$("#panelInfoMasiva").removeClass(" panel-success");
		$("#panelInfoMasiva").addClass(" panel-danger");
		$("#tituloInfoMasiva").html("<b>Error inesperado</b>");
		$("#contInfoMasiva").html("Ocurri� un error inesperado mientras se ingresaban las t�cticas");
	}
	
	actualizarTabla();
}

function validarSiTacticaExisteEnBD(condiciones){
	var consulta = queries.consultaExistenciaTactica + condiciones;

	var existe = validarTacticaYaExiste(consulta, stringConnections.strConexionFailedOperations);
	
	if (existe){
		return true;
	} else{
		return false;
	}
}

function mostrarMensajeValidandoCampos(){
	$("#tituloInfoMasiva").html("<b>Validando campos...</b>");
	$("#contInfoMasiva").html("Validando campos del archivo de cargue.");
	$("#panelInfoMasiva").removeClass(" panel-danger");
	$("#panelInfoMasiva").addClass(" panel-success");
}

function validarEstados(){
	if (jQuery.inArray(false, validacionCamposExcel) !== -1){
		return false;	
	} else{
		return true;
	}
}

function obtenerErrorCamposExcel(fila){
	var numError = validacionCamposExcel.indexOf(false);
	var numCelda = numerosCeldas.indexOf(numError) + 1;
	var letraCelda = letrasCeldas[numCelda];
	var errorCampo = erroresCargueMasivo[numError];
	
	return "<b>Error en la celda " + letraCelda + fila + ":</b> " + errorCampo;
}

function obtenerFechaRegistroTactica(){
	var fechaActual = obtenerFechaActual(0, false);
	var horaActual = obtenerHoraActual(false);
	
	return obtenerFechaHoraActual(fechaActual.split("/")[2] + "-" + fechaActual.split("/")[1] + "-" + fechaActual.split("/")[0], horaActual);
}

function obtenerOrigenRegistroTactica(valor){
	if (jQuery.inArray(valor, consultoresNormal) !== -1){
		return "Comex";
	} else if (jQuery.inArray(valor, tradersNormal) !== -1){
		return "Distribucion";
	} else {
		return "";
	}
}

function convertirArregloMayusculas(arreglo){
	var arregloUpper = [];
	
	for (i = 0; i < arreglo.length; i++){
		arregloUpper[i] = arreglo[i].toUpperCase();
	}
	
	return arregloUpper;
}

function convertirPrimeraLetraMayuscula(cadena){
	return cadena.charAt(0).toUpperCase() + cadena.slice(1);
}