/***************************************************************************************************/
/***************************************************************************************************/
/************************************ FUNCIONES COMBOS *********************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Consulta los items de los combos
function obtenerItemsCombos(){
	itemsTipoTactica = obtenerItemsCombo(queries.consultaItemsTipoTactica, stringConnections.strConexionFailedOperations);
	itemsTipoTacticaCompletas = obtenerItemsCombo(queries.consultaItemsTipoTacticaCompletas, stringConnections.strConexionFailedOperations);
	idsTipoTactica = obtenerItemsCombo(queries.consultaIdTipoTactica, stringConnections.strConexionFailedOperations);
	itemsTraderConsultorResponsable = obtenerItemsResponsable();
	itemsTipoAsistente = obtenerItemsCombo(queries.consultaItemsTipoAsistente, stringConnections.strConexionFailedOperations);
	itemsTemaTactica = obtenerItemsCombo(queries.consultaItemsTemaTactica, stringConnections.strConexionFailedOperations);
	idsTemaTactica = obtenerItemsCombo(queries.consultaIdTemaTactica, stringConnections.strConexionFailedOperations);
	itemsTrader = obtenerItemsCombo(queries.consultaItemsTraders, stringConnections.strConexionDataMart);
	itemsConsultor = obtenerItemsCombo(queries.consultaItemsConsultores, stringConnections.strConexionDataMart);
}

// Agrega los items consultados a los combos
function cargarCombos(){
	cargarCombo(itemsTipoTactica, "tiposTactica");
	cargarCombo(itemsTraderConsultorResponsable, "tradersConsultoresResponsables");
	cargarCombo(itemsTipoAsistente, "otros");
	cargarCombo(itemsTemaTactica, "temaEventoCapacitacionVisita");
	cargarCombo(itemsTrader, "traders");
	cargarCombo(itemsConsultor, "consultores");
}

// Crea y muestra los combos editables
function instanciarCombos(){
	instanciarCombo("tiposTactica");
	instanciarCombo("tradersConsultoresResponsables");
	instanciarCombo("nits");
	instanciarCombo("traders");
	instanciarCombo("consultores");
	instanciarCombo("otros");
	instanciarCombo("temaEventoCapacitacionVisita");
}

// Elimina todos los combos
function eliminarCombos(){
	eliminarCombo("tiposTactica");
	eliminarCombo("tradersConsultoresResponsables");
	eliminarCombo("nits");
	eliminarCombo("traders");
	eliminarCombo("consultores");
	eliminarCombo("otros");
	eliminarCombo("temaEventoCapacitacionVisita");
}

// Agrega valores a los combos del formulario
function cargarCombo(valores, id){
	$("#" + id).html(valores);
}

// Crea y muestra un combo editable
function instanciarCombo(id){
	$('#' + id).editableSelect();
}

// Elimina un combo editable
function eliminarCombo(id){
	$('#' + id).editableSelect("destroy");
}

// Vac�a un combo editable
function vaciarCombo(id){
	$('#' + id).editableSelect("clear");
}

/***************************************************************************************************/
/***************************************************************************************************/
/***************************** SUBFUNCIONES OBTENER ITEMS COMBOS ***********************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Valida si el usuario actual es trader o consultor y trae los datos para llenar el combo "Trader / Consultor Responsable"
function obtenerItemsResponsable(){
	var itemsResponsable = "";

	if (cargoUsuarioActual.localeCompare("Trader") == 0){
		itemsResponsable = obtenerValoresConcatenados(correoTradersUpper, itemsResponsable);
	} else if (cargoUsuarioActual.localeCompare("Consultor") == 0){
		itemsResponsable = obtenerValoresConcatenados(correoConsultoresUpper, itemsResponsable);
	} else{
		itemsResponsable = obtenerTradersYConsultoresConcatenados(correoTradersUpper, correoConsultoresUpper, itemsResponsable);
	}
	
	return itemsResponsable;
}

// Obtiene cadena que contiene los valores a cargar en el combo "Trader / Consultor Responsable" con un valor por defecto
function obtenerValoresConcatenados(arreglo, items){
	for (i = 0; i < arreglo.length; i++){
		if (users.currentUser.localeCompare(arreglo[i]) == 0){
			items = items + "<option selected>" + arreglo[i] + "</option>";
		} else{
			items = items + "<option>" + arreglo[i] + "</option>";
		}
	}
	
	return items;
}

// Obtiene cadena que contiene los valores a cargar en el combo "Trader / Consultor Responsable"
function obtenerTradersYConsultoresConcatenados(arreglo1, arreglo2, items){
	for (i = 0; i < arreglo1.length; i++){
		items = items + "<option>" + arreglo1[i] + "</option>";
	}
	
	for (i = 0; i < arreglo2.length; i++){
		items = items + "<option>" + arreglo2[i] + "</option>";
	}
	
	return items;
}