/*			VARIABLES		*/
// Objetos ActiveX BD
var conexion = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
var command = new ActiveXObject("ADODB.Command");
// Objeto ActiveX para detectar el usuario actual
var red = new ActiveXObject("WScript.Network");
// Objeto ActiveX para acceder a los archivos del sistema
var objetoDeArchivos = new ActiveXObject("Scripting.FileSystemObject");
// Traders y Correo Traders
var tradersUpper = [];var tradersNormal = [];
var correoTradersUpper = [];var correoTradersNormal = [];
var consultoresUpper = [];var consultoresNormal = [];
var correoConsultoresUpper = [];var correoConsultoresNormal = [];
// Usuarios a mostrar tacticas
var usuariosaMostrar = "";

/* 			INICIO LOGICO	*/
//showMessageLoading("tituloNotificacion", "cuerpoNotificacion");
//showLoadingOverlay();

$(document).ready(function(){
	//assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), objetoDeArchivos));


}