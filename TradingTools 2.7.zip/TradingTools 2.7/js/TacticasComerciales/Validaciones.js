/***************************************************************************************************/
/***************************************************************************************************/
/*************************** VALIDACI�N DE CADA UNO DE LOS CAMPOS **********************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Valida el campo "Tipo de T�ctica" cada vez que deje de tener el foco
function validarTipoTactica(){
	var tipoTactica = compareString($("#tiposTactica").val(), "Capacitaci�n") ? "Capacitaci�n y evento" : $("#tiposTactica").val();
	var pertenece;
	
	if (tipoTactica.localeCompare("Visita") == 0){
		$("#horaActual").html(horaFormulario + "<br><b>Tenga en cuenta que:</b> El registro de visitas en este m�dulo es exclusivo para PYME y en casos excepcionales para Banca Empresas. El registro por este medio no sustituye el registro en CRM.");
	} else{
		$("#horaActual").html(horaFormulario);
	}
	
	mostrarOcultarCampos(tipoTactica);
	activarDesactivarRadios(tipoTactica);
	reiniciarCombos(tipoTactica);
	removerEstadosDeValidacion(tipoTactica);
	
	if (tipoTactica.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	pertenece = validarItemPertenece(itemsTipoTactica, tipoTactica);
	
	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;	
}

// Valida el valor escrito o seleccionado en el combo fecha
function validarFechaTactica(){
	var fecha = $("#fechaTactica").val();
	var diaTexto = fecha.substring(0,2);
	var mesTexto = fecha.substring(3,5);
	var a�oTexto = fecha.substring(6,10);
	var diaNum = parseInt(diaTexto);
	var mesNum = parseInt(mesTexto);
	var a�oNum = parseInt(a�oTexto);
	var primerSlash = fecha.charAt(2);
	var segundoSlash = fecha.charAt(5);
	var fechaActualArr = (obtenerFechaActual(0, false)).split("/");
	var diaActual = fechaActualArr[0];
	var mesActual = fechaActualArr[1];
	var a�oActual = fechaActualArr[2];
	
	if (fecha.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	if (fecha.length != 10){
		error = obtenerErrorLongitudFecha();
		return false;
	}
	
	if (primerSlash.localeCompare("/") != 0 || segundoSlash.localeCompare("/") != 0){
		error = obtenerErrorFechaSinSlash();
		return false;
	}
	
	if (diaNum > 31 || diaNum < 1){
		error = obtenerErrorDiaInvalido();
		return false;
	}
	
	if (mesNum > 12 || mesNum < 1){
		error = obtenerErrorMesInvalido();
		return false;
	}

    /******************************************************************/
    /******************************************************************/
    /******************************************************************/

	if (parseInt(a�oActual) - a�oNum > 1){
		error = obtenerErrorFechaDiferenteA�o();
		return false;
	} else{
		if (parseInt(mesActual) - mesNum > 1){
			error = obtenerErrorDiferenciaUnMes();
			return false;
		} /*else if (parseInt(mesActual) - mesNum == 1){
			if (parseInt(diaActual) > 8 && parseInt(diaActual) < diaNum){
				error = obtenerErrorPlazoMaximoSiguienteMes();
				return false;
			}
			
		}*/
	}

	if (parseInt(a�oActual) < a�oNum) {
	    error = "La fecha no puede ser mayor a la fecha actual";
	    return false;
	} else {
	    if (parseInt(mesActual) < mesNum && parseInt(mesActual) != 1) {
	        error = "La fecha no puede ser mayor a la fecha actual";
	        return false;
	    } else {
	        if (parseInt(diaActual) < diaNum && parseInt(mesActual) == mesNum) {
	            error = "La fecha no puede ser mayor a la fecha actual";
	            return false;
             }
        }
    }

    /******************************************************************/
    /******************************************************************/
    /******************************************************************/
	
	error = "";
	return true;
}

// Valida el valor escrito o seleccionado en el combo nit
function validarNit(){
	var nit = $("#nits").val();
	var contadorPuntos = 0;
	
	if (nit.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < nit.length; i++){
		if (nit.charAt(i) == "."){
			contadorPuntos = contadorPuntos + 1;
		}
	}
	
	if (contadorPuntos > 0){
		error = obtenerErrorPunto();
		return false;
	}
	
	error = "";
	return true;
}

// Valida el valor escrito o seleecionado en el campo Numero de asistentes
function validarNumeroAsistentes(){
	var numeroAsistentes = $("#numeroAsistentesCliente").val();
	var contadorPuntos = 0;
	
	if (numeroAsistentes.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < numeroAsistentes.length; i++){
		if (numeroAsistentes.charAt(i) == "."){
			contadorPuntos = contadorPuntos + 1;
		}
	}
	
	if (contadorPuntos > 0){
		error = obtenerErrorPunto();
		return false;
	}
	
	error = "";
	return true;
}

// Valida el valor escrito en el campo cliente
function validarCliente(){
	var cliente = $("#nombreCliente").val();
	
	if (cliente.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < cliente.length; i++){
		if (cliente.charAt(i) == "'"){
			error = obtenerErrorNombreConComilla();
			return false;
		}
	}
	
	if (cliente.localeCompare("No se encontr� cliente para el nit introducido") == 0){
		error = "";
		return false;
	}
	
	error = "";
	return true;
}

// Valida el valor escrito o seleccionado en el combo Trader / Consultor Responsable
function validarTraderConsultorResponsable(){
	var traderConsultorResponsable = $("#tradersConsultoresResponsables").val();
	var pertenece;
	
	if (traderConsultorResponsable.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	pertenece = validarItemPertenece(itemsTraderConsultorResponsable, traderConsultorResponsable);
	
	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;	
}

// Valida el valor escrito o seleccionado en el combo Trader Asistente
function validarTraderAsistente(){
	var traderAsistente = $("#traders").val();
	var pertenece;

	pertenece = validarItemPertenece(itemsTrader, traderAsistente);

	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;	
}

// Valida el valor escrito o seleccionado en el combo Consultor Asistente
function validarConsultorAsistente(){
	var consultorAsistente = $("#consultores").val();
	var pertenece;

	pertenece = validarItemPertenece(itemsConsultor, consultorAsistente);

	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;	
}

// Valida el valor escrito o seleccionado en el combo Otro Asistente
function validarOtroAsistente(){
	var otroAsistente = $("#otros").val();
	var pertenece;

	pertenece = validarItemPertenece(itemsTipoAsistente, otroAsistente);

	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;	
}

// Valida el valor escrito o seleccionado en el combo Tema
function validarTema(){
	var tema = $("#temaEventoCapacitacionVisita").val();
	var pertenece;

	pertenece = validarItemPertenece(itemsTemaTactica, tema);

	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	if (tema.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	error = "";
	return true;	
}

// Valida el valor escrito o seleccionado en el combo Observaciones
function validarComentariosForm(){
	var observaciones = $("#comentarios").val();
	
	for (i = 0; i < observaciones.length; i++){
		if (observaciones.charAt(i) == "'"){
			error = obtenerErrorNombreConComilla();
			return false;
		}
	}
	
	error = "";
	return true;
}

/***************************************************************************************************/
/***************************************************************************************************/
/********************** VALIDACI�N DE CADA UNO DE LOS CAMPOS DE EXCEL ******************************/
/***************************************************************************************************/
/***************************************************************************************************/
function validarTipoTacticaExcel(valor){
	var posiblesValoresChat = ["CHAT- BLOOMBERG", "CHAT BLOOMBERG", "CHAT  BLOOMBERG", "CHAT - BLOOMBERG", "CHAT-BLOOMBERG", "CHAT -BLOOMBERG", "CHATBLOOMBERG", "CHAT DE BLOOMBERG", "CHAT/BLOOMBERG", "CHAT /BLOOMBERG", "CHAT/ BLOOMBERG", "CHAT / BLOOMBERG"];
	var posiblesValoresInforme = ["INFORME DE MERCADO", "INFORME MERCADO", "INFORMEMERCADO", "INFORME  MERCADO", "INFORMEDEMERCADO"];
	var posiblesValoresCapacitacion = ["CAPACITACI�N Y EVENTO", "CAPACITACION Y EVENTO", "CAPACITACI�N", "CAPACITACION", "EVENTO", "CAPACITACI�N EVENTO", "CAPACITACI�N  EVENTO","CAPACITACION EVENTO", "CAPACITACION  EVENTO"];
	var posiblesValoresTarjetaNavidad = ["TARJETA DE NAVIDAD", "TARJETANAVIDAD", "TARJETA  NAVIDAD", "NAVIDAD"];
	var posiblesValoresVisita = ["VISITA", "V�SITA", "VIS�TA", "VISIT�", "VISITAA", "VIISTA", "VISTIA"];
	var posiblesValoresTarjetaCumpleanos = ["TARJETA DE CUMPLEA�OS", "TARJETACUMPLEA�OS", "TARJETA  CUMPLEA�OS", "TARJETA CUMPLEA�OS"];;
	
	if (valor.localeCompare(undefined) == 0){
		validacionCamposExcel[0] = false;
		erroresCargueMasivo[0] = obtenerErrorEstaVacio();
		return 0;
	}
	
	var tipoTactica = "";

	if (jQuery.inArray(valor.toUpperCase(), posiblesValoresChat) !== -1){
		var tipoTactica = "CHAT - BLOOMBERG";
	} else if (jQuery.inArray(valor.toUpperCase(), posiblesValoresInforme) !== -1){
		var tipoTactica = "INFORME DE MERCADO";
	} else if (jQuery.inArray(valor.toUpperCase(), posiblesValoresCapacitacion) !== -1){
		var tipoTactica = "CAPACITACI�N Y EVENTO";
	} else if (jQuery.inArray(valor.toUpperCase(), posiblesValoresTarjetaNavidad) !== -1){
		var tipoTactica = "TARJETA DE NAVIDAD";
	} else if (jQuery.inArray(valor.toUpperCase(), posiblesValoresVisita) !== -1){
		var tipoTactica = "VISITA";
	} else if (jQuery.inArray(valor.toUpperCase(), posiblesValoresTarjetaCumpleanos) !== -1){
		var tipoTactica = "TARJETA DE CUMPLEA�OS";
	} else{
		validacionCamposExcel[0] = false;
		erroresCargueMasivo[0] = obtenerErrorValorEscritoTipoTactica();
		return 0;
	}

	tipoTactica = obtenerIdDesdeTactica(tipoTactica) + "";
	
	if (tipoTactica.localeCompare(undefined) == 0){
		validacionCamposExcel[0] = false;
		erroresCargueMasivo[0] = obtenerErrorValorEscritoTipoTactica();
		return 0;
	} else {
		validacionCamposExcel[0] = true;
		erroresCargueMasivo[0] = "";
		return parseInt(tipoTactica);
	}
}

function validarModalidadExcel(valor, tipoTactica){
	var modalidadUpper = valor.toUpperCase();
	
	if (tipoTactica == 6 || tipoTactica == 7 || tipoTactica == 8 || tipoTactica == 9){
		if (valor.localeCompare(undefined) == 0){
			validacionCamposExcel[1] = true;
			erroresCargueMasivo[1] = "";
			return validarNull(valor);
		} else{
			validacionCamposExcel[1] = false;
			erroresCargueMasivo[1] = obtenerErrorModalidadNoVacia();
			return "error";
		}
	} else if(tipoTactica == 2 || tipoTactica == 1){
		if (valor.localeCompare(undefined) == 0){
			validacionCamposExcel[1] = false;
			erroresCargueMasivo[1] = obtenerErrorEstaVacio();
			return "error";
		} else{
			if (modalidadUpper.localeCompare("PRESENCIAL") == 0 || modalidadUpper.localeCompare("VIRTUAL") == 0){
				validacionCamposExcel[1] = true;
				erroresCargueMasivo[1] = "";
				
				return convertirPrimeraLetraMayuscula(modalidadUpper.toLowerCase());
			} else{
				validacionCamposExcel[1] = false;
				erroresCargueMasivo[1] = obtenerErrorValorEscritoModalidad();
				return "error";
			}
		}	
	}
	
	/*validacionCamposExcel[1] = true;
	erroresCargueMasivo[1] = "";
	return valor;*/
}

function validarFechaExcel(dia, mes, a�o){

	if (dia == undefined || compareString(dia, "")){
		validacionCamposExcel[2] = false;
		erroresCargueMasivo[2] = obtenerErrorEstaVacio();
		return "error";
	} else if (mes == undefined || compareString(mes, "")){
		validacionCamposExcel[3] = false;
		erroresCargueMasivo[3] = obtenerErrorEstaVacio();
		return "error";
	} else if (a�o == undefined || compareString(a�o, "")){
		validacionCamposExcel[4] = false;
		erroresCargueMasivo[4] = obtenerErrorEstaVacio();
		return "error";
	} else if (parseInt(dia) < 1 || parseInt(dia) > 31){
		validacionCamposExcel[2] = false;
		erroresCargueMasivo[2] = obtenerErrorDiaInvalido();
		return "error";
	} else if (parseInt(mes) < 1 || parseInt(mes) > 12){
		validacionCamposExcel[3] = false;
		erroresCargueMasivo[3] = obtenerErrorMesInvalido();
		return "error";
	} else if(!isFinite(dia)){
		validacionCamposExcel[2] = false;
		erroresCargueMasivo[2] = "El d�a debe ser num�rico.";
		return "error";
	} else if(!isFinite(mes)){
		validacionCamposExcel[3] = false;
		erroresCargueMasivo[3] = "El mes debe ser num�rico.";
		return "error";
	} else if(!isFinite(a�o)){
		validacionCamposExcel[4] = false;
		erroresCargueMasivo[4] = "El a�o debe ser num�rico.";
		return "error";
	} else{
		var fechaActual = new Date();
		var a�oActual = fechaActual.getFullYear();
		var mesActual = fechaActual.getMonth() + 1;
		var diaActual = fechaActual.getDate();
		
		if (a�o > a�oActual || (a�o > a�oActual && mes > mesActual) || (a�o > a�oActual && mes > mesActual && dia > diaActual)){
			validacionCamposExcel[2] = false;
			validacionCamposExcel[3] = false;
			validacionCamposExcel[4] = false;
			erroresCargueMasivo[2] = obtenerErrorFechaMayor();
			erroresCargueMasivo[3] = obtenerErrorFechaMayor();
			erroresCargueMasivo[4] = obtenerErrorFechaMayor();
			return "error";
		}
	
		validacionCamposExcel[2] = true;
		validacionCamposExcel[3] = true;
		validacionCamposExcel[4] = true;
		erroresCargueMasivo[2] = "";
		erroresCargueMasivo[3] = "";
		erroresCargueMasivo[4] = "";
		
		return a�o + "-" + validarNumero(mes) + "-" + validarNumero(dia);
	}
}

function validarNitExcel(valor){
	if (valor.localeCompare(undefined) == 0){
		validacionCamposExcel[5] = false;
		erroresCargueMasivo[5] = obtenerErrorEstaVacio();
		return "error";
	} else{
		for (i = 0; i < valor.length; i++){
			if (valor.charAt(i) == '.' || valor.charAt(i) == ','){
				validacionCamposExcel[5] = false;
				erroresCargueMasivo[5] = obtenerErrorPuntosComas();
				return "error";
			}
		}
		
		if (valor.length > 12){
			validacionCamposExcel[5] = false;
			erroresCargueMasivo[5] = obtenerErrorExcedeTama�o(12);
			return "error";
		}
		
		if (valor.length < 5){
			validacionCamposExcel[5] = false;
			erroresCargueMasivo[5] = "Debe contener m�nimo 5 caracteres.";
			return "error";
		}
		
		if (!isFinite(valor)){
			validacionCamposExcel[5] = false;
			erroresCargueMasivo[5] = obtenerErrorNoEsNumerico();
			return "error";
		}
		
		validacionCamposExcel[5] = true;
		erroresCargueMasivo[5] = "";
		return validarNull(valor);
	}
}

function validarClienteExcel(valor){
	if (valor.localeCompare(undefined) == 0){
		validacionCamposExcel[6] = false;
		erroresCargueMasivo[6] = obtenerErrorEstaVacio();
		return "error";
	}
	
	for (i = 0; i < valor.length; i++){
		if (valor.charAt(i) == "'"){
			validacionCamposExcel[6] = false;
			erroresCargueMasivo[6] = obtenerErrorNombreConComilla();
			return "error";
		}
	}

	validacionCamposExcel[6] = true;
	erroresCargueMasivo[6] = "";
	return validarNull(valor);
}

function validarResponsableExcel(valor){
	if (valor.localeCompare(undefined) == 0){
		validacionCamposExcel[7] = false;
		erroresCargueMasivo[7] = obtenerErrorEstaVacio();
		return "error";
	} else{
		if (jQuery.inArray(valor.toUpperCase(), correoTradersUpper) !== -1){
			validacionCamposExcel[7] = true;
			erroresCargueMasivo[7] = "";
			return correoTradersUpper[correoTradersUpper.indexOf(valor.toUpperCase())];
		} else if (jQuery.inArray(valor.toUpperCase(), correoConsultoresUpper) !== -1){
			validacionCamposExcel[7] = true;
			erroresCargueMasivo[7] = "";
			return correoConsultoresUpper[correoConsultoresUpper.indexOf(valor.toUpperCase())];
		} else{
			validacionCamposExcel[7] = false;
			erroresCargueMasivo[7] = obtenerErrorNoExiteTraderConsultor();
			return "error";
		}
	}
	
	/*validacionCamposExcel[6] = true;
	erroresCargueMasivo[6] = "";
	return valor;*/
}

function validarTemaExcel(valor, tipoTactica){
	if (tipoTactica == 6 || tipoTactica == 7 || tipoTactica == 8 || tipoTactica == 9){
		if (valor.localeCompare(undefined) == 0){
			validacionCamposExcel[8] = true;
			erroresCargueMasivo[8] = "";
			return 0;
		} else{
			validacionCamposExcel[8] = false;
			erroresCargueMasivo[8] = obtenerErrorTemaNoVacio();
			return "error";
		}
	} else if(tipoTactica == 2 || tipoTactica == 1){
		if (valor.localeCompare(undefined) == 0){
			validacionCamposExcel[8] = false;
			erroresCargueMasivo[8] = obtenerErrorEstaVacio();
			return 0;
		}
	
		var tema = obtenerIdDesdeTema(valor);
		
		if (tema == undefined){
			validacionCamposExcel[8] = false;
			erroresCargueMasivo[8] = obtenerErrorValorEscritoTema();
			return 0;
		} else{
			validacionCamposExcel[8] = true;
			erroresCargueMasivo[8] = "";
			return tema;
		}
	}
	
	/*if (valor.localeCompare(undefined) == 0){
		validacionCamposExcel[7] = true;
		erroresCargueMasivo[7] = "";
		return 0;
	}
	
	var tema = obtenerIdDesdeTema(valor);
		
	if (tema == undefined){
		validacionCamposExcel[7] = false;
		erroresCargueMasivo[7] = obtenerErrorValorEscritoTema();
		return 0;
	} else{
		validacionCamposExcel[7] = true;
		erroresCargueMasivo[7] = "";
		return tema;
	}*/
}

function validarNumeroAsistentesExcel(valor, tipoTactica){
	if (tipoTactica == 6 || tipoTactica == 7 || tipoTactica == 8 || tipoTactica == 9 || tipoTactica == 1){
		if (valor.localeCompare(undefined) == 0){
			validacionCamposExcel[9] = true;
			erroresCargueMasivo[9] = "";
			return 0;
		} else{
			validacionCamposExcel[9] = false;
			erroresCargueMasivo[9] = obtenerErrorNumeroAsistentesNoVacio();
			return "error";
		}
	} else if(tipoTactica == 2){
		if (valor.localeCompare(undefined) == 0){
			validacionCamposExcel[9] = false;
			erroresCargueMasivo[9] = obtenerErrorEstaVacio();
			return 0;
		} else{
			for (i = 0; i < valor.length; i++){
				if (valor.charAt(i) == '.' || valor.charAt(i) == ','){
					validacionCamposExcel[9] = false;
					erroresCargueMasivo[9] = obtenerErrorPuntosComas();
					return 0;
				}
			}
			
			if (valor.length > 2){
				validacionCamposExcel[9] = false;
				erroresCargueMasivo[9] = obtenerErrorExcedeTama�o(2);
				return "error";
			}
		
			if (isFinite(valor)){
				validacionCamposExcel[9] = true;
				erroresCargueMasivo[9] = "";
				return parseInt(valor);
			} else{
				validacionCamposExcel[9] = false;
				erroresCargueMasivo[9] = obtenerErrorNoEsNumerico();
				return 0;
			}
		}
	}
	
	/*if (isFinite(valor)){
		validacionCamposExcel[8] = true;
		erroresCargueMasivo[8] = "";
		return parseInt(valor);
	} else{
		validacionCamposExcel[8] = true;
		erroresCargueMasivo[8] = obtenerErrorNoEsNumerico();
		return 0;
	}*/
}

function validarObservacionesExcel(valor){
	for (i = 0; i < valor.length; i++){
		if (valor.charAt(i) == "'"){
			validacionCamposExcel[10] = false;
			erroresCargueMasivo[10] = obtenerErrorNombreConComilla();
			return "error";
		}
	}

	validacionCamposExcel[10] = true;
	erroresCargueMasivo[10] = "";
	return validarNull(valor);
}

function validarOrigenExcel(valor){
	var posiblesValoresOrigen = ["INTERNACIONAL", "INTER NACIONAL", "INTER  NACIONAL"];
	var posiblesValoresOrigen2 = ["TESORERIA", "TESORER�A"];

	if (valor.localeCompare(undefined) == 0){
		validacionCamposExcel[11] = false;
		erroresCargueMasivo[11] = obtenerErrorEstaVacio();
		return "Error";
	} else{
		if (jQuery.inArray(valor.toUpperCase(), posiblesValoresOrigen) !== -1){
			validacionCamposExcel[11] = true;
			erroresCargueMasivo[11] = "";
			return "Internacional";
		} else if (jQuery.inArray(valor.toUpperCase(), posiblesValoresOrigen2) !== -1){
			validacionCamposExcel[11] = true;
			erroresCargueMasivo[11] = "";
			return "Tesorer�a";
		} else{
			validacionCamposExcel[11] = false;
			erroresCargueMasivo[11] = obtenerErrorValorEscritoOrigen();
			return "Error";
		}
	}
}

/***************************************************************************************************/
/***************************************************************************************************/
/********************************** ESTADOS DE VALIDACI�N ******************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Muestra estado del campo, su error y activa o desactiva el bot�n de insertar
function mostrarValidacionDeCampos(esValido, idCampo, contenedorCampo, textoLabel, idLabel, numCampo){
	if (esValido){
		validacionCampos[numCampo] = true;
	} else{
		validacionCampos[numCampo] = false;
	}

	mostrarEstadoCampo(esValido, idCampo, contenedorCampo);
	mostrarErrorCampo(textoLabel, idLabel);
	cambiarEstadoBoton();
}

// Pinta de rojo(error) o verde(satisfactorio) el combo y su label
function mostrarEstadoCampo(esValido, idCombo, idContenedor){
	if (esValido){
		$("#" + idContenedor).removeClass(" has-error");
		$("#" + idCombo).removeClass(" errorInput");
		$("#" + idContenedor).addClass(" has-success");
		$("#" + idCombo).addClass(" successInput");
	} else {
		$("#" + idContenedor).removeClass(" has-success");
		$("#" + idCombo).removeClass(" successInput");
		$("#" + idContenedor).addClass(" has-error");
		$("#" + idCombo).addClass(" errorInput");
	}
}

// Muestra el error de los campos
function mostrarErrorCampo(nombreCampo, idLabel){
	$("#" + idLabel).html(nombreCampo + " " + error);
}

/***************************************************************************************************/
/***************************************************************************************************/
/******************************** ESTADOS DEL BOT�N INSERTAR ***************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Activa o desactiva el bot�n de insertar
function cambiarEstadoBoton(){
	var estado = true;

	for (i = 0; i < validacionCampos.length; i++){
		if (validacionCampos[i] == false){
			desactivarBotonEnviar();
			estado = false;
			
			break;
		}
	}

	if (estado){
		activarBotonEnviar();
	}
}

// Activa bot�n de insertar
function activarBotonEnviar(){
	$("#divBotonInsertarDesactivado").addClass(" hide");
	$("#divBotonInsertarActivado").removeClass(" hide");
}

// Desactiva bot�n de insertar
function desactivarBotonEnviar(){
	$("#divBotonInsertarActivado").addClass(" hide");
	$("#divBotonInsertarDesactivado").removeClass(" hide");
}

/***************************************************************************************************/
/***************************************************************************************************/
/********************************** OCULTAR Y MOSTRAR CAMPOS ***************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Muestra u oculta los campos dependiendo de la opci�n seleccionada en el campo tipo de tactica
function mostrarOcultarCampos(valor){
	if (valor.localeCompare("Capacitaci�n y evento") == 0 || valor.localeCompare("Capacitaci�n") == 0){
		removerClase("contenedorRadios", "hide");
		removerClase("divNumeroAsistentesCliente", "hide");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("contenedorCombosOtrosAsistentes", "hide");
		validacionCampos[5] = false;
		validacionCampos[10] = compareString(userType, "Consultor") ? true : false;
	} else if (valor.localeCompare("Contacto Social") == 0){
		removerClase("divNumeroAsistentesCliente", "hide");
		removerClase("contenedorCombosOtrosAsistentes", "hide");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("contenedorRadios", "hide");
		validacionCampos[5] = false;
		validacionCampos[10] = false;
	} else if (valor.localeCompare("Regalo cliente Nuevo") == 0){
		ponerClase("contenedorRadios", "hide");
		ponerClase("divNumeroAsistentesCliente", "hide");
		ponerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("contenedorCombosOtrosAsistentes", "hide");
		validacionCampos[5] = true;
		validacionCampos[10] = true;
	} else if (valor.localeCompare("Regalo de cumplea�os") == 0){
		ponerClase("contenedorRadios", "hide");
		ponerClase("divNumeroAsistentesCliente", "hide");
		ponerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("contenedorCombosOtrosAsistentes", "hide");
		validacionCampos[5] = true;
		validacionCampos[10] = true;
	} else if (valor.localeCompare("Tarjeta de Cumplea�os") == 0){
		ponerClase("contenedorRadios", "hide");
		ponerClase("divNumeroAsistentesCliente", "hide");
		ponerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("contenedorCombosOtrosAsistentes", "hide");
		validacionCampos[5] = true;
		validacionCampos[10] = true;
	} else if (valor.localeCompare("Visita") == 0){
		removerClase("contenedorRadios", "hide");
		removerClase("contenedorCombosOtrosAsistentes", "hide");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("divNumeroAsistentesCliente", "hide");
		validacionCampos[5] = true;
		validacionCampos[10] = compareString(userType, "Consultor") ? true : false;
	} else{
		ponerClase("contenedorRadios", "hide");
		ponerClase("divNumeroAsistentesCliente", "hide");
		ponerClase("contenedorComboTemaEventoCapacitacionVisita", "hide");
		ponerClase("contenedorCombosOtrosAsistentes", "hide");
		validacionCampos[5] = true;
		validacionCampos[10] = true;
	}
}

function removerClase(id, clase){
	$("#" + id).removeClass(clase);
}

function ponerClase(id, clase){
	$("#" + id).addClass(clase);
}

function activarDesactivarRadios(valor){
	if (valor.localeCompare("Capacitaci�n y evento") == 0 || valor.localeCompare("Capacitaci�n") == 0){
		removerClase("labelRadio1", "btn-default");
		ponerClase("labelRadio1", "btn-success");
		ponerClase("labelRadio1", "active");
	} else if (valor.localeCompare("Contacto Social") == 0){
		ponerClase("labelRadio1", "btn-default");
		removerClase("labelRadio1", "btn-success");
		removerClase("labelRadio1", "active");
	} else if (valor.localeCompare("Regalo cliente Nuevo") == 0){
		ponerClase("labelRadio1", "btn-default");
		removerClase("labelRadio1", "btn-success");
		removerClase("labelRadio1", "active");
	} else if (valor.localeCompare("Regalo de cumplea�os") == 0){
		ponerClase("labelRadio1", "btn-default");
		removerClase("labelRadio1", "btn-success");
		removerClase("labelRadio1", "active");
	} else if (valor.localeCompare("Tarjeta de Cumplea�os") == 0){
		ponerClase("labelRadio1", "btn-default");
		removerClase("labelRadio1", "btn-success");
		removerClase("labelRadio1", "active");
	} else if (valor.localeCompare("Visita") == 0){
		removerClase("labelRadio1", "btn-default");
		ponerClase("labelRadio1", "btn-success");
		ponerClase("labelRadio1", "active");
	} else{
		ponerClase("labelRadio1", "btn-default");
		removerClase("labelRadio1", "btn-success");
		removerClase("labelRadio1", "active");
	}
}

function reiniciarCombos(valor){
	if (valor.localeCompare("Capacitaci�n y evento") == 0 || valor.localeCompare("Capacitaci�n") == 0){
		eliminarCombo("traders");
		eliminarCombo("consultores");
		eliminarCombo("otros");
		$("#traders").val("");
		$("#consultores").val("");
		$("#otros").val("");
		instanciarCombo("temaEventoCapacitacionVisita");
	} else if (valor.localeCompare("Contacto Social") == 0){
		$("#temaEventoCapacitacionVisita").val("");
		instanciarCombo("traders");
		instanciarCombo("consultores");
		instanciarCombo("otros");
		instanciarCombo("temaEventoCapacitacionVisita");
	} else if (valor.localeCompare("Regalo cliente Nuevo") == 0){
		$("#numeroAsistentesCliente").val("");
		eliminarCombo("traders");
		eliminarCombo("consultores");
		eliminarCombo("otros");
		eliminarCombo("temaEventoCapacitacionVisita");
		$("#traders").val("");
		$("#consultores").val("");
		$("#otros").val("");
		$("#temaEventoCapacitacionVisita").val("");
	} else if (valor.localeCompare("Regalo de cumplea�os") == 0){
		$("#numeroAsistentesCliente").val("");
		eliminarCombo("traders");
		eliminarCombo("consultores");
		eliminarCombo("otros");
		eliminarCombo("temaEventoCapacitacionVisita");
		$("#traders").val("");
		$("#consultores").val("");
		$("#otros").val("");
		$("#temaEventoCapacitacionVisita").val("");
	} else if (valor.localeCompare("Tarjeta de Cumplea�os") == 0){
		$("#numeroAsistentesCliente").val("");
		eliminarCombo("traders");
		eliminarCombo("consultores");
		eliminarCombo("otros");
		eliminarCombo("temaEventoCapacitacionVisita");
		$("#traders").val("");
		$("#consultores").val("");
		$("#otros").val("");
		$("#temaEventoCapacitacionVisita").val("");
	} else if (valor.localeCompare("Visita") == 0){
		$("#numeroAsistentesCliente").val("");
		instanciarCombo("traders");
		instanciarCombo("consultores");
		instanciarCombo("otros");
		instanciarCombo("temaEventoCapacitacionVisita");
	} else{
		$("#numeroAsistentesCliente").val("");
		eliminarCombo("traders");
		eliminarCombo("consultores");
		eliminarCombo("otros");
		eliminarCombo("temaEventoCapacitacionVisita");
		$("#traders").val("");
		$("#consultores").val("");
		$("#otros").val("");
		$("#temaEventoCapacitacionVisita").val("");
	}
}

function removerEstadosDeValidacion(valor){
	if (valor.localeCompare("Capacitaci�n y evento") == 0 || valor.localeCompare("Capacitaci�n") == 0){
		removerClase("contenedorComboTraders", "has-error");
		removerClase("contenedorComboConsultores", "has-error");
		removerClase("contenedorComboOtros", "has-error");
		removerClase("contenedorComboTraders", "has-success");
		removerClase("contenedorComboConsultores", "has-success");
		removerClase("contenedorComboOtros", "has-success");
		
		removerClase("traders", "successInput");
		removerClase("consultores", "successInput");
		removerClase("otros", "successInput");
		removerClase("traders", "errorInput");
		removerClase("consultores", "errorInput");
		removerClase("otros", "errorInput");
		
		establecerValor("labelTraders", "Trader");
		establecerValor("labelConsultores", "Consultor");
		establecerValor("labelOtros", "Otro");
	} else if (valor.localeCompare("Regalo cliente Nuevo") == 0){
		removerClase("contenedorComboTraders", "has-error");
		removerClase("contenedorComboConsultores", "has-error");
		removerClase("contenedorComboOtros", "has-error");
		removerClase("divNumeroAsistentesCliente", "has-error");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-error");
		removerClase("contenedorComboTraders", "has-success");
		removerClase("contenedorComboConsultores", "has-success");
		removerClase("contenedorComboOtros", "has-success");
		removerClase("divNumeroAsistentesCliente", "has-success");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-success");
		
		removerClase("traders", "successInput");
		removerClase("consultores", "successInput");
		removerClase("otros", "successInput");
		removerClase("numeroAsistentesCliente", "successInput");
		removerClase("temaEventoCapacitacionVisita", "successInput");
		removerClase("traders", "errorInput");
		removerClase("consultores", "errorInput");
		removerClase("otros", "errorInput");
		removerClase("numeroAsistentesCliente", "errorInput");
		removerClase("temaEventoCapacitacionVisita", "errorInput");
		
		establecerValor("labelTraders", "Trader");
		establecerValor("labelConsultores", "Consultor");
		establecerValor("labelOtros", "Otro");
		establecerValor("labelTemaEventoCapacitacionVisita", "Tema de evento, capacitaci�n o visita");
	} else if (valor.localeCompare("Regalo de cumplea�os") == 0){
		removerClase("contenedorComboTraders", "has-error");
		removerClase("contenedorComboConsultores", "has-error");
		removerClase("contenedorComboOtros", "has-error");
		removerClase("divNumeroAsistentesCliente", "has-error");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-error");
		removerClase("contenedorComboTraders", "has-success");
		removerClase("contenedorComboConsultores", "has-success");
		removerClase("contenedorComboOtros", "has-success");
		removerClase("divNumeroAsistentesCliente", "has-success");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-success");
		
		removerClase("traders", "successInput");
		removerClase("consultores", "successInput");
		removerClase("otros", "successInput");
		removerClase("numeroAsistentesCliente", "successInput");
		removerClase("temaEventoCapacitacionVisita", "successInput");
		removerClase("traders", "errorInput");
		removerClase("consultores", "errorInput");
		removerClase("otros", "errorInput");
		removerClase("numeroAsistentesCliente", "errorInput");
		removerClase("temaEventoCapacitacionVisita", "errorInput");
		
		establecerValor("labelTraders", "Trader");
		establecerValor("labelConsultores", "Consultor");
		establecerValor("labelOtros", "Otro");
		establecerValor("labelTemaEventoCapacitacionVisita", "Tema de evento, capacitaci�n o visita");
	} else if (valor.localeCompare("Tarjeta de Cumplea�os") == 0){
		removerClase("contenedorComboTraders", "has-error");
		removerClase("contenedorComboConsultores", "has-error");
		removerClase("contenedorComboOtros", "has-error");
		removerClase("divNumeroAsistentesCliente", "has-error");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-error");
		removerClase("contenedorComboTraders", "has-success");
		removerClase("contenedorComboConsultores", "has-success");
		removerClase("contenedorComboOtros", "has-success");
		removerClase("divNumeroAsistentesCliente", "has-success");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-success");
		
		removerClase("traders", "successInput");
		removerClase("consultores", "successInput");
		removerClase("otros", "successInput");
		removerClase("numeroAsistentesCliente", "successInput");
		removerClase("temaEventoCapacitacionVisita", "successInput");
		removerClase("traders", "errorInput");
		removerClase("consultores", "errorInput");
		removerClase("otros", "errorInput");
		removerClase("numeroAsistentesCliente", "errorInput");
		removerClase("temaEventoCapacitacionVisita", "errorInput");
		
		establecerValor("labelTraders", "Trader");
		establecerValor("labelConsultores", "Consultor");
		establecerValor("labelOtros", "Otro");
		establecerValor("labelTemaEventoCapacitacionVisita", "Tema de evento, capacitaci�n o visita");
	} else if (valor.localeCompare("Visita") == 0){
		removerClase("divNumeroAsistentesCliente", "has-error");
		removerClase("divNumeroAsistentesCliente", "has-success");
		
		removerClase("numeroAsistentesCliente", "successInput");
		removerClase("numeroAsistentesCliente", "errorInput");
	} else{
		removerClase("contenedorComboTraders", "has-error");
		removerClase("contenedorComboConsultores", "has-error");
		removerClase("contenedorComboOtros", "has-error");
		removerClase("divNumeroAsistentesCliente", "has-error");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-error");
		removerClase("contenedorComboTraders", "has-success");
		removerClase("contenedorComboConsultores", "has-success");
		removerClase("contenedorComboOtros", "has-success");
		removerClase("divNumeroAsistentesCliente", "has-success");
		removerClase("contenedorComboTemaEventoCapacitacionVisita", "has-success");
		
		removerClase("traders", "successInput");
		removerClase("consultores", "successInput");
		removerClase("otros", "successInput");
		removerClase("numeroAsistentesCliente", "successInput");
		removerClase("temaEventoCapacitacionVisita", "successInput");
		removerClase("traders", "errorInput");
		removerClase("consultores", "errorInput");
		removerClase("otros", "errorInput");
		removerClase("numeroAsistentesCliente", "errorInput");
		removerClase("temaEventoCapacitacionVisita", "errorInput");
		
		establecerValor("labelTraders", "Trader");
		establecerValor("labelConsultores", "Consultor");
		establecerValor("labelOtros", "Otro");
		establecerValor("labelTemaEventoCapacitacionVisita", "Tema de evento, capacitaci�n o visita");
	}
}

function establecerValor(id, valor){
	$("#" + id).html(valor);
}

/***************************************************************************************************/
/***************************************************************************************************/
/******************************** SUBFUNCIONES PARA VALIDAR ****************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// Valida si la ruta seleccionada es un archivo de excel
function validarRuta(){
	var rutaArr = rutaArchivoParaCargue.split(".");
	var extension = rutaArr[rutaArr.length - 1];
	
	if (extension.localeCompare("xls") == 0 || extension.localeCompare("xlsx") == 0){
		$("#inputSinArchivos").val(rutaArchivoParaCargue);
		$("#divBotonCargueMasivoActivado").removeClass("hide");
		$("#divBotonCargueMasivoDesactivado").addClass(" hide");
	} else{
		$("#inputSinArchivos").val("Tipo de archivo no permitido");
		$("#divBotonCargueMasivoActivado").addClass(" hide");
		$("#divBotonCargueMasivoDesactivado").removeClass("hide");
	}
}

// Valida si el item seleccionado en el combo pertenece a la lista
function validarItemPertenece(items, valor){
	var opciones = reemplazarTodos(items, "<option>", "");
	opciones = reemplazarTodos(opciones, "<option selected>", "");
	var pertenece = false;
	var opcionesArr = opciones.split("</option>");
	
	for (i = 0; i < opcionesArr.length; i++){
		if (valor.localeCompare(opcionesArr[i]) == 0){
			pertenece = true;
	
			break;
		}
	}
	
	return pertenece;
}

function obtenerIdDesdeTactica(valor){
	var tacticas = (reemplazarTodos(itemsTipoTacticaCompletas, "<option>", "")).split("</option>");
	var tacticasUpper = convertirArregloMayusculas(tacticas);
	
	return idsTipoTacticaArr[tacticasUpper.indexOf(valor.toUpperCase())];
}

function obtenerIdDesdeTema(valor){
	var temas = (reemplazarTodos(itemsTemaTactica, "<option>", "")).split("</option>");
	var temasUpper = convertirArregloMayusculas(temas);
	
	return idsTemaTacticaArr[temasUpper.indexOf(valor.toUpperCase())];
}

function validarModalidadTraida(valor, id){
	if (valor.localeCompare("Presencial") == 0){
		return "<td id='" + id + "' class='linkModalidadPresencial'>" + valor + "</td>";
	} else if (valor.localeCompare("Virtual") == 0){
		return "<td id='" + id + "' class='linkModalidadVirtual'>" + valor + "</td>";
	} else{
		return "<td id='" + id + "'>" + valor + "</td>";
	}
}