// Update progress bar position
function updateProgressBar(action){
	var probabilitiesClasses = ["cero", "diez", "veinticinco", "cincuenta", "setenta", "noventa", "noventaicinco", "cien"];
	var probabilitiesText = ["0%", "10%", "25%", "50%", "70%", "90%", "95%", "100%"];
	var currentIndex = probabilities.indexOf(true);
	var currentClass = probabilitiesClasses[currentIndex];
	var changeIndex = compareString(action, "previous") ? currentIndex - 1 : compareString(action, "next") ? currentIndex + 1 : compareString(action, "success") ? probabilities.length - 1 : compareString(action, "failed") ? 0 : compareString(action, "changeStatus") ? currentIndex : probabilitiesText.indexOf(action);

	// Nestor
	if(compareString(action, "previous") && changeIndex == 0){
		removeClass("#successRadioLabel", "successRadioLabelActivated");
		removeClass("#successRadioLabel", "active");
		removeClass("#failedRadioLabel", "failedRadioLabelNormal");
		removeClass("#invalidRadioLabel", "invalidRadioLabelActivated");
		removeClass("#invalidRadioLabel", "active");
		addClass("#failedRadioLabel", " failedRadioLabelActivated");
		addClass("#failedRadioLabel", " active");
		addClass("#invalidRadioLabel", " invalidRadioLabelNormal");
		addClass("#successRadioLabel", " successRadioLabelNormal");		
		addClass("#invalidContainer", " hide");		
	}else if(compareString(action, "next") && changeIndex == 7){
		removeClass("#successRadioLabel", "successRadioLabelNormal");
		removeClass("#failedRadioLabel", "failedRadioLabelActivated");
		removeClass("#failedRadioLabel", "active");
		removeClass("#invalidRadioLabel", "invalidRadioLabelActivated");
		removeClass("#invalidRadioLabel", "active");
		addClass("#failedRadioLabel", " failedRadioLabelNormal");
		addClass("#invalidRadioLabel", " invalidRadioLabelNormal");
		addClass("#successRadioLabel", " successRadioLabelActivated");		
		addClass("#successRadioLabel", " active");
		addClass("#invalidContainer", " hide");
	}
	
	probabilities[currentIndex] = false;
	probabilities[changeIndex] = true;
	
	removeClass(".progress-bar", currentClass);
	addClass(".progress-bar", probabilitiesClasses[changeIndex]);
	assignContent(".progress-bar", probabilitiesText[changeIndex]);
	
	validateProgressPosition(changeIndex, 0, probabilities.length - 1, action);
}

// Show Fast Selection Date
function showFastSelectionDate(selector){
	// Close all fast selection date opened
	$(".cancelUpdate").click();
	
	monthAux = $(selector).parent().text().trim();
	yearAux = $(selector).attr('value');
	
	$(selector).parent().html("<div class='row' style='text-align: center'><div class='col-md-12'><div class='row'><div class='col-md-4'><a class='addMonth'><i class='fa fa-angle-up'></i></a></div><div class='col-md-4'><a class='addyear'><i class='fa fa-angle-up'></i></a></div><div class='col-md-4'><a class='updateDate' title='Editar fecha de cierre'><i class='fa fa-check'></i></a></div></div></div><div class='col-md-12'><div class='row'><div class='col-md-4'><span class='myMonth'>" + monthAux + "</span></div><div class='col-md-4'><span class='myYear'>" + yearAux + "</span></div><div class='col-md-4'></div></div></div><div class='col-md-12'><div class='row'><div class='col-md-4'><a class='subtractMonth'><i class='fa fa-angle-down'></i></a></div><div class='col-md-4'><a class='subtractYear'><i class='fa fa-angle-down'></i></a></div><div class='col-md-4'><a class='cancelUpdate' title='Cancelar edici�n'><i class='fa fa-times'></i></a></div></div></div></div>");
}

// Show Fast Selection Probability
function showFastSelectionProbability(selector){
	// Close all fast selection date opened
	$(".cancelUpdateProbability").click();
	
	ProbabilityAux = $(selector).parent().text().trim();
	
	
	$(selector).parent().html("<div class='row' style='text-align: center'><div class='col-md-12'><div class='row'><div class='col-md-6'><a class='addProbability'><i class='fa fa-angle-up'></i></a></div><div class='col-md-6'><a class='updateProbability' title='Editar fecha de cierre'><i class='fa fa-check'></i></a></div></div></div><div class='col-md-12'><div class='row'><div class='col-md-6'><span class='myProbabilityAux'>" + ProbabilityAux + "</span></div><div class='col-md-6'></div></div></div><div class='col-md-12'><div class='row'><div class='col-md-6'><a class='subtractProbability'><i class='fa fa-angle-down'></i></a></div><div class='col-md-6'><a class='cancelUpdateProbability' title='Cancelar edici�n'><i class='fa fa-times'></i></a></div></div></div></div>");
	// $(selector).parent().html("<div class='row' style='text-align: center'><div class='col-md-12'><div class='row'><a class='updateDate' title='Editar probabilidad de cierre'><i class='fa fa-check'></i></a></div></div></div><div class='col-md-12'><div class='row'></div><div class='col-md-4'><span class='myProbability'>" + ProbabilityAux + "</span></div><div class='col-md-4'></div></div></div><div class='col-md-12'><div class='row'><div class='col-md-4'><a class='subtractMonth'><i class='fa fa-angle-down'></i></a></div><div class='col-md-4'><a class='subtractYear'><i class='fa fa-angle-down'></i></a></div><div class='col-md-4'><a class='cancelUpdate' title='Cancelar edici�n'><i class='fa fa-times'></i></a></div></div></div></div>");
}

// Update fast selection date
function changePositionFastSelectionDate(action, element){
	if (compareString(element, "month")){
		var months = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
		var myMonth = $(".myMonth").text();
		var myMonthPosition = months.indexOf(myMonth);
		
		if (compareString(action, "next")){
			if (myMonthPosition == 11){
				$(".myMonth").text("Ene");
				$(".myYear").text(parseInt($(".myYear").text()) + 1);
			}else {
				$(".myMonth").text(months[myMonthPosition + 1]);
			}
		} else if (compareString(action, "previous")){
			if (myMonthPosition == 0){ 
				$(".myMonth").text("Dic");
				$(".myYear").text(parseInt($(".myYear").text()) - 1);
			}else{ 
				$(".myMonth").text(months[myMonthPosition - 1]);
			}
		}
	} else{
		if (compareString(action, "next")) $(".myYear").text(parseInt($(".myYear").text()) + 1);
		else $(".myYear").text(parseInt($(".myYear").text()) - 1);
	}
}

function changePositionFastSelectionProbability(action){
		var Probabilities = ["10%", "25%", "50%", "70%", "90%", "95%"];
		var myProbability = $(".myProbabilityAux").text();
		var myProbabilityPosition = Probabilities.indexOf(myProbability);
		
		if (compareString(action, "next")){
			if (myProbabilityPosition == 5){
				$(".myProbabilityAux").text("10%");
			}else {
				$(".myProbabilityAux").text(Probabilities[myProbabilityPosition + 1]);
			}
		} else if (compareString(action, "previous")){
			if (myProbabilityPosition == 0){ 
				$(".myProbabilityAux").text("95%");
			}else{ 
				$(".myProbabilityAux").text(Probabilities[myProbabilityPosition - 1]);
			}
		}
	
}

// Get Data For Details Panel
function showDetailsPanelContent(){
	$("#subdetail-one").removeClass("hide");
	$("#subdetail-start").addClass(" hide");
	
	putBigDetailsT();
	loadToolTip("[data-toggle='tooltip']", false, "", "");
	loadToolTip(".infoTraders", true, "Esta tabla muestra el mes estimado de cierre para las oportunidades abiertas seg�n el trader.", "right");
}

// Get Data For Details International Panel
function showDetailsInternationalPanelContent(){
	$("#subdetailint-one").removeClass("hide");
	$("#subdetailint-start").addClass(" hide");
	
	putBigDetails();
	loadToolTip("[data-toggle='tooltip']", false, "", "");
	loadToolTip(".infoTraders", true, "Esta tabla muestra el mes estimado de cierre para las oportunidades abiertas seg�n el trader.", "right");
}

// Calculate Usd Amount Input
function calculateUsdAmount(){
	var originalAmount = replaceAll($("#originalAmount").val(), ",", "");
	var rate = replaceAll($("#rate").val(), ",", "");
	var currency = $("#currency").val();
	var usdAmount = addCommas(compareString(currency, "USD") ? originalAmount : (compareString(currency, "EUR") || compareString(currency, "GBP") ? originalAmount * rate : originalAmount / rate));
	
	usdAmount = addCommas(parseFloat(replaceAll(usdAmount, ",", "")).toFixed(2));
	
	changeProperty("#usdAmount", "title", usdAmount);
	assignValue("#usdAmount", usdAmount);
}

// Calculate Expected Utility Input
function calculateExpectedUtility(){
	var estimateUtility = replaceAll($("#estimatedUtility").val(), ",", "");
	var probability = parseInt($(".progress-bar").text().substring(0, $(".progress-bar").text().length - 1)) / 100;
	var error = isNaN(estimateUtility * probability) || !isFinite(estimateUtility * probability) ? "Revise el valor de utilidad estimada" : "";
	var expectedUtility = addCommas(estimateUtility * probability);
	
	expectedUtility = addCommas(parseFloat(replaceAll(expectedUtility, ",", "")).toFixed(2));
	
	changeProperty("#expectedUtility", "title", expectedUtility);
	assignValue("#expectedUtility", expectedUtility);
	
	showFormStatus(error, 29, "#errorExpectedUtility", "#expectedUtility", "#expectedUtilityLabel", "#insertButton", "#editButton");
}

// Calculate RR Input
function calculateRR(){
	var producto= $('#product').val();
	if(compareString(producto, 'Estructuras con Opciones')||compareString(producto, 'Opci�n Plain Vanilla')){
		formStates[17] = true;
		assignValue("#rr", 0);
	}else{
		if (parseFloat(replaceAll($("#estimatedUtility").val(), ",", "")) > parseFloat(replaceAll($("#consumedQuota").val(), ",", ""))){
			alert("La utilidad debe ser menor o igual al cupo consumido.");
			assignValue("#rr", 0);
			return;
		}

		var estimateUtility = parseFloat(replaceAll($("#estimatedUtility").val(), ",", ""));
		var consumedQuota = parseFloat(replaceAll($("#consumedQuota").val(), ",", ""));
		var fv = consumedQuota + estimateUtility;
		var termDuration = !hasClass($("#durationDiv").parent(), "hide") ? parseFloat(replaceAll($("#duration").val(), ",", "")) : parseFloat(replaceAll($("#term").val(), ",", "")) / 365;
		var rr = addCommas(calculateIRR([consumedQuota * -1, fv]) / termDuration);
		
		rr = addCommas(parseFloat(replaceAll(rr, ",", "")).toFixed(2));
		
		changeProperty("#rr", "title", rr);
		assignValue("#rr", rr);
	}
}

// Hide form input when user type is "Consultor"
function hideInputs(){
	if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){
		["#positionContainer", "#currencyContainer", "#originalAmountDiv", "#priorizationContainer", "#expectedUtilityDiv", "#termDiv", "#usdAmountDiv", "#pendingBankContainer", "#pendingCustomerContainer"].forEach(function(a){addClass($(a).parent(), " hide")});
		addClass("#panel3", " hide");
		addClass(".chartPanel", " hide");
		addClass(".bigDetailsTPanel", " hide");
		formStates = [false, false, false, true, true, true, true, true, false, true, false, false, true, true, true, true, true, true, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true];
		$("#vehicleContainer").parent().removeClass("hide");
		assignContent("#probabilityDiv", '<label class="control-label" id="probabilityLabel">Probabilidad de Cierre</label><div class="progress progress-striped active"><div class="progress-bar cincuenta" role="progressbar">50%</div></div>');
		assignContent("#statusDiv", '<label class="control-label" id="statusLabel">Estado</label><select class="form-control" id="status"></select><p class="errorMessage hide" id="errorStatus"></p>');
		assignContent("#usdAmountDiv", '<label class="control-label" id="usdAmountLabel">Monto en USD</label><div class="required-field-block"><input class="form-control" maxlength="15" id="usdAmount"><div class="required-icon"><div class="text">*</div></div></div><p class="errorMessage hide" id="errorUsdAmount"></p>');
		removeClass(".panelOperation", "hide");
		removeClass(".bigDetailsPanel", "hide");
		addClass($("#traderContainer").parent(), " col-xs-offset-2");
		$("#traderLabel").text("Consultor");
		$("#rateLabel").text("Tasa %");
		changeProperty($("#rate"), "placeholder", "Tasa");
		addClass("#rowTableT", " hide");
		removeClass("#rowTableI", "hide");
	} else if (compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT")){
		queries.queryConsultDataGraph = replaceAll(queries.queryConsultDataGraph, "rOrigen", "Tesorer�a");
		queries.queryConsultDataGraphII = replaceAll(queries.queryConsultDataGraphII, "rOrigen", "Tesorer�a");
		queries.queryConsultDataGraphIII = replaceAll(queries.queryConsultDataGraphIII, "rOrigen", "Tesorer�a");
		queries.queryConsultDetailsGraph = replaceAll(queries.queryConsultDetailsGraph, "rOrigen", "Tesorer�a");
	} else{
		queries.queryConsultDataGraph = replaceAll(queries.queryConsultDataGraph, "Origen = 'rOrigen' AND", "");
		queries.queryConsultDataGraphII = replaceAll(queries.queryConsultDataGraphII, "Origen = 'rOrigen' AND", "");
		queries.queryConsultDataGraphIII = replaceAll(queries.queryConsultDataGraphIII, "Origen = 'rOrigen' AND", "");
		queries.queryConsultDetailsGraph = replaceAll(queries.queryConsultDetailsGraph, "Origen = 'rOrigen' AND", "");
		removeClass(".bigDetailsPanel", "hide");
		addClass("#rowTableT", " hide");
		removeClass("#rowTableA", "hide");
		removeClass($("#vehicleContainer").parent(), "hide");
	}
}

// Autocomplete Bank, Segment, Region Inputs Based on Unit
function autoCompleteGeographicShortForm(){
	var stringConnection = stringConnections.strConexionDataMart;
	var query = replaceAll(queries.queryGeographyInfoII, "rUnidad", $("#unit").val() + "");
	query = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? replaceAll(replaceAll(query, "Trader", "Consultor"), "Facilitador", "Coordinador") : query;
	var geographicInfoArray = consultGeographicInfo(query, stringConnection, connection, recordSet, "short");
	var exist = compareString(geographicInfoArray[0], "") ? false : true;
	
	if (exist){
		assignMultipleValues(["#trader", "#bank", "#segment", "#region"], [geographicInfoArray[0], geographicInfoArray[1], geographicInfoArray[2], geographicInfoArray[3]]);
		changeMultipleItemsProperty(["#trader", "#bank", "#segment", "#region"], "title", [geographicInfoArray[0], geographicInfoArray[1], geographicInfoArray[2], geographicInfoArray[3]]);
		showFormStatus("", 20, "#errorUnit", "#unit", "#unitLabel", "#insertButton", "#editButton");
	} else{
		assignMultipleValues(["#trader", "#bank", "#segment", "#region"], ["", "", "", ""]);
		changeMultipleItemsProperty(["#trader", "#bank", "#segment", "#region"], "title", ["", "", "", ""]);
	
		if ($("#unit").val().length != 4){
			showFormStatus("Debe ser a 4 d�gitos", 20, "#errorUnit", "#unit", "#unitLabel", "#insertButton", "#editButton");
		} else{
			showFormStatus("Unidad no existe", 20, "#errorUnit", "#unit", "#unitLabel", "#insertButton", "#editButton");
		}
	}
}

// Autocomplete Customer, Trader, Unit, Bank, Segment, Region Inputs Based on NIT
function autocompleteGeographicInputsLargeForm(){
	var query = replaceAll(queries.consultaCliente, "rNit", $("#nit").val() + "");
	var stringConnection = stringConnections.strConexionDataMart;
	var customerArray = readDatamart(query, stringConnection, connection, recordSet);
	var exist = compareString(customerArray[0], "Sin resultados") ? false : true;
	query = replaceAll(queries.queryGeographyInfo, "rNit", $("#nit").val() + "");
	query = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? replaceAll(replaceAll(query, "Trader", "Consultor"), "Facilitador", "Coordinador") : query;
	var geographicInfoArray = consultGeographicInfo(query, stringConnection, connection, recordSet, "large");
	
	if (exist){
		assignMultipleValues(["#customer", "#trader", "#unit", "#bank", "#segment", "#region", "#priorization"], [customerArray[0], geographicInfoArray[0], geographicInfoArray[1], geographicInfoArray[2], geographicInfoArray[3], geographicInfoArray[4], geographicInfoArray[5]]);
		changeMultipleItemsProperty(["#customer", "#unit"], "disabled", [true, true]);
		changeMultipleItemsProperty(["#customer", "#trader", "#unit", "#bank", "#segment", "#region", "#priorization"], "title", [customerArray[0], geographicInfoArray[0], geographicInfoArray[1], geographicInfoArray[2], geographicInfoArray[3], geographicInfoArray[4], geographicInfoArray[5]]);
		// Add Classes
		addClass("#errorCustomer", " hide");addClass("#customSearchCustomer", " successInput");addClass("#customerLabel", " successLabel");addClass("#errorUnit", " hide");addClass("#unit", " successInput");addClass("#unitLabel", " successLabel");
		// Remove Classes
		removeClass("#unit", " errorInput");removeClass("#unitLabel", " errorLabel");removeClass("#customSearchCustomer", " errorInput");removeClass("#customerLabel", " errorLabel");
		
		formStates[1] = true;
		formStates[20] = true;
	} else{
		assignMultipleValues(["#customer", "#trader", "#unit", "#bank", "#segment", "#region"], ["No encontrado", "", "", "", "", ""]);
		changeMultipleItemsProperty(["#customer", "#unit"], "disabled", [false, false]);
		changeMultipleItemsProperty(["#customer", "#trader", "#unit", "#bank", "#segment", "#region"], "title", ["", "", "", "", "", ""]);
		
		removeClass("#unit", " successInput");
		removeClass("#unitLabel", " successLabel");
		removeClass("#customSearchCustomer", " successInput");
		removeClass("#customerLabel", " successLabel");
		
		formStates[1] = false;
		formStates[20] = false;
	}
}

/**********************************************************************************************/
/********************************* G E T  D A T A  F O R M ************************************/
/**********************************************************************************************/
// Get All data wrote in form
function getFormData(action){
	if (!compareString(userType, "ConsultorI") && !compareString(userType, "GerencialI") && !compareString(userType, "CoordinadorI")){
		calculateUsdAmount();
		calculateRR();
	}
	
	rowToInsertTable = [];
	
	/* Aux Variables */
	var currentDate = getDate(0, false);
	var currentTime = getTime(false);
	var date = getCleanValueForm("#estimatedDate", "Date", 0, "", []);
	/* Form Variables */
	var uploadDate = "#" + getDateTime(currentDate.split("/")[2] + "-" + currentDate.split("/")[1] + "-" + currentDate.split("/")[0], currentTime) + "#";
	var estimatedDate = "#" + date + "#";
	var nit = "'" + getCleanValueForm("#nit", "Text", 0, "", []) + "'";
	var customer = "'" + getCleanValueForm("#customer", "Text", 0, "", []) + "'";
	var product = getCleanValueForm("#product", "Id", 0, productItems, productIds);
	var subProduct = replaceAll(getCleanValueForm("#subProduct", "Id", 0, subProductItems, subProductIds), "NULL", "") + replaceAll(getCleanValueForm("#subProduct2", "Id", 0, subProductItems2, subProductIds2), "NULL", "");
	subProduct = compareString(subProduct, "") ? "NULL" : subProduct;
	var position = getCleanValueForm("#position", "Id", 0, positionItems, positionIds);
	var currency = getCleanValueForm("#currency", "Id", 0, currencyItems, currencyIds);
	var origen = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? "'Internacional'" : compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT") ? "'Tesorer�a'" : "NULL";
	var rate = compareString(origen, "Internacional") ? getCleanValueForm("#rate", "Percentage", 0, "", []) : getCleanValueForm("#rate", "Number", 2, "", []);
	var originalAmount = getCleanValueForm("#originalAmount", "Number", 2, "", []);
	var usdAmount = getCleanValueForm("#usdAmount", "Number", 2, "", []);
	var copIngress = getCleanValueForm("#copIngress", "Number", 2, "", []);
	var term = getCleanValueForm("#term", "Text", 0, "", []);
	var vehicle = getCleanValueForm("#vehicle", "Id", 0, vehicleItems, vehicleIds);
	var duration = getCleanValueForm("#duration", "Text", 0, "", []);
	var operationStrategy = getCleanValueForm("#operationStrategy", "Id", 0, operationStrategyItems, operationStrategyIds);
	var estimatedUtility = getCleanValueForm("#estimatedUtility", "Number", 2, "", []);
	var expectedUtility = getCleanValueForm("#expectedUtility", "Number", 2, "", []);
	var consumedQuota = getCleanValueForm("#consumedQuota", "Number", 2, "", []);
	var rr = getCleanValueForm("#rr", "Number", 3, "", []);
	var unit = "'" + getCleanValueForm("#unit", "Text", 0, "", []) + "'";
	var bank = replaceAll(getCleanValueForm("#bank", "Text", 0, "", []), "NULL", "");
	var segment = replaceAll(getCleanValueForm("#segment", "Text", 0, "", []), "NULL", "");
	var region = replaceAll(getCleanValueForm("#region", "Text", 0, "", []), "NULL", "");
	var referredBy = getCleanValueForm("#referredBy", "Id", 0, referredByItems, referredByIds);
	var status = getCleanValueForm("#status", "Id", 0, statusItems, statusIds);
	var pendingBank = getCleanValueForm("#pendingBank", "Id", 0, pendingBankItems, pendingBankIds);
	var pendingCustomer = getCleanValueForm("#pendingCustomer", "Id", 0, pendingCustomerItems, pendingCustomerIds);
	var probability = getCleanValueForm(".progress-bar", "Progress", 0, "", []);
	var observations = "'" + replaceAll(getCleanValueForm("#observations", "Text", 0, "", []), "NULL", "") + "'";
	var reason = getCleanValueForm("#reason", "Id", 0, reasonItems, reasonIds);
	var invalidReason = getCleanValueForm("#invalid", "Id", 0, invalidItems, invalidIds);
	var statusOperation = hasClass("#successRadioLabel", "active") ? "'Oper. Exitosa'" : (hasClass("#failedRadioLabel", "active") ? "'Oper. Fallida'" : (hasClass("#invalidRadioLabel", "active") ? "'Oper. Invalida'" : "NULL"));//Nestor
	//var statusOperation =  hasClass("#successRadioLabel", "active") ? "'Oper. Exitosa'" : (hasClass("#failedRadioLabel", "active") ? "'Oper. Fallida'" : (hasClass("#cancelledRadioLabel", "active") ? "'Oper. Anulada'" : (hasClass("#clientErrorRadioLabel", "active") ? "'Cliente no cerr�'" : "NULL")));
	var uploadBy = "'" + users.currentUser + "'";
	var traderConsultant = replaceAll(getCleanValueForm("#trader", "Text", 0, "", []), "NULL", "");
	//var closeDate = compareString(statusOperation + "", "'Oper. Exitosa'") || compareString(statusOperation + "", "'Oper. Fallida'") ? uploadDate : "NULL";
	var closeDate = compareString(statusOperation + "", "'Oper. Exitosa'") || compareString(statusOperation + "", "'Oper. Fallida'") ? replaceAll("#" + getDateTime(currentDate.split("/")[2] + "-" + currentDate.split("/")[1] + "-" + currentDate.split("/")[0], "") + "#", " ", "") : "NULL";
	/* Validate Variables */
	var varsForValidate = [subProduct, position, currency, rate, originalAmount, usdAmount, copIngress, term, vehicle, operationStrategy, estimatedUtility, expectedUtility, consumedQuota, rr, status, pendingBank, pendingCustomer, statusOperation, origen, observations];
	var validateVars = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""];
	varsForValidate.forEach(function(a, b){validateVars[b] = compareString(a, "NULL") ? "IS NULL" : "=" + a});
	/* Row for insert to table */
	var statusFtd = compareString(statusOperation, "NULL") ? "" : statusOperation.substring(1, statusOperation.length - 1);
	var statussT = compareString(statusOperation + "", "'Oper. Exitosa'") || compareString(statusOperation + "", "'Oper. Fallida'") || compareString(statusOperation + "", "'Oper. Invalida'") ? statusOperation.substring(1, statusOperation.length - 1) + "" : statusItemsArray[statusIds.indexOf(status)];
	var statussI = compareString(statusOperation + "", "'Oper. Exitosa'") || compareString(statusOperation + "", "'Oper. Fallida'") || compareString(statusOperation + "", "'Oper. Invalida'") ? statusOperation.substring(1, statusOperation.length - 1) + "" : concatArrays(["", "", "", ""], statusItemsArray)[concatArrays(["", "", "", ""], statusIds).indexOf(status)];
	var buttonEditable = compareString(statusOperation, "NULL") ? "<a value='" + idForEdit + "' title='Refresque la p�gina para editar esta oportunidad' class='fa fa-edit'></a>" : "";
	var varsForTableT = [date.substring(0,4) + "/" + date.substring(5,7) + "/" + date.substring(8,10), convertNumericMonthToStringMonth((new Date(date.substring(0,4) + "/" + date.substring(5,7) + "/" + date.substring(8,10))).getMonth() + 1), $("#nit").val(), $("#customer").val(), $("#product").val(), term, $("#position").val(), addCommas(usdAmount), addCommas(expectedUtility), probability + "%", replaceAll(statussT + "", "NULL", ""), observations.substring(1, observations.length - 1), coordinator, traderConsultant, bank, segment, region, buttonEditable];
	var varsForTableI = [date.substring(0,4) + "/" + date.substring(5,7) + "/" + date.substring(8,10), convertNumericMonthToStringMonth((new Date(date.substring(0,4) + "/" + date.substring(5,7) + "/" + date.substring(8,10))).getMonth() + 1), $("#nit").val(), $("#customer").val(), $("#product").val() + " (" + $("#subProduct").val() + $("#subProduct2").val() + ")", term, $("#vehicle").val(), addCommas(usdAmount), addCommas(replaceAll(copIngress, "NULL", "")), probability + "%", replaceAll(statussI + "", "NULL", ""), observations.substring(1, observations.length - 1), coordinator, traderConsultant, bank, segment, region, buttonEditable];
	var varsForTable = compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT") || compareString(userType, "Administrador") ? varsForTableT : compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? varsForTableI : "";
	
	varsForTable.forEach(function(a){rowToInsertTable.push(a)});
	
	dataForValidate = " FechaEstimada=" + estimatedDate + " AND Nit=" + nit + " AND Cliente=" + customer + " AND Producto=" + product + " AND SubProducto " + validateVars[0] + " AND Posici�nBdB " + validateVars[1] + " AND Moneda " + validateVars[2] + " AND Tasa " + validateVars[3] + " AND Monto " + validateVars[4] + " AND MontoUSD " + validateVars[5] + " AND IngresoCOP " + validateVars[6] + " AND Plazo " + validateVars[7] + " AND Vehiculo " + validateVars[8] + " AND EstrategiaOperaci�n " + validateVars[9] + " AND UtilidadEstimada " + validateVars[10] + " AND UtilidadEsperada " + validateVars[11] + " AND CupoConsumido " + validateVars[12] + " AND RrEsperado " + validateVars[13] + " AND Unidad=" + unit + " AND ReferidoPor=" + referredBy + " AND Estado " + validateVars[14] + " AND PendienteBanco " + validateVars[15] + " AND PendienteCliente " + validateVars[16] + " AND ProbabilidadCierre=" + probability + " AND EstadoOperaci�n " + validateVars[17] + " AND UsuarioSubio=" + uploadBy + " AND Origen " + validateVars[18] + " AND Observaciones " + validateVars[19];
	dataForValidateFailedOperation = " Trader=" + uploadBy + " AND NIT=" + nit + " AND ClientName=" + customer + " AND TransactionDate=" + estimatedDate + " AND CurrencyPair='" + getCleanValueForm("#currency", "Text", 0, "", []) + getCleanValueForm("#currency", "Text", 0, "", []) + "' AND Quota= '" + getCleanValueForm("#reason", "Text", 0, "", []) + "' AND OperationType='" + getCleanValueForm("#position", "Text", 0, "", []) + "' AND Amount=" + usdAmount;
	
	if (compareString(action, "Insert")){
		return uploadDate + ", " + estimatedDate + ", " + closeDate + ", " + nit + ", " + customer + ", " + product + ", " + subProduct + ", " + position + ", " + currency + ", " + rate + ", " + originalAmount + ", " + usdAmount + ", " + copIngress + ", " + term + ", " + vehicle + ", " + duration + ", " + operationStrategy + ", " + estimatedUtility + ", " + expectedUtility + ", " + consumedQuota + ", " + rr + ", " + unit + ", " + referredBy + ", " + status + ", " + pendingBank + ", " + pendingCustomer + ", " + probability + ", " + statusOperation + ", " + reason+", "+invalidReason + ", " + observations + ", " + uploadBy + ", " + origen;
	} else if(compareString(action, "Update")){
		return "FechaEstimada = " + estimatedDate + ", FechaCierre = " + closeDate +  ", Nit = " + nit + ", Cliente = " + customer + ", Producto = " + product + ", SubProducto = " + subProduct + ", Posici�nBdB = " + position + ", Moneda = " + currency + ", Tasa = " + rate + ", Monto = " + originalAmount + ", MontoUSD = " + usdAmount + ", IngresoCOP = " + copIngress + ", Plazo = " + term + ", Vehiculo = " + vehicle + ", Duraci�n = " + duration + ", EstrategiaOperaci�n = " + operationStrategy + ", UtilidadEstimada = " + estimatedUtility + ", UtilidadEsperada = " + expectedUtility + ", CupoConsumido = " + consumedQuota + ", RrEsperado = " + rr + ", Unidad = " + unit + ", ReferidoPor = " + referredBy + ", Estado = " + status + ", PendienteBanco = " + pendingBank + ", PendienteCliente = " + pendingCustomer + ", ProbabilidadCierre = " + probability + ", EstadoOperaci�n = " + statusOperation + ", Motivo = " + reason+",MotivoInvalida	= "+invalidReason + ", Observaciones = " + observations + " WHERE Id = rId";
	} else if(compareString(action, "InsertFailedOperation")){
		return uploadBy + ", " + nit + ", " + customer + ", '" + replaceAll(getCleanValueForm("#position", "Text", 0, "", []), "NULL", "") + "', '" + getCleanValueForm("#currency", "Text", 0, "", []) + getCleanValueForm("#currency", "Text", 0, "", []) + "', " + closeDate + ", 'PL-" + getCleanValueForm("#product", "Text", 0, "", []) + "', " + usdAmount + ", '" + getCleanValueForm("#reason", "Text", 0, "", []) + "', '" + term + "', NULL, NULL, NULL, " + observations + ", " + uploadDate + ", " + origen;
	}
}

/**********************************************************************************************/
/****************************** R E S E T  F U N C T I O N S **********************************/
/**********************************************************************************************/
// Reset All Form Inputs
function resetForm(){
	clearInputs();
	clearClasses();
	clearProperties();
	clearProgressBar();
	clearformStates();
}

// Reset Selects Editables Filter
function resetInputsFilter(){
	destroyEditableSelect("#statusOperationFilter");destroyEditableSelect("#range");
	instanceEditableSelect("#statusOperationFilter");instanceEditableSelect("#range");
}

// Clear Other inputs (Selects Editables, RadioButtons)
function clearInputs(){
	removeClass("#successRadioLabel", " active successRadioLabelActivated");
	removeClass("#failedRadioLabel", " active failedRadioLabelActivated");
	removeClass("#invalidRadioLabel", " active invalidRadioLabelActivated");//Nestor
	addClass("#successRadioLabel", " successRadioLabelNormal");
	addClass("#failedRadioLabel", " failedRadioLabelNormal");
	addClass("#invalidRadioLabel", " invalidRadioLabelNormal");//Nestor
	removeClass("#searchCoincidencesButton", "hide");
	removeClass("#restartButton", "hide");
	clearEditableSelect("#nit");
	destroyMultiplesEditableSelects(["#nit", "#product", "#position", "#currency", "#operationStrategy", "#referredBy", "#status", "#pendingBank", "#pendingCustomer"]);
	setTimeout(intanceMultiplesEditableSelects(["#nit", "#product", "#position", "#currency", "#operationStrategy", "#referredBy", "#status", "#pendingBank", "#pendingCustomer"]), 100);
}

// Remove error & success classes 
function clearClasses(){
	var selectorsInputs = ["#nit", "#customSearchCustomer", "#product", "#position", "#currency", "#originalAmount", "#estimatedDate", "#term", "#rate", "#operationStrategy", "#estimatedUtility", "#consumedQuota", "#unit", "#referredBy", "#status", "#pendingBank", "#pendingCustomer", "#customSearchExpectedUtility", "#subProduct", "#subProduct2", "#vehicle", "#usdAmount", "#copIngress", "#observations", "#reason", "#invalid"];//Nestor
	var selectorsLabel = ["#nitLabel", "#customerLabel", "#productLabel", "#positionLabel", "#currencyLabel", "#originalAmountLabel", "#estimatedDateLabel", "#termLabel", "#rateLabel", "#operationStrategyLabel", "#estimatedUtilityLabel", "#consumedQuotaLabel", "#unitLabel", "#referredByLabel", "#statusLabel", "#pendingBankLabel", "#pendingCustomerLabel", "#expectedUtilityLabel", "#subProductLabel", "#subProductLabel2", "#vehicleLabel", "#usdAmountLabel", "#copIngressLabel", "#observationsLabel", "#reasonLabel", "#invalidLabel"];//Nestor
	var selectorsErrorMessages = ["#errorNit", "#errorCustomer", "#errorProduct", "#errorPosition", "#errorCurrency", "#errorOriginalAmount", "#errorEstimatedDate", "#errorTerm", "#errorRate", "#errorOperationStrategy", "#errorEstimatedUtility", "#errorConsumedQuota", "#errorUnit", "#errorReferredBy", "#errorStatus", "#errorPendingBank", "#errorPendingCustomer", "#errorExpectedUtility", "#errorSubProduct", "#errorSubProduct2", "#errorVehicle", "#errorUsdAmount", "#errorCopIngress", "#errorObservations", "#errorReason", "#errorInvalid"];//Nestor
	var classesToRemoveInputs = ["successInput", "errorInput"];
	var classesToRemoveLabels = ["successLabel", "errorLabel"];
	
	classesToRemoveInputs.forEach(function(a){selectorsInputs.forEach(function(b){$(b).removeClass(a)})});
	classesToRemoveLabels.forEach(function(a){selectorsLabel.forEach(function(b){$(b).removeClass(a)})});
	selectorsErrorMessages.forEach(function(b){$(b).addClass(" hide")});
	
	addClass("#editButtonDiv", " hide");
	addClass(".panelOperation", " hide");//Nestor
	removeClass("#insertButtonDiv", "hide");
	addClass("#reasonContainer", " hide");
	addClass("#invalidContainer", " hide");
}

// Clean properties like "disabled"
function clearProperties(){
	changeProperty("#insertButton", "disabled", true);
	changeProperty("#customer", "disabled", false);
	changeProperty("#unit", "disabled", false);
	changeProperty("#searchCoincidencesButton", "disabled", true);
}

// Remove progress bar classes
function clearProgressBar(){
	removeClass(".progress-bar", "cero");
	removeClass(".progress-bar", "diez");
	removeClass(".progress-bar", "veinticinco");
	removeClass(".progress-bar", "cincuenta");
	removeClass(".progress-bar", "setenta");
	removeClass(".progress-bar", "noventa");
	removeClass(".progress-bar", "noventaicinco");
	removeClass(".progress-bar", "cien");
	removeClass("#nextProgress", "hide");
	removeClass("#previusProgress", "hide");
	addClass(".progress-bar", " cincuenta");
	$(".progress-bar").text("50%");
	probabilities = [false, false, false, true, false, false, false, false];
}

// Reset form states (false)
function clearformStates(){
	if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){
		formStates = [false, false, false, true, true, true, true, true, false, true, false, false, true, true, true, true, true, true, true, true, false, true, true, true, true, false, true, true, true, true, true, true, true];
	} else{
		formStates = [false, false, false, true, true, true, false, false, false, false, false, true, true, true, true, false, false, false, true, true, false, true, true, true, true, false, true, true, true, false, true, true, true];
	}
}