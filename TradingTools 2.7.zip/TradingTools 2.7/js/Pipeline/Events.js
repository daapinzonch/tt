var yearAux = "";
var monthAux = "";
var ProbabilityAux = "";
function addEvents(){
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});

	/***************************************************************************************************/
	/*************************************** ON CLICK **************************************************/
	/***************************************************************************************************/
	//scroll lateral 
	moveScroll("#scrollLateral", ".scrollLateraly");
	// Show Previous Percentage Progress Bar
	$("#previusProgress").on('click',function(){updateProgressBar("previous")});
	
	// Show Next Percentage Progress Bar
	$('#nextProgress').on('click', function (e){updateProgressBar("next")});
	
	// Consult & Autocomplete Geographic Inputs When Exist Customer
	$('#autocompleteCustomerButton').on('click', function (e){autocompleteGeographicInputsLargeForm()});
	
	// Calculate USD Amount
	$('#autocompleteUsdAmountButton').on('click', function (e){calculateUsdAmount()});
	
	// Calculate Expected Utility
	//$('#autocompleteExpectedUtilityButton').on('click', function (e){calculateExpectedUtility()});
	
	// Calculate RR
	$('#autocompleteRrButton').on('click', function (e){calculateRR()});
	
	// Reset Selects Editables Of Form
	$('#restartButton').on('click', function (e){resetForm()});
	
	// Reset All Form Inputs & Resize Panel
	$('#formPipelineLink').on('click', function (e){$('#restartButton').click();removeClass("#containerCard", " fullWidth");$("#status").val("En Cotizaci�n");changeProperty("#status", "disabled", true)});
	
	// Resize Panel
	$('#fluxPipelineLink').on('click', function (e){addClass("#containerCard", " fullWidth")});
	
	// Insert new opportunity
	$('#insertButton').on('click', function (e){validateFailedOperation();insertOpportunity(getFormData("Insert"));});
	
	// Update opportunity
	$('#editButton').on('click', function (e){validateFailedOperation();updateOpportunity(getFormData("Update"), $(this).attr("value"))});
	
	// Change Icon Expand/Compress
	$('#linkShowGraph, #linkShowDetails, #linkShowDetailsT').on('click', function (e){exchangeClass($(this), "fa-compress", "fa-expand")});
	
	// Get Nit Coincidences
	$('#searchCoincidencesButton').on('click', function (e){showCoincidences(e, $("#nit").val(), replaceAll(queries.consultaNits, "rNit", $("#nit").val()), stringConnections.strConexionDataMart, "#nit", connection)});
	
	// Get opportunity for edit
	$(selectorDatatable).on('click', '.openEditOpportunityForm', function (e){putOpportunityDataInForm($(this).parent().parent().attr("value"), "Editar")});
	
	// Get opportunity for reuse
	$(selectorDatatable).on('click', '.openReuseOpportunityForm', function (e){putOpportunityDataInForm($(this).parent().parent().attr("value"), "Reutilizar")});
	
	// Export opportunities to Excel
	$(selectorDatatable + "Div").on('click', '#exportOpportunities', function (){removeCommasToColumn(selectorDatatable, numericColumns);exportTable(selectorDatatable, "Oportunidades", "Oportunidades_" + users.currentUser);putCommasToColumn(selectorDatatable, numericColumns)});
	
	// Show Fast Selection Date
	$(selectorDatatable).on('click', ".estimatedDateEditable", function(){showFastSelectionDate($(this))});
	
	// Show Fast Selection Probability
	$(selectorDatatable).on('click', ".estimatedProbabilityEditable", function(){showFastSelectionProbability($(this))});
	
	// Add month to fast selection date
	$(selectorDatatable).on('click', '.addMonth', function (e){changePositionFastSelectionDate("next", "month")});
	
	// Add month to fast selection date
	$(selectorDatatable).on('click', '.addyear', function (e){changePositionFastSelectionDate("next", "year");});
	$(selectorDatatable).on('click', '.addProbability', function (e){changePositionFastSelectionProbability("next");});
	
	// Add month to fast selection date
	$(selectorDatatable).on('click', '.subtractMonth', function (e){changePositionFastSelectionDate("previous", "month")});
	$(selectorDatatable).on('click', '.subtractProbability', function (e){changePositionFastSelectionProbability("previous")});
	
	// Add month to fast selection date
	$(selectorDatatable).on('click', '.subtractYear', function (e){changePositionFastSelectionDate("previous", "year")});
	
	// Hidden Fast Selection Date
	$(selectorDatatable).on('click', ".cancelUpdate", function(){$(this).parent().parent().parent().parent().parent().html(monthAux + " <a class='estimatedDateEditable' value='" + yearAux + "' title='Editar fecha'><i class='fa fa-edit'></i></a>")});
	// Hidden Fast Selection Probability
	$(selectorDatatable).on('click', ".cancelUpdateProbability", function(){$(this).parent().parent().parent().parent().parent().html( ProbabilityAux + " <a class='estimatedProbabilityEditable' title='Editar probabilidad'><i class='fa fa-edit'></i></a>")});
	
	// Update estimateDate in DB
	$(selectorDatatable).on('click', '.updateDate', function (e){updateEstimatedDateFromTable($(this))});
	$(selectorDatatable).on('click', '.updateProbability', function (e){updateEstimatedProbabilityFromTable($(this))});
	
	// Get Graph Panel Content
	$("#getGraphDetails").on('click', function (){showGraphPanelContent()});
	
	// Get Details Panel Content
	$("#getDetails").on('click', function (){showDetailsPanelContent()});
	
	// Get Details International Panel Content
	$("#getDetailsInt").on('click', function (){showDetailsInternationalPanelContent()});
	
	/***************************************************************************************************/
	/*************************************** FOCUS OUT *************************************************/
	/***************************************************************************************************/
	//Hide clarification in consumedQuota
	$("#consumedQuota").focusout(function (){
		addClass("#clarificationConsumedQuota", " hide");
	});
	// Validate Nit Input
	$("#nitContainer").focusout(function (){showFormStatus(validateInput($("#nit").val() + "", 0), 0, "#errorNit", "#nit", "#nitLabel", "#insertButton", "#editButton")});
	
	// Validate Customer Input
	$("#customer").focusout(function (){showFormStatus(validateCustomerInput($("#customer").val() + ""), 1, "#errorCustomer", "#customSearchCustomer", "#customerLabel", "#insertButton", "#editButton")});
	
	// Validate Product Select Editable
	$("#productContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#product").val() + "", productItems), 2, "#errorProduct", "#product", "#productLabel", "#insertButton", "#editButton"); validateProductSelected()});
	
	// Validate SubProduct Select Editable
	$("#subProductContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#subProduct").val() + "", subProductItems), 3, "#errorSubProduct", "#subProduct", "#subProductLabel", "#insertButton", "#editButton")});
	
	// Validate SubProduct2 Select Editable
	$("#subProductContainer2").focusout(function (){showFormStatus(validateValueSelectEditable($("#subProduct2").val() + "", subProductItems2), 4, "#errorSubProduct2", "#subProduct2", "#subProductLabel2", "#insertButton", "#editButton"); validateSubproduct2Selected()});
	
	// Validate PositionContainer Select Editable
	$("#positionContainer").focusout(function (){showFormStatus(validateValueSelectEditableOptional($("#position").val() + "", positionItems), 5, "#errorPosition", "#position", "#positionLabel", "#insertButton", "#editButton")});
	
	// Validate Currency Select Editable
	$("#currencyContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#currency").val() + "", currencyItems), 6, "#errorCurrency", "#currency", "#currencyLabel", "#insertButton", "#editButton");validateCurrencySelected()});
	
	// Validate OriginalAmount Input
	$("#originalAmount").focusout(function (){showFormStatus(validateInput($("#originalAmount").val() + "", 1), 7, "#errorOriginalAmount", "#originalAmount", "#originalAmountLabel", "#insertButton", "#editButton")});
	
	// Validate EstimatedDate Input
	$("#estimatedDate").focusout(function (){showFormStatus(validateDateInput($("#estimatedDate").val() + ""), 8, "#errorEstimatedDate", "#estimatedDate", "#estimatedDateLabel", "#insertButton", "#editButton")});
	
	// Validate Term Input
	$("#term").focusout(function (){showFormStatus(validateInput($("#term").val() + "", 0), 9, "#errorTerm", "#term", "#termLabel", "#insertButton", "#editButton")});
	
	// Validate Rate Input
	$("#rate").focusout(function (){showFormStatus(validateInput($("#rate").val() + "", 1), 10, "#errorRate", "#rate", "#rateLabel", "#insertButton", "#editButton")});
	
	// Validate Vehicle Select Editable
	$("#vehicleContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#vehicle").val() + "", vehicleItems), 11, "#errorVehicle", "#vehicle", "#vehicleLabel", "#insertButton", "#editButton")});
	
	// Validate Duration Input
	$("#duration").focusout(function (){showFormStatus(validateInput($("#duration").val() + "", 1), 12, "#errorDuration", "#duration", "#durationLabel", "#insertButton", "#editButton")});
	
	// Validate USD Amount Input
	$("#usdAmountDiv").focusout(function (){/* if (compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT") || compareString(userType, "Administrador")){showFormStatus(validateInput($("#usdAmount").val() + "", 1), 13, "#errorUsdAmount", "#usdAmount", "#usdAmountLabel", "#insertButton", "#editButton")} else */ if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){showFormStatus(validateInput($("#usdAmount").val() + "", 1), 13, "#errorUsdAmount", "#usdAmount", "#usdAmountLabel", "#insertButton", "#editButton")}});
	
	// Validate COP Ingress Input
	$("#copIngressDiv").focusout(function (){showFormStatus(validateInput($("#copIngress").val() + "", 1), 14, "#errorCopIngress", "#copIngress", "#copIngressLabel", "#insertButton", "#editButton")});
	
	// Validate Strategy Select Editable
	$("#operationStrategyContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#operationStrategy").val() + "", operationStrategyItems), 15, "#errorOperationStrategy", "#operationStrategy", "#operationStrategyLabel", "#insertButton", "#editButton")});
	
	// Validate EstimatedUtility Input
	$("#estimatedUtility").focusout(function (){showFormStatus(validateInput($("#estimatedUtility").val() + "", 1), 16, "#errorEstimatedUtility", "#estimatedUtility", "#estimatedUtilityLabel", "#insertButton", "#editButton"); calculateExpectedUtility()});
	
	// Validate ConsumedQuota Input
	$("#consumedQuota").focusout(function (){showFormStatus(validateInput($("#consumedQuota").val() + "", 1), 17, "#errorConsumedQuota", "#consumedQuota", "#consumedQuotaLabel", "#insertButton", "#editButton")});
	
	// Get Geographic Info When Customer No Exist & Validate Unit Input
	$("#unit").focusout(function (){autoCompleteGeographicShortForm()});
	
	// Validate ReferredBy Select Editable
	$("#referredByContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#referredBy").val() + "", referredByItems), 25, "#errorReferredBy", "#referredBy", "#referredByLabel", "#insertButton", "#editButton")});
	
	// Validate PendingBank Select Editable
	$("#pendingBankContainer").focusout(function (){showFormStatus(validateValueSelectEditableOptional($("#pendingBank").val() + "", pendingBankItems), 26, "#errorPendingBank", "#pendingBank", "#pendingBankLabel", "#insertButton", "#editButton"); validatePendingBankSelected()});
	
	// Validate PendingCustomer Select Editable
	$("#pendingCustomerContainer").focusout(function (){showFormStatus(validateValueSelectEditableOptional($("#pendingCustomer").val() + "", pendingCustomerItems), 27, "#errorPendingCustomer", "#pendingCustomer", "#pendingCustomerLabel", "#insertButton", "#editButton"); validatePendingcustomerSelected()});
	
	// Validate Range Select Editable
	$("#range").focusout(function (){validateRange($("#range").val() + "");updateGraph()});
	
	// Update Graph Depending Current Filter
	$('#statusOperationFilter').focusout(function (){updateGraph()});
	
	// Validate Status Select Editable
	$("#statusContainer").focusout(function (){
		/* if (compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT") || compareString(userType, "Administrador")){showFormStatus(validateValueSelectEditable($("#status").val() + "", statusItems), 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");validateStatusSelected()} else */
		if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){showFormStatus(validateValueSelectEditableOptional($("#status").val() + "", statusItems), 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton")}
	});
	
	// Validate Observations TextArea
	$("#observations").focusout(function (){showFormStatus(validateTextArea($("#observations").val() + ""), 30, "#errorObservations", "#observations", "#observationsLabel", "#insertButton", "#editButton")});
	
	// Validate Reason Select Editable
	$("#reasonContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#reason").val() + "", reasonItems), 31, "#errorReason", "#reason", "#reasonLabel", "#insertButton", "#editButton")});
	
	// Validate Invalid Select Editable - Nestor
	$("#invalidContainer").focusout(function (){showFormStatus(validateValueSelectEditable($("#invalid").val() + "", invalidItems), 32, "#errorInvalid", "#invalid", "#invalidLabel", "#insertButton", "#editButton")});
	
	/***************************************************************************************************/
	/**************************************** FOCUS IN *************************************************/
	/***************************************************************************************************/
	//Show clarification in consumedQuota
	$("#consumedQuota").focusin(function (){
		removeClass("#clarificationConsumedQuota", "hide");
	});
	// Activated "Success operation" RadioButton - Nestor
	$("#successRadioLabel").focusin(function (){
		removeClass("#successRadioLabel", "successRadioLabelNormal");
		removeClass("#failedRadioLabel", "failedRadioLabelActivated");
		removeClass("#invalidRadioLabel", "invalidRadioLabelActivated");
		addClass("#successRadioLabel", " successRadioLabelActivated");
		addClass("#failedRadioLabel", " failedRadioLabelNormal");
		addClass("#invalidRadioLabel", " invalidRadioLabelNormal");
		addClass("#reasonContainer", " hide");
		addClass("#invalidContainer", " hide");
		updateProgressBar("success");
		formStates[31] = true;
	});
	
	// Activated "Failed operation" RadioButton - Nestor
	$("#failedRadioLabel").focusin(function (){
		removeClass("#failedRadioLabel", "failedRadioLabelNormal");
		removeClass("#successRadioLabel", "successRadioLabelActivated");
		removeClass("#invalidRadioLabel", "invalidRadioLabelActivated");
		removeClass("#reasonContainer", "hide");
		addClass("#invalidContainer", " hide");
		addClass("#failedRadioLabel", " failedRadioLabelActivated");
		addClass("#successRadioLabel", " successRadioLabelNormal");
		addClass("#invalidRadioLabel", " invalidRadioLabelNormal");
		updateProgressBar("failed");
		formStates[31] = false;
		formStates[32] = true;
	});
	
	// Activated "Invalid operation" RadioButton - Nestor
	$("#invalidRadioLabel").focusin(function (){
		updateProgressBar("failed");
		formStates[31] = true;
		formStates[32] = false;
		removeClass("#invalidRadioLabel", "invalidRadioLabelNormal");
		removeClass("#successRadioLabel", "successRadioLabelActivated");
		removeClass("#failedRadioLabel", "failedRadioLabelActivated");
		removeClass("#failedRadioLabel", "active");
		removeClass("#invalidContainer", " hide");
		addClass("#reasonContainer", " hide");
		addClass("#invalidRadioLabel", " invalidRadioLabelActivated");
		addClass("#successRadioLabel", " successRadioLabelNormal");
		addClass("#failedRadioLabel", " failedRadioLabelNormal");
	});
		
	// Activated "Show Opened Operations" RadioButton Nestor
	$("#radioAbiertas").focusin( function(){changeTableView("#labelRadio1", "#labelRadio2", "#labelRadio3", " AND Oportunidades.Estado <> 3", " AND YEAR(Oportunidades.FechaEstimada) IN (YEAR(NOW), YEAR(NOW) + 1)")});
	
	// Activated "Show Full Operations" RadioButton Nestor
	$("#radioFull").focusin( function(){changeTableView("#labelRadio2", "#labelRadio1", "#labelRadio3", "", " AND YEAR(Oportunidades.FechaEstimada) IN (YEAR(NOW) - 1, YEAR(NOW), YEAR(NOW) + 1)")});
	
	// Activated "Show Group Operations" RadioButton Nestor
	$("#radioGroup").focusin( function(){changeTableGroup(getUsersToShowMeCurrentGeography(replaceAll(queries.queryGetUsersToShowIII, 'rUsuario', users.currentUser),stringConnections.strConexionDataMart, connection, recordSet), " AND Oportunidades.Estado <> 3", " AND YEAR(Oportunidades.FechaEstimada) IN (YEAR(NOW), YEAR(NOW) + 1)")});
	
	
	/***************************************************************************************************/
	/****************************************** HOVER **************************************************/
	/***************************************************************************************************/
	// Activate or desactivated autocompleteCustomerButton
	$(".autocompleteCustomerButton").hover(function (){
		if ($("#nit").val().length == 0){
			changeProperty("#autocompleteCustomerButton", "disabled", true);
			changeProperty("#autocompleteCustomerButton", "title", "Es necesario ingresar un nit");
		} else{
			changeProperty("#autocompleteCustomerButton", "disabled", false);
			changeProperty("#autocompleteCustomerButton", "title", "Autocompletar cliente seg�n nit");
		}
	});
	
	// Activate or desactivated autocompleteUsdAmountButton
	$(".autocompleteUsdAmountButton").hover(function (){
		if (compareString($("#currency").val(), "USD") && $("#originalAmount").val().length > 0 ){
			changeProperty("#autocompleteUsdAmountButton", "disabled", false);
			changeProperty("#autocompleteUsdAmountButton", "title", "Calcular monto en USD");
		} else{
			if ($("#currency").val().length == 0 || $("#originalAmount").val().length == 0 || $("#rate").val().length == 0){
				changeProperty("#autocompleteUsdAmountButton", "disabled", true);
				changeProperty("#autocompleteUsdAmountButton", "title", "Es necesario ingresar un moneda, monto y tasa de cambio");
			} else{
				changeProperty("#autocompleteUsdAmountButton", "disabled", false);
				changeProperty("#autocompleteUsdAmountButton", "title", "Calcular monto en USD");
			}
		}
	});
	
	// Activate or desactivated autocompleteRrButton
	$(".autocompleteRrButton").hover(function (){
		//Carlos
		/*var estrategia= $('#product').val();
		if($('#product').val() == 'Estructuras con Opciones'||$('#product').val() == 'Opci�n Plain Vanilla'){
			assignValue("#rr", 0);
		}else{*/
		
			if ((($("#estimatedUtility").val().length != 0 && $("#consumedQuota").val().length != 0 && $("#term").val().length != 0 && hasClass($("#durationDiv").parent(), "hide")) || ($("#estimatedUtility").val().length != 0 && $("#consumedQuota").val().length != 0 && $("#duration").val().length != 0 && !hasClass($("#durationDiv").parent(), "hide"))) || ($('#product').val() == 'Estructuras con Opciones'||$('#product').val() == 'Opci�n Plain Vanilla')){
				changeProperty("#autocompleteRrButton", "disabled", false);changeProperty("#autocompleteRrButton", "title", "Calcular monto en USD");
			} else{
				changeProperty("#autocompleteRrButton", "disabled", true);changeProperty("#autocompleteRrButton", "title", "Es necesario ingresar utilidad, cupo consumido y plazo y/o duraci�n");
			}
		
		
		//}
		//Carlos
	});
	
	/***************************************************************************************************/
	/********************************* SELECT.EDITABLE-SELECT ******************************************/
	/***************************************************************************************************/
	// Consult & Autocomplete Geographic Inputs When Exist Customer
	$('#nitDiv').on('select.editable-select', function (e){autocompleteGeographicInputsLargeForm()});
	
	// Update Graph Depending Current Filter
	$('#rangeDiv, #statusOperationFilterDiv').on('select.editable-select', function (e){updateGraph()});
	
	/***************************************************************************************************/
	/***************************************** KEY DOWN ************************************************/
	/***************************************************************************************************/
	// Allow Only Numeric Values For All Numeric Inputs 
	$("#nitContainer, #originalAmountDiv, #usdAmountDiv, #copIngressDiv, #termDiv, #rateDiv, #estimatedUtilityDiv, #consumedQuotaDiv, #rrDiv, #unit").keydown(function (e){allowNumericValues(e)});
	
	/***************************************************************************************************/
	/******************************************* KEY UP ************************************************/
	/***************************************************************************************************/
	// Change State
	$('#nitDiv').keyup(function (e){changeStateSearchButton(e, "#nit", "#searchCoincidencesButton")});
	
	// Add Commas to Numeric Inputs
	$("#originalAmount, #usdAmount, #copIngress, #term, #rate, #estimatedUtility, #consumedQuota, #rr").keyup(function (e){$(this).val(addCommas(replaceAll($(this).val(), ",", "")))});
	
}