/***************************************************************************************************/
/***************************************************************************************************/
/*************************************** VARIABLES *************************************************/
/***************************************************************************************************/
/***************************************************************************************************/
// ActiveX DB Objects
var connection = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
var command = new ActiveXObject("ADODB.Command");
var fileSystem = new ActiveXObject("Scripting.FileSystemObject");
// Traders & Mail Traders
var tradersUpperArray = [];var tradersArray = [];
var userTradersUpperArray = [];var userTradersArray = [];
// Consultants & Mail Consultants
var consultantsUpperArray = [];var consultantsArray = [];
var userConsultantsUpperArray = [];var userConsultantsArray = [];
// User type
var userType = "";
// Headers Table
var headersTable = [];
// Probabilities
var probabilities = [false, false, false, true, false, false, false, false];
// Validation states
var formStates = [false, false, false, true, true, true, false, false, false, false, false, true, true, true, true, false, false, false, true, true, false, true, true, true, true, false, true, true, true, false, true, true, true];
var customerStates = [false];
var usdAmountStates = [false, false, false];
var rrStates = [false, false, false];
var expectedUtility = [false, false];
// Data for validate if opportunity exist
var dataForValidate = "";
// Data for validate if failed operation exist
var dataForValidateFailedOperation = "";
// Save row for update table immediately when opportunity is insert in DB
var rowToInsertTable = [];
// Data Graph
var labelsArray = [];
var amountUsdArray = [];
var utilityArray = [];
var registeredBusinessDetail = 0;
var expectedBusinessDetail = 0;
var registeredVolumeDetail = 0;
var expectedVolumeDetail = 0;
var expectedUtilityDetail = 0;
// Coordinator
var coordinator = "";
// Selector Datatable (OpportunitiesTableI or OpportunitiesTableT)
var selectorDatatable = "";
// Numeric Columns Array
var numericColumns = [];
// Final Message to Show
var finalMessage = "";
// Users to show Opportunities
var usersToShowMe = "";

/***************************************************************************************************/
/******************************** S T A R T  M O D U L E *******************************************/
/***************************************************************************************************/
showMessageLoading("notificationTitle", "notificationBody");
showLoadingOverlay();

$(document).ready(function() {
	// Put current version
	assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), fileSystem));
	// Get Consultants & Traders for Assign Role
	getTradersConsultantsNameAndMail(connection, recordSet, queries.queryGetTraders, stringConnections.strConexionDataMart, tradersUpperArray, userTradersUpperArray, tradersArray, userTradersArray);
	getTradersConsultantsNameAndMail(connection, recordSet, queries.queryGetConsultants, stringConnections.strConexionDataMart, consultantsUpperArray, userConsultantsUpperArray, consultantsArray, userConsultantsArray);
	// Get User Rol
	userType = getUserType(connection, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
	// Show connected user
	showUserConnected("#connected-user");
	// Show modules for user
	showModules(userType);
	// insert Log
	insertLog(connection, "Pipeline WEB");
	if(compareString(userType, "CoordinadorT")){
		getGroupCoordinador();	
	}
	if (compareString(userType, "Administrador") || compareString(userType, "TraderT") || compareString(userType, "ConsultorI") || compareString(userType, "GerencialT") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") || compareString(userType, "CoordinadorT")){
		$("#year").text(" " + (new Date()).getFullYear());
		$("#year2").text(" " + (new Date()).getFullYear() + "-" + ((new Date()).getFullYear() + 1));
		// Hide form input when user type is "Consultor"
		hideInputs();
		// Get select items
		getSelectsContent();
		// Put opportunities into table
		headersTable = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? headers.headersOpportunitiesTableI : compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT") ? headers.headersOpportunitiesTableT : headers.headersOpportunitiesTableA;
		selectorDatatable = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? "#opportunitiesTableI" : compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT") ? "#opportunitiesTableT" : "#opportunitiesTableA";
		numericColumns = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? [6, 8, 9] : compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT") ? [6, 7, 9, 10, 11, 12, 14, 15, 18] : [6, 7, 8, 9, 10, 11, 12, 16, 17, 18];
		 // Users to show Me
		if (compareString(userType, "GerencialT") || compareString(userType, "GerencialI")){
			usersToShowMe = getUsersToShowMe(replaceAll(queries.queryGetUsersByArea, "rUsuario", users.currentUser), stringConnections.strConexionDataMart, connection, recordSet);
		} else if (compareString(userType, "Administrador")){
			usersToShowMe = "";
		} else{
			usersToShowMe = getUsersToShowMeCurrentGeography(replaceAll(queries.queryGetUsersToShowII, "rUsuario", users.currentUser), stringConnections.strConexionDataMart, connection, recordSet);
		}
		// Load data on table
		buildTable(headersTable, getOpportunities(usersToShowMe, " AND Oportunidades.Estado <> 3", " AND YEAR(Oportunidades.FechaEstimada) IN (YEAR(NOW), YEAR(NOW) + 1)"), selectorDatatable);
		// Instance DataTable
		instanceTable(selectorDatatable);
		// Add export link in datatable
		addLinkOnTable(selectorDatatable + "_info", selectorDatatable + "_paginate", "exportOpportunities", "Exportar oportunidades");
		addTableTypeRadioButtons(selectorDatatable + "_length", selectorDatatable + "_filter", " selected", "", "");
		// Add Horizontally Button Scroll on datatable
		// addScrollButton(selectorDatatable + "_length");
		// Add Horizontally Scroll on datatable
		putScrollOnTable(selectorDatatable);
		// Load select items
		loadMultiplesEditableSelects(["#product", "#subProduct", "#subProduct2", "#position", "#currency", "#vehicle", "#operationStrategy", "#referredBy", "#status", "#pendingBank", "#pendingCustomer", "#reason", "#invalid"], [productItems, subProductItems, subProductItems2, positionItems, currencyItems, vehicleItems, operationStrategyItems, referredByItems, statusItems, pendingBankItems, pendingCustomerItems, reasonItems, invalidItems]);
		// Instance select editables
		intanceMultiplesEditableSelects(["#nit", "#product", "#subProduct", "#subProduct2", "#position", "#currency", "#vehicle", "#operationStrategy", "#referredBy", "#status", "#pendingBank", "#pendingCustomer", "#reason", "#range", "#invalid"]);
		// Instance DatePicker
		instanceDatePicker("#estimatedDate");
		// Load ToolTips
		loadToolTip(".required-icon", true, "Campo obligatorio", "left");
		loadToolTip("[data-toggle='tooltip']", false, "", "");
		loadToolTip(".infoTraders", true, "Esta tabla muestra el mes estimado de cierre para las oportunidades abiertas seg�n el trader.", "right");
		// Add Events to document
		addEvents();
		// Show button for user
		if(!compareString(userType, "TraderT")){
			$("#labelRadio3").addClass(" hide");
		}
	}

	if(contain(location.href, "???")){
		$("#formPipelineLink").click();
		$("#nit").val(location.href.split("???")[2]);
		$("#autocompleteCustomerButton").click();
		formStates[0] = true;
	}
	
	// Hide start message when page is charged and show main container
	hideStartMessage("#loading", ".container");
	hideLoadingOverlay();
	
});