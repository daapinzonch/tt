// Validate if opportunity exist in DB & insert him
function insertFailedOperation(data){
	var queryInsert = replaceAll(queries.consultaInsertarFallida, "datos", data);
	var queryValidateExist = queries.consultaExistenciaFallida + dataForValidateFailedOperation;
	var stringConnection = stringConnections.strConexionFailedOperations;
	
	if (hasClass("#failedRadioLabel", "active")){
		if (!existInBD(connection, recordSet, queryValidateExist, stringConnection)){
			if (insert(queryInsert, stringConnection, connection)){
				finalMessage = "Este registro tambi�n fue ingresado en el m�dulo de operaciones fallidas. ";
			} else{
				finalMessage = "Ocurri� un error intentanto ingresar esta operaci�n fallida. ";
			}
		} else{
			finalMessage = "Esta operaci�n no fue ingresada en la tabla de Operaciones fallidas porque ya exist�a. ";
		}
	}
}