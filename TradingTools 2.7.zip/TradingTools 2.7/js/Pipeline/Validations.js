/***************************************************************************************************/
/********************************* F O R M  I N P U T S ********************************************/
/***************************************************************************************************/
// Validate Nit, OriginalAmount, Term, Rate, EstimatedUtility, ConsumedQuota Inputs
function validateInput(value, quantityDotsLimit){
	if (value.length == 0) return getEmptyError();
	if (haveDots(value, quantityDotsLimit)) return getLimitDotsError(quantityDotsLimit);
	if (compareString(value, ".")) return getNumericError();
	if (parseFloat(value) == 0) return getValueZeroError();
	if (compareString(value.charAt(0), '.')) return getIncompleteValueError();
	
	return "";
}

// Validate Customer Input
function validateCustomerInput(value){
	if (value.indexOf("'") != -1) return getInvertedCommaError();
	if (value.length == 0) return getEmptyError();
	if (compareString(value, "No encontrado")) return getValueInvalidError();
	
	return "";
}

// Validate Product, Currency, Strategy, ReferredBy, Status Selects Editables
function validateValueSelectEditable(value, items){
	if (value.length == 0) return getEmptyError();
	if (!belongToString(value, items)) return getItemDontBelongError();
	
	return "";
}

// Validate PositionContainer, PendingBank, PendingCustomer Select Editables
function validateValueSelectEditableOptional(value, items){
	if (!belongToString(value, items)) return getItemDontBelongError();
	
	return "";
}

// Validate EstimatedDate Input
function validateDateInput(value){
	var currentDate = getDate(0, false).split("/");
	var day = value.substring(0,2);
	var month = value.substring(3,5);
	var year = value.substring(6,10);
	var currentDay = currentDate[0];
	var currentMonth = currentDate[1];
	var currentYear = currentDate[2];
	
	if (value.length == 0) return getEmptyError();
	if (value.length != 10) return getLengthError(10);
	if (day.indexOf("/") != -1 || month.indexOf("/") != -1 || year.indexOf("/") != -1 || day.length < 2 || month.length < 2 || year.length < 4) return getDateStructureInvalidError();
	if (parseInt(month) > 12 || parseInt(month) < 1) return getLimitMonthError();
	if (parseInt(day) > 31 || parseInt(day) < 1) return getLimitDayError();
	if ((parseInt(month) < parseInt(currentMonth) && parseInt(year) <= parseInt(currentYear)) || (parseInt(year) < parseInt(currentYear)) || (parseInt(day) < parseInt(currentDay) && parseInt(month) <= parseInt(currentMonth) && parseInt(year) <= parseInt(currentYear))) return getMinimumDateError();
	
	return "";
}

// Validate Observations TextArea
function validateTextArea(value){
	return (value.indexOf("'") != -1) ? getInvertedCommaError() : "";
}

// Validate Range Input
function validateRange(value){
	if (compareString(value, "Mensual") || compareString(value, "Trimestral") || compareString(value, "Semestral")){changeProperty("#statusOperationFilter", "disabled", false)}
	else{$("#statusOperationFilter").val("");changeProperty("#statusOperationFilter", "disabled", true)}
}

/***************************************************************************************************/
/******************************* S T A T U S  I N P U T S ******************************************/
/***************************************************************************************************/
// Show input, label, message error or success & activate or disabled button
function showFormStatus(error, numImput, selectorErrorMessage, selectorInput, selectorLabel, selectorFormButton, selectorEditFormButton){
	showInputContainerStatus(error, numImput, selectorErrorMessage, selectorInput, selectorLabel);
	changeButtonFormStatus(selectorFormButton, selectorEditFormButton);
}

// Show input, label, message error or success
function showInputContainerStatus(error, numImput, selectorErrorMessage, selectorInput, selectorLabel){
	if (compareString(error, "")){
		formStates[numImput] = true;
		
		addClass(selectorErrorMessage, " hide");
		addClass(selectorInput, " successInput");
		addClass(selectorLabel, " successLabel");
		removeClass(selectorInput, " errorInput");
		removeClass(selectorLabel, " errorLabel");
	} else{
		formStates[numImput] = false;
		
		assignContent(selectorErrorMessage, error);
		
		removeClass(selectorErrorMessage, " hide");
		removeClass(selectorInput, " successInput");
		removeClass(selectorLabel, " successLabel");
		addClass(selectorInput, " errorInput");
		addClass(selectorLabel, " errorLabel");
	}
}

// Activate or disabled button
function changeButtonFormStatus(selectorFormButton, selectorEditFormButton){
	if (!isInArray(false, formStates)){
		changeProperty(selectorFormButton, "disabled", false);
		changeProperty(selectorEditFormButton, "disabled", false);
	} else{
		changeProperty(selectorFormButton, "disabled", true);
		changeProperty(selectorEditFormButton, "disabled", true);
	}
}

// Put, Change or Hide GraphDetails's Clarification
function validateClarificationGraphDetails(){
	if (compareString($("#statusOperationFilter").val(), "Oper. Fallida")){
		$("#clarificationBigDetails").html("**Solo tiene en cuenta operaciones fallidas");
		removeClass("#clarificationBigDetails", "hide");
	} else if (compareString($("#statusOperationFilter").val(), "Oper. Exitosa")){
		$("#clarificationBigDetails").html("**Solo tiene en cuenta operaciones exitosas");
		removeClass("#clarificationBigDetails", "hide");
	} else{
		addClass("#clarificationBigDetails", " hide");
	}
}

// Put, Change or Hide Graph's Clarification
function validateClarificationGraph(){
	if (compareString($("#statusOperationFilter").val(), "")){
		myChart.options.title.text = ["Flujo de Negocios Puntuales " + (new Date()).getFullYear(), "**No tiene en cuenta operaciones fallidas ni exitosas"];
		myChart.update();
	} else{
		myChart.options.title.text = "Flujo de Negocios Puntuales " + (new Date()).getFullYear();
		myChart.update();
	}
}

/***************************************************************************************************/
/************************ V A L I D A T I O N  F U N C T I O N S ***********************************/
/***************************************************************************************************/
// Validate if progress bar is in first or last position
function validateProgressPosition(index, firstPosition, lastPosition, action){
	if (index == firstPosition){ //0% - Nestor
		addClass("#previusProgress", "hide");addClass("#failedRadioLabel", " failedRadioLabelActivated"); addClass("#failedRadioLabel", " active");addClass("#successRadioLabel", " successRadioLabelNormal");
		removeClass("#nextProgress", "hide");removeClass("#failedRadioLabel", " failedRadioLabelNormal");removeClass("#successRadioLabel", " successRadioLabelActivated");removeClass("#successRadioLabel", "active");removeClass(".panelOperation", " hide");removeClass("#reasonContainer", "hide");
		
		$("#reason").val("");
		$("#invalid").val("");
		formStates[31] = false;
		formStates[32] = true;
		destroyEditableSelect("#reason");
		destroyEditableSelect("#invalid");
		instanceEditableSelect("#reason");
		instanceEditableSelect("#invalid");
		
		if (!compareString(userType, "ConsultorI") && !compareString(userType, "GerencialI") && !compareString(userType, "CoordinadorI")){
			$("#status").val("Cierre");
			[26, 27, 28].forEach(function(a){formStates[a] = true});
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			if (!compareString($("#pendingCustomer").val(), "Cliente no va a cerrar")){$("#pendingCustomer").val("");destroyEditableSelect("#pendingCustomer");instanceEditableSelect("#pendingCustomer")}
			$("#pendingBank").val("");
			destroyEditableSelect("#pendingBank");instanceEditableSelect("#pendingBank");
			removeClass($("#pendingBankLabel"), "successLabel");removeClass($("#pendingBankLabel"), "errorLabel");removeClass($("#pendingBank"), "successInput");removeClass($("#pendingBank"), "errorInput");removeClass($("#pendingCustomerLabel"), "successLabel");removeClass($("#pendingCustomerLabel"), "errorLabel");removeClass($("#pendingCustomer"), "successInput");removeClass($("#pendingCustomer"), "errorInput");
			addClass("#errorPendingCustomer", " hide");addClass("#errorPendingBank", " hide");
			changeProperty("#pendingBank", "disabled", true);
			changeProperty("#pendingCustomer", "disabled", true);
			changeProperty("#status", "disabled", true);
		} else{
			$("#status").val("");
			formStates[28] = true;
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			changeProperty("#status", "disabled", true);
		}
	} else if (index == lastPosition){ //100% - Nestor
	 	addClass("#nextProgress", "hide");addClass("#successRadioLabel", " successRadioLabelActivated");addClass("#successRadioLabel", " active");addClass("#failedRadioLabel", " failedRadioLabelNormal");addClass("#reasonContainer", " hide");addClass("#invalidContainer", " hide");
		removeClass("#previusProgress", "hide");removeClass("#successRadioLabel", " successRadioLabelNormal");removeClass("#failedRadioLabel", " failedRadioLabelActivated");removeClass("#failedRadioLabel", "active");removeClass(".panelOperation", " hide");
		
		$("#reason").val("");
		$("#invalid").val("");
		$("#estimatedDate").val(getDate(0));
		formStates[31] = true;
		formStates[32] = true;
		formStates[8] = true;
		
		if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){
			$("#status").val("");
			formStates[28] = true;
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			destroyEditableSelect("#status");
			instanceEditableSelect("#status");
			changeProperty("#status", "disabled", true);
		} else{
			$("#status").val("Cierre");
			$("#pendingBank").val("");
			$("#pendingCustomer").val("");
			[26, 27, 28, 31].forEach(function(a){formStates[a] = true});
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			destroyEditableSelect("#pendingBank");destroyEditableSelect("#pendingCustomer");
			instanceEditableSelect("#pendingBank");instanceEditableSelect("#pendingCustomer");
			removeClass($("#pendingBankLabel"), "successLabel");removeClass($("#pendingBankLabel"), "errorLabel");removeClass($("#pendingBank"), "successInput");removeClass($("#pendingBank"), "errorInput");removeClass($("#pendingCustomerLabel"), "successLabel");removeClass($("#pendingCustomerLabel"), "errorLabel");removeClass($("#pendingCustomer"), "successInput");removeClass($("#pendingCustomer"), "errorInput");
			addClass("#errorPendingCustomer", " hide");addClass("#errorPendingBank", " hide");
			changeProperty("#pendingBank", "disabled", true);
			changeProperty("#pendingCustomer", "disabled", true);
			changeProperty("#status", "disabled", true);
		}
	} else{ // 10%, 25%, 50%, 70%, 90%, 95% - Nestor
		removeClass("#nextProgress", "hide");removeClass("#previusProgress", "hide");removeClass("#failedRadioLabel", " failedRadioLabelActivated");removeClass("#failedRadioLabel", "active");removeClass("#successRadioLabel", " successRadioLabelActivated");removeClass("#successRadioLabel", "active");
		addClass("#failedRadioLabel", " failedRadioLabelNormal");addClass("#successRadioLabel", " successRadioLabelNormal");addClass(".panelOperation", " hide");addClass("#reasonContainer", " hide");addClass("#invalidContainer", " hide");
		
		$("#reason").val("");
		$("#invalid").val("");
		formStates[31] = true;
		formStates[32] = true;
		
		if (compareString($("#status").val(), "") || compareString($("#status").val(), "En Espera de Nivel")){
			changeProperty("#status", "disabled", false);
			formStates[28] = false;
		}
		
		if (compareString($("#pendingCustomer").val(), "Cliente no va a cerrar")){
			destroyEditableSelect("#pendingCustomer");instanceEditableSelect("#pendingCustomer");
			formStates[28] = true;
		}
		
		if (!compareString(userType, "ConsultorI") && !compareString(userType, "GerencialI") && !compareString(userType, "CoordinadorI")){
			changeProperty("#pendingBank", "disabled", false);
			changeProperty("#pendingCustomer", "disabled", false);
			
			$('#status').val("En Cotizaci�n");
			formStates[28] = true;
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			changeProperty("#status", "disabled", true);
		}
	}
	
	if (!compareString(userType, "ConsultorI") && !compareString(userType, "GerencialI") && !compareString(userType, "CoordinadorI")) calculateExpectedUtility();
}

// Validate dots quantity of value
function haveDots(value, dotsLimit){
	var dots = 0;
	
	for (var i = 0; i < value.length; i++){
		if (value.charAt(i) == ".") dots++;
	}
	
	return dots > dotsLimit;
}

// Validate if string belong to stringItems
function belongToString(value, items){
	var itemsArray = replaceAll(items, "<option>", "").split("</option>");
	
	for (i = 0; i < itemsArray.length; i++){
		if (compareString(value, itemsArray[i])) return true;
	}
	
	return false;
}

// Show Sub Product Input
function validateProductSelected(){
	if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){
		var inputsToClean = ["#rate", "#term", "#usdAmount", "#copIngress"];
		var selectsToReset = ["#subProduct", "#subProduct2", "#vehicle"];
		var errorsToHide = ["#errorTerm", "#errorUsdAmount", "#errorCopIngress", "#errorSubProduct", "#errorSubProduct2"];
		var inputsToCleanClasses = ["#term", "#usdAmount", "#copIngress", "#subProduct", "#subProduct2"];
		var labelToCleanClasses = ["#termLabel", "#usdAmountLabel", "#copIngressLabel", "#subProductLabel", "#subProductLabel2"];
	
		inputsToClean.forEach(function(a){assignValue(a, "")});
		selectsToReset.forEach(function(a){destroyEditableSelect(a); instanceEditableSelect(a)});
		errorsToHide.forEach(function(a){addClass(a, " hide")});
		inputsToCleanClasses.forEach(function(a){removeClass(a, " successInput");removeClass(a, " errorInput")});
		labelToCleanClasses.forEach(function(a){removeClass(a, " successLabel");removeClass(a, " errorLabel")});
		removeClass($("#rateDiv").parent(), " hide");
		
		if (compareString($("#product").val(), "Comisi�n")){
			var selectorsToAddClasses = [$("#subProductContainer2").parent(), $("#usdAmountDiv").parent(), $("#termDiv").parent(), $("#rateDiv").parent(), $("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#termDiv").parent()];
			var selectorsToRemoveClasses = [$("#subProductContainer").parent(), $("#copIngressDiv").parent(), $("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#vehicleContainer").parent(), $("#rateDiv").parent(), $("#termDiv").parent()];
			var clasessToAdd = [" hide", " hide", " hide", " hide", " col-xs-6", " col-xs-6", " col-xs-6", " col-xs-4"];
			var clasessToRemove = ["hide", "hide", "col-xs-8 col-xs-offset-2", "col-xs-3", "col-xs-4", "col-xs-3", "col-xs-4", "col-xs-3", "col-xs-3"];
			
			addMultipleClassesToMultipleElements(selectorsToAddClasses, clasessToAdd);
			removeMultipleClassesToMultipleElements(selectorsToRemoveClasses, clasessToRemove);
			
			[3, 14].forEach(function(a){formStates[a] = false});
			[4, 9, 10, 13].forEach(function(a){formStates[a] = true});
		} else if(compareString($("#product").val(), "Captaci�n")){
			var selectorsToAddClasses = [$("#subProductContainer").parent(), $("#copIngressDiv").parent(), $("#termDiv").parent(), $("#termDiv").parent(), $("#rateDiv").parent(), $("#estimatedDateDiv").parent(), $("#productContainer").parent(), $("#vehicleContainer").parent()];
			var selectorsToRemoveClasses = [$("#subProductContainer2").parent(), $("#usdAmountDiv").parent(), $("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#vehicleContainer").parent(), $("#rateDiv").parent(), $("#termDiv").parent()];
			var clasessToAdd = [" hide", " hide", " hide", " col-xs-4", " col-xs-4", " col-xs-4", " col-xs-6", " col-xs-4"];
			var clasessToRemove = ["hide", "hide", "col-xs-8 col-xs-offset-2", "col-xs-3", "col-xs-6", "col-xs-3", "col-xs-6", "col-xs-3", "col-xs-3"];
		
			addMultipleClassesToMultipleElements(selectorsToAddClasses, clasessToAdd);
			removeMultipleClassesToMultipleElements(selectorsToRemoveClasses, clasessToRemove);
			
			formStates[10] = compareString(validateInput($("#rate").val() + "", 1), "") ? true : false;
			formStates[4] = false;
			formStates[13] = false;
			
			[3, 9, 14].forEach(function(a){formStates[a] = true});
		} else if(compareString($("#product").val(), "Cartera")){
			var selectorsToAddClasses = [$("#subProductContainer").parent(), $("#subProductContainer2").parent(), $("#copIngressDiv").parent(), $("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#termDiv").parent(), $("#rateDiv").parent()];
			var selectorsToRemoveClasses = [$("#usdAmountDiv").parent(), $("#termDiv").parent(), $("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#vehicleContainer").parent(), $("#termDiv").parent(), $("#rateDiv").parent()];
			var clasessToAdd = [" hide", " hide", " hide", " col-xs-8 col-xs-offset-2", " col-xs-3", " col-xs-3", " col-xs-3", " col-xs-3"];
			var clasessToRemove = ["hide", "hide", "col-xs-6", "col-xs-4", "col-xs-6", "col-xs-4", "col-xs-6", "col-xs-4", "col-xs-4"];
		
			addMultipleClassesToMultipleElements(selectorsToAddClasses, clasessToAdd);
			removeMultipleClassesToMultipleElements(selectorsToRemoveClasses, clasessToRemove);
			
			formStates[9] = compareString(validateInput($("#term").val() + "", 0), "") ? true : false;
			formStates[10] = compareString(validateInput($("#rate").val() + "", 1), "") ? true : false;
			formStates[13] = false;
			[3, 4, 14].forEach(function(a){formStates[a] = true});
		} else{
			var selectorsToAddClasses = [$("#subProductContainer2").parent(), $("#subProductContainer").parent(), $("#copIngressDiv").parent(), $("#usdAmountDiv").parent(), $("#termDiv").parent(), $("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#termDiv").parent(), $("#rateDiv").parent()];
			var selectorsToRemoveClasses = [$("#productContainer").parent(), $("#estimatedDateDiv").parent(), $("#estimatedDateDiv").parent(), $("#vehicleContainer").parent(), $("#vehicleContainer").parent(), $("#rateDiv").parent(), $("#termDiv").parent()];
			var clasessToAdd = [" hide", " hide", " hide", " hide", " hide", " col-xs-8 col-xs-offset-2", " col-xs-4", " col-xs-4", " col-xs-4", " col-xs-4"];
			var clasessToRemove = ["col-xs-6", "col-xs-3", "col-xs-6", "col-xs-3", "col-xs-6", "col-xs-3", "col-xs-3"];
		
			addMultipleClassesToMultipleElements(selectorsToAddClasses, clasessToAdd);
			removeMultipleClassesToMultipleElements(selectorsToRemoveClasses, clasessToRemove);
			
			[3, 4, 9, 13, 14].forEach(function(a){formStates[a] = true});
			formStates[10] = compareString(validateInput($("#rate").val() + "", 1), "") ? true : false;
		}
		
	} else if (compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT")){
		$("#term").val("");
		$("#consumedQuota").val("");
		$("#rr").val("");
		$("#duration").val("");
		
		if (compareString($("#product").val(), "Spot USD/COP") || compareString($("#product").val(), "Spot Fx")){
			addClass($("#termDiv").parent(), " hide");addClass($("#consumedQuotaDiv").parent(), " hide");addClass($("#rrDiv").parent(), " hide");addClass($("#estimatedDateDiv").parent(), " col-xs-6");addClass($("#rateDiv").parent(), " col-xs-6");addClass($("#estimatedUtilityDiv").parent(), " col-xs-8 col-xs-offset-2");
			removeClass($("#estimatedDateDiv").parent(), "col-xs-4");removeClass($("#rateDiv").parent(), "col-xs-4");removeClass($("#estimatedUtilityDiv").parent(), "col-xs-4");
			formStates[9] = true;
			formStates[17] = true;
		} else if(compareString($("#product").val(), "Estructuras con Opciones") || compareString($("#product").val(), "Opci�n Plain Vanilla")){
			formStates[17] = true;
		} else{
			removeClass($("#termDiv").parent(), " hide");removeClass($("#consumedQuotaDiv").parent(), " hide");removeClass($("#rrDiv").parent(), " hide");removeClass($("#estimatedDateDiv").parent(), " col-xs-6");removeClass($("#rateDiv").parent(), " col-xs-6");removeClass($("#estimatedUtilityDiv").parent(), " col-xs-8 col-xs-offset-2");
			addClass($("#estimatedDateDiv").parent(), "col-xs-4");addClass($("#rateDiv").parent(), "col-xs-4");addClass($("#estimatedUtilityDiv").parent(), "col-xs-4");
			formStates[9] = false;
			formStates[17] = false;
		}
		
		if (compareString($("#product").val(), "IRS USD") || compareString($("#product").val(), "IRS COP") || compareString($("#product").val(), "CCS") || compareString($("#product").val(), "Sintetico Financiaci�n-Swap")){
			formStates[12] = false;
			removeClass($("#durationDiv").parent(), "hide");removeClass($("#durationLabel"), "successLabel");removeClass($("#durationLabel"), "errorLabel");removeClass($("#duration"), "successInput");removeClass($("#duration"), "errorInput");
			removeClass($("#termLabel"), "successLabel");removeClass($("#termLabel"), "errorLabel");removeClass($("#term"), "successInput");removeClass($("#term"), "errorInput");
			addClass("#errorDuration", " hide");
		} else{
			addClass($("#durationDiv").parent(), " hide");
			formStates[12] = true;
		}
	}
	
	changeButtonFormStatus("#insertButton", "#editButton");
}

// Show Term Input
function validateSubproduct2Selected(){
	if (compareString($("#subProduct2").val(), "Dep�sito a plazo")){
		addMultipleClassesToMultipleElements([$("#estimatedDateDiv").parent(), $("#termDiv").parent(), $("#rateDiv").parent(), $("#vehicleContainer").parent(), $("#copIngressDiv").parent()], [" col-xs-3", " col-xs-3", " col-xs-3", " col-xs-3", " hide"]);
		removeMultipleClassesToMultipleElements([$("#termDiv").parent(), $("#estimatedDateDiv").parent(), $("#termDiv").parent(), $("#rateDiv").parent(), $("#vehicleContainer").parent()], ["hide", "col-xs-4", "col-xs-4", "col-xs-4", "col-xs-4"]);
		[9, 13].forEach(function(a){formStates[a] = false});
		[3, 4, 14].forEach(function(a){formStates[a] = true});
		["#term", "#usdAmount", "#copIngress"].forEach(function(a){assignValue(a, "")});
	} else if (compareString($("#subProduct2").val(), "Cuenta")){
		addMultipleClassesToMultipleElements([$("#termDiv").parent(), $("#subProductContainer").parent(), $("#copIngressDiv").parent(), $("#estimatedDateDiv").parent(), $("#termDiv").parent(), $("#rateDiv").parent(), $("#vehicleContainer").parent()], [" hide", " hide", " hide", " col-xs-4", " col-xs-4", " col-xs-4", " col-xs-4"]);
		removeMultipleClassesToMultipleElements([$("#rateDiv").parent(), $("#estimatedDateDiv").parent(), $("#termDiv").parent(), $("#vehicleContainer").parent()], ["col-xs-3", "col-xs-3", "col-xs-3", "col-xs-3"]);
		formStates[13] = false;
		[3, 14, 9].forEach(function(a){formStates[a] = true});
		["#subProduct", "#term", "#usdAmount", "#copIngress"].forEach(function(a){assignValue(a, "")});
	} else{
		addMultipleClassesToMultipleElements([$("#termDiv").parent(), $("#subProductContainer").parent(), $("#copIngressDiv").parent(), $("#estimatedDateDiv").parent(), $("#termDiv").parent(), $("#rateDiv").parent(), $("#vehicleContainer").parent()], [" hide", " hide", " hide", " col-xs-4", " col-xs-4", " col-xs-4", " col-xs-4"]);
		removeMultipleClassesToMultipleElements([$("#rateDiv").parent(), $("#estimatedDateDiv").parent(), $("#termDiv").parent(), $("#vehicleContainer").parent()], ["col-xs-3", "col-xs-3", "col-xs-3", "col-xs-3"]);
		[3, 13, 14, 9].forEach(function(a){formStates[a] = true});
		["#subProduct", "#subProduct2", "#term", "#usdAmount", "#copIngress"].forEach(function(a){assignValue(a, "")});
	}
	
	changeButtonFormStatus("#insertButton", "#editButton");
}

//Show Status Operation Panel when "Cierre" is Selected
function validateStatusSelected(){
	if (compareString($("#status").val(), "Cierre")){
		removeClass(".panelOperation", " hide");
		changeProperty("#pendingBank", "disabled", true);
		changeProperty("#pendingCustomer", "disabled", true);
		updateProgressBar("failed");
	} else{
		addClass(".panelOperation", " hide");
		changeProperty("#pendingBank", "disabled", false);
		changeProperty("#pendingCustomer", "disabled", false);
	}
}

// Put or hide Status Value Depending of PendingBank Value
function validatePendingBankSelected(){
	// Show "En Aprobaci�n del Banco" in Status Input
	if (!compareString($("#pendingBank").val(), "")){
		destroyEditableSelect("#status");
		instanceEditableSelect("#status");
		$("#status").val("En Aprobaci�n del Banco");
		formStates[28] = true;
		showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
	} else{
		if (compareString($("#status").val(), "En Aprobaci�n del Banco")){
			$("#status").val("");
			formStates[28] = false;
			removeClass($("#statusLabel"), "successLabel");
			removeClass($("#status"), "successInput");
		}
	}
	
	// Show/Hide "En Cotizaci�n" in Status Input
	validateInCotization();
	// Show "En revisi�n del banco y cliente" in Status Input
	validateReviewBankCustomer();
}

// Put or hide Status Value Depending of PendingBank Value
function validatePendingcustomerSelected(){
	// Show "En Revisi�n del Cliente" in Status Input
	if (!compareString($("#pendingCustomer").val(), "Cliente no va a cerrar") && !compareString($("#pendingCustomer").val(), "En Espera de Nivel") && !compareString($("#pendingCustomer").val(), "")){
		destroyEditableSelect("#status");
		instanceEditableSelect("#status");
		$("#status").val("En Revisi�n del Cliente");
		formStates[28] = true;
		showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
	} else{
		if (compareString($("#status").val(), "En Revisi�n del Cliente")){
			$("#status").val("");
			formStates[28] = false;
			removeClass($("#statusLabel"), "successLabel");
			removeClass($("#status"), "successInput");
		}
	}
	
	// Show/Hide "En Cotizaci�n" in Status Input
	validateInCotization();
	// Put "Operaci�n Fallida" when "Cliente no va a cerrar" is in PendingCustomer Input
	if (compareString($("#pendingCustomer").val(), "Cliente no va a cerrar")){
		destroyEditableSelect("#status");
		instanceEditableSelect("#status");
		removeClass(".panelOperation", " hide");
		$("#failedRadioLabel").click();
		$("#status").val("Cierre");
		formStates[28] = true;
		showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
		changeProperty("#pendingBank", "disabled", true);
		changeProperty("#pendingCustomer", "disabled", true);
	} else{
		addClass(".panelOperation", " hide");
		removeClass("#failedRadioLabel", " active failedRadioLabelActivated");
		updateProgressBar("changeStatus");
		changeProperty("#pendingBank", "disabled", false);
		changeProperty("#pendingCustomer", "disabled", false);
		
		if (compareString($("#status").val(), "Cierre")){
			$("#status").val("");
			formStates[28] = false;
			removeClass($("#statusLabel"), "successLabel");
			removeClass($("#status"), "successInput");
		}
	}
	// Show "En revisi�n del banco y cliente" in Status Input
	validateReviewBankCustomer();
}

// Hide "Rate" Input when "USD" is Selected
function validateCurrencySelected(){
	if (compareString($("#currency").val(), "USD")){
		$("#rate").val("1");
		addClass($("#rateDiv").parent(), " hide");
		addClass($("#estimatedDateDiv").parent(), " col-xs-8 col-xs-offset-2");
		
		removeClass($("#estimatedDateDiv").parent(), "col-xs-6");
		
		formStates[10] = true;
	} else{
		$("#rate").val("");
		
		removeClass($("#rateDiv").parent(), "hide");
		removeClass($("#estimatedDateDiv").parent(), "col-xs-8 col-xs-offset-2");
		
		addClass($("#estimatedDateDiv").parent(), " col-xs-6");
		
		formStates[10] = false;
	}
	
	changeButtonFormStatus("#insertButton", "#editButton");
}

// Validate if probability is 0 for insert in FailesOperations Table
function validateFailedOperation(){
	if (!compareString(userType, "ConsultorI") && !compareString(userType, "GerencialI") && !compareString(userType, "CoordinadorI")){
		if (compareString(getCleanValueForm(".progress-bar", "Progress", 0, "", []), "0")){
			insertFailedOperation(getFormData("InsertFailedOperation"));
		} else{
			$("#modalInfFooter").html("");
		}
	} 
}

// Show/Hide "En Cotizaci�n" in Status Input
function validateInCotization(){
	if ((compareString($("#pendingBank").val(), "") && (compareString($("#pendingCustomer").val(), ""))) || (compareString($("#pendingCustomer").val(), "En Espera de Nivel"))){
		$('#status').val("En Cotizaci�n");
		formStates[28] = true;
		showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
		changeProperty("#status", "disabled", true);
	} else{
		$('#status').val("");
		formStates[28] = false;
		changeProperty("#status", "disabled", false);
	}
}

// Show "En revisi�n del banco y cliente" in Status Input
function validateReviewBankCustomer(){
	if (!compareString($("#pendingBank").val(), "") && !compareString($("#pendingCustomer").val(), "")){
		destroyEditableSelect("#status");
		instanceEditableSelect("#status");
		$("#status").val("En Revisi�n del Banco y Cliente");
		formStates[28] = true;
		showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
		changeProperty("#status", "disabled", true);
	} else{
		if (!compareString($("#pendingCustomer").val(), "Cliente no va a cerrar") && !compareString($("#pendingCustomer").val(), "En Espera de Nivel") && !compareString($("#pendingCustomer").val(), "")){
			destroyEditableSelect("#status");
			instanceEditableSelect("#status");
			$("#status").val("En Revisi�n del Cliente");
			formStates[28] = true;
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			changeProperty("#status", "disabled", true);
		} else{
			if (compareString($("#status").val(), "En Revisi�n del Cliente")){
				$("#status").val("");
				formStates[28] = false;
				removeClass($("#statusLabel"), "successLabel");
				removeClass($("#status"), "successInput");
				changeProperty("#status", "disabled", false);
			}
		}
		
		if (!compareString($("#pendingBank").val(), "")){
			destroyEditableSelect("#status");
			instanceEditableSelect("#status");
			$("#status").val("En Aprobaci�n del Banco");
			formStates[28] = true;
			showFormStatus("", 28, "#errorStatus", "#status", "#statusLabel", "#insertButton", "#editButton");
			changeProperty("#status", "disabled", true);
		} else{
			if (compareString($("#status").val(), "En Aprobaci�n del Banco")){
				$("#status").val("");
				formStates[28] = false;
				removeClass($("#statusLabel"), "successLabel");
				removeClass($("#status"), "successInput");
				changeProperty("#status", "disabled", false);
			}
		}
	}
}