// Put details For Consultants in tables
function putBigDetails(){
	var queryCE = replaceAll(replaceAll(queries.queryConsultBigDetails, "rGroup", "Segmento"), "rCriterion", " AND Banca = 'CE'");
	var queryPMP = replaceAll(replaceAll(queries.queryConsultBigDetails, "rGroup", "Segmento"), "rCriterion", " AND Banca = 'PMP'");
	var queryCoordinators = replaceAll(replaceAll(queries.queryConsultBigDetails, "rGroup", "Coordinador"), "rCriterion", "");
	var queryActives = replaceAll(queries.queryConsultBigDetailsII, "rCriterion", " AND (EstadoOperaci�n IS NULL OR EstadoOperaci�n = '')");
	var queryInactivesSuccess = replaceAll(queries.queryConsultBigDetailsII, "rCriterion", " AND (EstadoOperaci�n = 'Oper. Exitosa')");
	var queryInactivesFailed = replaceAll(queries.queryConsultBigDetailsII, "rCriterion", " AND (EstadoOperaci�n = 'Oper. Fallida')");
	
	$("#ce").html(consultDetails(queryCE));
	$("#pmp").html(consultDetails(queryPMP));
	$("#coordinators").html(consultDetails(queryCoordinators));
	$("#actives").html(consultDetailsII(queryActives, "activesTable"));
	$("#inactives").html("<div class='row'><div class='col-xs-6'><div class='col-xs-12 tableBigDetails'><span class='tableTitle'>Exitosas</span></div><div class='col-xs-12'>" + consultDetailsII(queryInactivesSuccess, "successTable") + "</div></div><div class='col-xs-6'><div class='col-xs-12 tableBigDetails'><span class='tableTitle'>Fallidas</span></div><div class='col-xs-12'>" + consultDetailsII(queryInactivesFailed, "failedTable") + "</div></div></div>");
	
	validateTable("#ce", "#buttonCE");
	validateTable("#pmp", "#buttonPMP");
	validateTable("#coordinators", "#buttonCoordinators");
	validateTable("#actives", "#buttonActives");
	validateTable("#inactives", "#buttonInactives");
	
	getSumColumns("#ce");
	getSumColumns("#pmp");
	getSumColumns("#coordinators");
	getSumColumns("#activesTable");
	getSumColumns("#successTable");
	getSumColumns("#failedTable");
}

// Put details For Traders in tables
function putBigDetailsT(){
	var tableDetailsBanksCE = consultDetailsT(replaceAll(queries.queryConsultBigDetailsTII, "rBank", "CE"), "Banca Empresas " + ((new Date()).getFullYear() - 1) + "-" + (new Date()).getFullYear());
	var tableDetailsBanksPMP = consultDetailsT(replaceAll(queries.queryConsultBigDetailsTII, "rBank", "PMP"), "PYME " + ((new Date()).getFullYear() - 1) + "-" + (new Date()).getFullYear());
	var tableDetailsTradersCE = consultDetailsTII(replaceAll(queries.queryConsultBigDetailsT, "rBank", "CE"), "Banca Empresas");
	var tableDetailsTradersPMP = consultDetailsTII(replaceAll(queries.queryConsultBigDetailsT, "rBank", "PMP"), "PYME");

	$("#banks").html("<div class='row'>" + tableDetailsBanksCE + tableDetailsBanksPMP + "</div>");
	$("#traders").html("<div class='row'>" + tableDetailsTradersCE + tableDetailsTradersPMP + "</div>");
}

// Validate if table is empty and hide it
function validateTable(selectorTable, selectorButton){
	if (compareString($(selectorTable).html(), "")){
		addClass(selectorButton, " hide");
	} else{
		removeClass(selectorButton, "hide");
	}
}

// Get SUM Column and put in tfoot
function getSumColumns(selectorTable){
	assignContent(selectorTable + " .sumA", sumColumn(selectorTable + " .a"));
	assignContent(selectorTable + " .sumB", sumColumn(selectorTable + " .b"));
	assignContent(selectorTable + " .sumC", sumColumn(selectorTable + " .c"));
	assignContent(selectorTable + " .sumD", sumColumn(selectorTable + " .d"));
	assignContent(selectorTable + " .sumE", sumColumn(selectorTable + " .e"));
}