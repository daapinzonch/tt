var rowForEdit;
var idForEdit = "";

// Get opportunity data for edit in form
function putOpportunityDataInForm(id, action){
	// Open Form
	$("#formPipelineLink").click();
	// Consult & Put opportunity data in form
	putDataOpportunityForEdit(id);
	// Consult & Put geographic information in form
	putInfoGeographicForEdit();
	// Change Status Inputs Form
	formStates = [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true];
	
	if (compareString(action, "Editar")){
		// Disabled Form Buttons
		changeProperty("#insertButton", "disabled", false);
		changeProperty("#editButton", "disabled", false);
		// Show Edit Button
		removeClass("#editButtonDiv", "hide");
		addClass("#insertButtonDiv", " hide");
		// Save opportunity id
		changeProperty("#editButton", "value", id + "");
	} else if(compareString(action, "Reutilizar")){
		changeProperty("#insertButton", "disabled", false);
	}
}

// Update opportunity in DB
function updateOpportunity(data, id){
	// Query & StringConnection
	var query = replaceAll(queries.queryUpdateOpportunity + data, "rId", id);
	var stringConnection = stringConnections.strConnectionPipeline;
	var successfulUpdate = update(query, stringConnection, connection, command);
	
	if (successfulUpdate){
		alert("La oportunidad fue actualizada con exito en la base de datos. " + finalMessage + "Esta p�gina se actualizar�, presione el boton 'Aceptar' para continuar.");
	} else{
		alert("Ocurri� un error al intentar actualizar la oportunidad en la base de datos. " + finalMessage + "Esta p�gina se actualizar�, presione el boton 'Aceptar' para continuar.");
	}
	
	reloadPage();
}

// Update EstimatedDate
function updateEstimatedDateFromTable(selector){
	var year = $(".myYear").text();
	var stringMonth = $(".myMonth").text();
	var numericMonth = convertStringMonthToNumericMonth($(".myMonth").text());
	var newDate = year + "-" + numericMonth + "-15";
	var id = $(selector).parent().parent().parent().parent().parent().parent().attr("value");
	var query = replaceAll(replaceAll(queries.queryUpdateEstimatedDateOpportunity, "rId", id), "rDate", newDate);		
	var stringConnection = stringConnections.strConnectionPipeline;
	var successfullUpdate = update(query, stringConnection, connection, command);
	
	if (successfullUpdate){
		monthAux = stringMonth;
		yearAux = year;
		
		$(selector).parent().parent().parent().parent().parent().html(monthAux + " <a class='estimatedDateEditable' value='" + yearAux + "' title='Editar fecha'><i class='fa fa-edit'></i></a>")
	} else{
		alert("Ocurri� un error al intentar actualizar la fecha de cierre");
	}
}

// Update Estimated Probability
function updateEstimatedProbabilityFromTable(selector){
	var probability = $(".myProbabilityAux").text();
	probability= probability.substring(0,probability.length-1)
	var id = $(selector).parent().parent().parent().parent().parent().parent().attr("value");
	var query = replaceAll(replaceAll(queries.queryUpdateEstimatedProbabilityOpportunity, "rId", id), "rProbability", probability);
	var stringConnection = stringConnections.strConnectionPipeline;
	var successfullUpdate = update(query, stringConnection, connection, command);
	
	if (successfullUpdate){
				
		$(selector).parent().parent().parent().parent().parent().html(probability + "% <a class='estimatedProbabilityEditable' title='Editar probabilidad'><i class='fa fa-edit'></i></a>")
	} else{
		alert("Ocurri� un error al intentar actualizar la probabilidad de cierre");
	}
}