var myChart = undefined;

// Update graph
function updateGraph(){
	getGraphData();
	getGraphDetails();
	
	myChart.data.labels = labelsArray;
	myChart.data.datasets[0].data = utilityArray;
	myChart.data.datasets[1].data = amountUsdArray;
	myChart.update();
}

// Get Data for Graph and Details
function showGraphPanelContent(){
	$("#subgraph-one").removeClass("hide");
	$("#subgraph-two").removeClass("hide");
	$("#subgraph-three").removeClass("hide");
	$("#subgraph-start").addClass(" hide");
	
	getGraphData();
	createGraph();
	getGraphDetails();
	
	// Instance select editables Filter
	instanceEditableSelect("#statusOperationFilter");
}

// Create Graph
function createGraph(){
	var ctx = document.getElementById('chartPipeline').getContext('2d');
	
	myChart = new Chart(ctx, {
		type: 'line',
		data: {
			labels: labelsArray,
			datasets: [{
				label: 'Utilidad Esperada',
				data: utilityArray,
				backgroundColor: ['rgba(222, 239, 215, 0.5)'],
				borderColor: ['rgba(92, 183, 92, 1)'],
				borderWidth: 2,
				lineTension: 0
			},{
				label: 'Volumen Esperado',
				data: amountUsdArray,
				backgroundColor: ['rgba(216, 236, 246, 0.5)'],
				borderColor: ['rgba(51, 122, 182, 1)'],
				borderWidth: 2,
				lineTension: 0,
			}]
		},
		options: {
			scales: {
				yAxes: [{
					ticks: {beginAtZero:true},
					offset: true,
					display: false
				}],
				xAxes: [{
					ticks: {
						fontColor: "rgba(90, 64, 127, 1)",
						fontSize: 14,
						fontStyle: "bold"
					}
				}]
				
			},
			layout: {
				padding: {
					left: 70,
					right: 70,
				}
			},
			legend: {
				display: true,
				labels: {fontSize: 14}
			},
			title: {
				display: true,
				text: ["Flujo de Negocios Puntuales " + (new Date()).getFullYear(), "**No tiene en cuenta operaciones fallidas ni exitosas"],
				fontSize: 18
			},
			tooltips: {enabled: false},
			plugins: {
				datalabels: {
					anchor : 'end',
					align : 'top',
					color: function(context) {return compareString(context.dataset.label, "Utilidad") == 0 ? "#31708f" : "#3c763d"},
					backgroundColor: function(context) {return compareString(context.dataset.label, "Utilidad") == 0 ? "rgba(216, 236, 246, 0.6)" : "rgba(222, 239, 215, 0.6)"},
					borderRadius: 3,
					font : {
						size : "16",
						weight : "bold"
					},
					formatter : function(value, context) {
						return addCommas(value);
					}
				}
			}
		}
	});
}