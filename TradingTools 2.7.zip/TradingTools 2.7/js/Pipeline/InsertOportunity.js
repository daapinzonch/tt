// Validate if opportunity exist in DB & insert him
function insertOpportunity(data){
	var queryInsert = replaceAll(queries.queryInsertOpportunity, "rData", data);
	var queryValidateExist = queries.queryConsultOpportunityExist + dataForValidate;
	var stringConnection = stringConnections.strConnectionPipeline;
	
	// testInsert(queryInsert);
	
	if (!existInBD(connection, recordSet, queryValidateExist, stringConnection)){
		if (insert(queryInsert, stringConnection, connection)){
			
			if (contain(location.href, "???")){
				var ID = getLastId(queries.queryGetLastID, stringConnections.strConnectionPipeline);
				if(insert(replaceAll(replaceAll(replaceAll(queries.queryInsertOpportunityOnPET, 'R_NIT', getCleanValueForm("#nit", "Text", 0, "", [])), 'R_ID', ID),'R_ESTRATEGIA',getCleanValueForm("#operationStrategy", "Text", 0, "", [])), stringConnections.strConnectionPET, connection)){
					alert("Su oportunidad fue enlazada con el PET satisfactoriamente. " + finalMessage + "Esta p�gina se actualizar�, presione el boton 'Aceptar' para continuar.");
				}
			} 
			
			alert("Su oportunidad fue ingresada satisfactoriamente. " + finalMessage + "Esta p�gina se actualizar�, presione el boton 'Aceptar' para continuar.");
		
		} else{
			alert("Ocurri� un error al intentar insertar esta oportunidad en la base de datos. " + finalMessage + "Esta p�gina se actualizar�, presione el boton 'Aceptar' para continuar.");
		}
	} else{
		alert("Esta oportunidad no fue ingresada porque ya exist�a en la base de datos. " + finalMessage + "Esta p�gina se actualizar�, presione el boton 'Aceptar' para continuar.");
	}
	
	reloadPage();
}

// Show in console values before insert
function testInsert(query){
	console.log(query);
	query = query.substring(27, query.length);
	
	var queryArray = query.split(") VALUES(");
	var columns = queryArray[0].split(", ");
	var values = queryArray[1].split(", ");
	
	for (i = 0; i < columns.length; i++){console.log(columns[i] + ": " + values[i])}
}