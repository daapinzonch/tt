/**********************************************************************************/
/*************************************** DETAILS **********************************/
/**********************************************************************************/
// Get Big Details (CE, PMP & Coordinators) For Comex
function consultDetails(query){
	var stringConnection = stringConnections.strConnectionPipeline;
	var exist = false;
	var table = "<table class='tableBigDetails'><thead><tr><th></th><th>Negocios Registrados</th><th>Negocios Esperados</th><th>Monto Cartera</th><th>Monto Captaci�n</th><th>Monto Comisiones</th></tr></thead><tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			exist = true;
			table = table + "<tr>" + 
								"<td><b>" + recordSet(0).Value + "</b></td>" + 
								"<td class='a'>" + (compareString(recordSet(1).Value + "", "0") ? "" : recordSet(1).Value) + "</td>" + 
								"<td class='b'>" + (recordSet(2).Value == undefined || compareString(recordSet(2).Value + "", "0") ? "" : recordSet(2).Value) + "</td>" + 
								"<td class='c'>" + (recordSet(3).Value == undefined || compareString(recordSet(3).Value + "", "0") ? "" : addCommas(recordSet(3).Value)) + "</td>" + 
								"<td class='d'>" + (recordSet(4).Value == undefined || compareString(recordSet(4).Value + "", "0")? "" : addCommas(recordSet(4).Value)) + "</td>" + 
								"<td class='e'>" + (recordSet(5).Value == undefined || compareString(recordSet(5).Value + "", "0")? "" : addCommas(recordSet(5).Value)) + "</td>" + 
							"</tr>";
			
			recordSet.MoveNext();
		}
		
		table = table + "</tbody><tfoot><tr><th>Total</th><th class='sumA'></th><th class='sumB'></th><th class='sumC'></th><th class='sumD'></th><th class='sumE'></th></tr></tfoot></table>";
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return exist ? table : "";
}

// Get Big Details (Actives & Inactives) For Comex
function consultDetailsII(query, id){
	var stringConnection = stringConnections.strConnectionPipeline;
	var exist = false;
	var table = "<table class='tableBigDetails' id='" + id + "'><thead><tr><th>Producto</th><th>Negocios Registrados</th><th>Monto Cartera</th><th>Monto Captaci�n</th><th>Monto Comisiones</th></tr></thead><tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			exist = true;
			table = table + "<tr>" + 
								"<td><b>" + productItemsArray[productIds.indexOf(recordSet(0).Value + "")] + "</b></td>" + 
								"<td class='a'>" + (compareString(recordSet(1).Value + "", "0") ? "" : recordSet(1).Value) + "</td>" + 
								"<td class='b'>" + (recordSet(2).Value == undefined || compareString(recordSet(2).Value + "", "0") ? "" : addCommas(recordSet(2).Value)) + "</td>" + 
								"<td class='c'>" + (recordSet(3).Value == undefined || compareString(recordSet(3).Value + "", "0") ? "" : addCommas(recordSet(3).Value)) + "</td>" + 
								"<td class='d'>" + (recordSet(4).Value == undefined || compareString(recordSet(4).Value + "", "0")? "" : addCommas(recordSet(4).Value)) + "</td>" + 
							"</tr>";
			
			recordSet.MoveNext();
		}
		
		table = table + "</tbody><tfoot><tr><th>Total</th><th class='sumA'></th><th class='sumB'></th><th class='sumC'></th><th class='sumD'></th></tr></tfoot></table>";
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return exist ? table : "";
}

// Get Big Details For Trader (CE, PMP) By Segment
function consultDetailsT(query, tableName){
	var stringConnection = stringConnections.strConnectionPipeline;
	var exist = false;
	var table = "<div class='col-xs-12 col-md-6'>" + 
					"<table class='tableBigDetailsT'>" + 
						"<thead>" + 
							"<tr>" + 
								"<th colspan=4>" + tableName +"</th>" + 
							"</tr>" + 
							"<tr>" + 
								"<th><i class='fa fa-info-circle infoTooltip' data-toggle='tooltip' data-html='true' data-placement='right' title = 'Esta tabla muestra la cantidad y<br>el monto USD para las oportunidades<br>Abiertas, Fallidas y Exitosas seg�n el segmento.'></i></th>" + 
								"<th>Abiertas</th>" + 
								"<th>Fallidas</th>" + 
								"<th>Exitosas</th>" + 
							"</tr>" + 
						"</thead>" + 
						"<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			exist = true;
			table = table + "<tr>" + 
								"<td><b>" + recordSet(0) + "</b></td>" + 
								"<td>" + (compareString(recordSet(1) + "", "null") ? "" : (recordSet(1) + "").split(" | ")[0] + " | " + addCommas((recordSet(1) + "").split(" | ")[1])) + "</td>" + 
								"<td>" + (compareString(recordSet(2) + "", "null") ? "" : (recordSet(2) + "").split(" | ")[0] + " | " + addCommas((recordSet(2) + "").split(" | ")[1])) + "</td>" + 
								"<td>" + (compareString(recordSet(3) + "", "null") ? "" : (recordSet(3) + "").split(" | ")[0] + " | " + addCommas((recordSet(3) + "").split(" | ")[1])) + "</td>" + 
							"</tr>";
			
			recordSet.MoveNext();
		}
		
		table = table + "</tbody></table></div>";
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return exist ? table : "";
}

// Get Big Details For Trader II (Months-Trader)
function consultDetailsTII(query, tableName){
	var stringConnection = stringConnections.strConnectionPipeline;
	var exist = false;
	var table = "<div class='col-xs-12 col-md-6 scrollHorizontally'>" + 
					"<table class='tableBigDetailsT'>" + 
						"<thead>" + 
							"<tr>" + 
								"<th colspan=25>" + tableName + "</th>" + 
							"</tr>" + 
							"<tr>" + 
								"<th><i class='fa fa-info-circle infoTooltip infoTraders'></i></th>" + 
								"<th colspan=12>" + (new Date()).getFullYear() + "</th>" + 
								"<th colspan=12>" + ((new Date()).getFullYear() + 1) + "</th>" + 
							"</tr>" + 
							"<tr>" + 
								"<th></th>" + 
								"<th>Ene</th>" + 
								"<th>Feb</th>" + 
								"<th>Mar</th>" + 
								"<th>Abr</th>" + 
								"<th>May</th>" + 
								"<th>Jun</th>" + 
								"<th>Jul</th>" + 
								"<th>Ago</th>" + 
								"<th>Sep</th>" + 
								"<th>Oct</th>" + 
								"<th>Nov</th>" + 
								"<th>Dic</th>" + 
								"<th>Ene</th>" + 
								"<th>Feb</th>" + 
								"<th>Mar</th>" + 
								"<th>Abr</th>" + 
								"<th>May</th>" + 
								"<th>Jun</th>" + 
								"<th>Jul</th>" + 
								"<th>Ago</th>" + 
								"<th>Sep</th>" + 
								"<th>Oct</th>" + 
								"<th>Nov</th>" + 
								"<th>Dic</th>" + 
							"</tr>" + 
						"</thead>" + 
						"<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			exist = true;
			table = table + "<tr>" + 
								"<td><b>" + recordSet(0) + "</b></td>" + 
								"<td>" + (compareString(recordSet(1) + "", "0") ? "" : recordSet(1) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(2) + "", "0") ? "" : recordSet(2) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(3) + "", "0") ? "" : recordSet(3) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(4) + "", "0") ? "" : recordSet(4) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(5) + "", "0") ? "" : recordSet(5) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(6) + "", "0") ? "" : recordSet(6) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(7) + "", "0") ? "" : recordSet(7) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(8) + "", "0") ? "" : recordSet(8) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(9) + "", "0") ? "" : recordSet(9) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(10) + "", "0") ? "" : recordSet(10) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(11) + "", "0") ? "" : recordSet(11) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(12) + "", "0") ? "" : recordSet(12) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(13) + "", "0") ? "" : recordSet(13) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(14) + "", "0") ? "" : recordSet(14) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(15) + "", "0") ? "" : recordSet(15) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(16) + "", "0") ? "" : recordSet(16) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(17) + "", "0") ? "" : recordSet(17) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(18) + "", "0") ? "" : recordSet(18) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(19) + "", "0") ? "" : recordSet(19) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(20) + "", "0") ? "" : recordSet(20) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(21) + "", "0") ? "" : recordSet(21) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(22) + "", "0") ? "" : recordSet(22) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(23) + "", "0") ? "" : recordSet(23) + "") + "</td>" + 
								"<td>" + (compareString(recordSet(24) + "", "0") ? "" : recordSet(24) + "") + "</td>" + 
							"</tr>";
			
			recordSet.MoveNext();
		}
		
		table = table + "</tbody></table></div>";
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return exist ? table : "";
}

// Get details graph
function getGraphDetails(){
	var query = queries.queryConsultDetailsGraph;
	var stringConnection = stringConnections.strConnectionPipeline;
	
	var statusOperationCriterion = compareString(isInvalid($("#statusOperationFilter").val(), ""), "") ? " AND (EstadoOperaci�n IS NULL OR EstadoOperaci�n = '')" : " AND EstadoOperaci�n='" + $("#statusOperationFilter").val() + "'";
	var users = statusOperationCriterion + usersToShowMe;
	
	query = query + users;
	
	registeredBusinessDetail = 0;
	expectedBusinessDetail = 0;
	registeredVolumeDetail = 0;
	expectedVolumeDetail = 0;
	expectedUtilityDetail = 0;

	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		registeredBusinessDetail = compareString(addCommas(recordSet(0) + ""), "null") ? "" : recordSet(0) + "";
		expectedBusinessDetail = compareString(addCommas(recordSet(1) + ""), "null") ? "0" : addCommas(recordSet(1) + "");
		registeredVolumeDetail = compareString(addCommas(recordSet(2) + ""), "null") ? "0" : addCommas(recordSet(2) + "");
		expectedVolumeDetail = compareString(addCommas(recordSet(3) + ""), "null") ? "0" : addCommas(recordSet(3) + "");
		expectedUtilityDetail = compareString(addCommas(recordSet(4) + ""), "null") ? "0" : addCommas(recordSet(4) + "");
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	assignContent("#registeredBusiness", registeredBusinessDetail);
	assignContent("#expectedBusiness", expectedBusinessDetail);
	assignContent("#registeredVolume", registeredVolumeDetail);
	assignContent("#expectedVolume", expectedVolumeDetail);
	assignContent("#expectedUtilityDetail", expectedUtilityDetail);

	// Put, Change or Hide GraphDetails's Clarification
	validateClarificationGraphDetails();
	// Put, Change or Hide Graph's Clarification
	validateClarificationGraph();
}

/**********************************************************************************/
/**************************************** GRAPH ***********************************/
/**********************************************************************************/
// Get Graph Data
function getGraphData(){
	var statusOperationCriterion = compareString(isInvalid($("#statusOperationFilter").val(), ""), "") ? " AND (EstadoOperaci�n IS NULL OR EstadoOperaci�n = '')" : " AND EstadoOperaci�n='" + $("#statusOperationFilter").val() + "'";
	var users = statusOperationCriterion + usersToShowMe;
	var queryCriterion = users + " GROUP";
	var filterIsValid = false;
	
	var query = compareString($("#range").val(), "Mensual") ? queries.queryConsultDataGraph : compareString($("#range").val(), "Trimestral") ? queries.queryConsultDataGraphII : compareString($("#range").val(), "Semestral") ? queries.queryConsultDataGraphIII : queries.queryConsultDataGraph;
	var stringConnection = stringConnections.strConnectionPipeline; 
	
	query = replaceAll(query, "GROUP", queryCriterion);
	
	labelsArray = [];
	amountUsdArray = [];
	utilityArray = [];

	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (recordSet.EOF == false){
			filterIsValid = true;
			labelsArray.push(recordSet(0) + "");
			amountUsdArray.push(parseFloat(recordSet(1) + "").toFixed(2));
			utilityArray.push(parseFloat(recordSet(2) + "").toFixed(2));
			recordSet.MoveNext();
		}
		
		if (!filterIsValid){
			$("#modalErrorTitle").html("<b>Datos no encontrados</b>");$("#bodyModalError").html("No se encontraron datos.");$("#modalError").modal("show");
		}
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

/**********************************************************************************/
/********************************* SELECTS EDITABLES ******************************/
/**********************************************************************************/
// Get select items from DB
function consultSelectsContent(query, type, stringConnection){
	var items = [];
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
	
		while (recordSet.EOF == false){
			if (compareString(type, "Fecha")){
				items.push(recordSet(0) + "%&" + $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(1))));
			}else{
				items.push(recordSet(0) + "%&" + recordSet(1));
			}
			recordSet.MoveNext();
		}
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return items;
}

/**********************************************************************************/
/********************************* SELECTS EDITABLES II ***************************/
/**********************************************************************************/
// Get select items from DB
function consultSelectsContentII(query, stringConnection){
	var items = "";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
	
		while (recordSet.EOF == false){
			items = recordSet(0).Value;
			recordSet.MoveNext();
		}
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return items;
}

/**********************************************************************************/
/********************************* SELECTS EDITABLES II ***************************/
/**********************************************************************************/
// Get Last Opportunity Id
function getLastId(query, stringConnection){
	var id = "";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		id = recordSet(0).Value;
	} catch(e){
		alert("Ocurri� un error al intentar enlazar esta oportunidad con el PET" + e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return id;
}

/**********************************************************************************/
/********************************** GEOGRAPHIC INFO *******************************/
/**********************************************************************************/

// Consult NIT Geographic Information
function consultGeographicInfo(query, stringConnection, connection, recordSet, criterion){
	var geographicArray = [];
	var haveGeographic = false;
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
	
		while (recordSet.EOF == false){
			haveGeographic = true;
			
			coordinator = recordSet(0).Value;
			geographicArray = compareString(criterion, "large") ? [recordSet(1) + "", recordSet(2) + "", recordSet(3) + "", recordSet(4) + "", recordSet(5) + "", recordSet(6) + ""] : [recordSet(1) + "", recordSet(2) + "", recordSet(3) + "", recordSet(4) + ""];
			recordSet.MoveNext();
		}
		
		geographicArray = haveGeographic ? geographicArray : compareString(criterion, "large") ? ["", "", "", "", "", ""] : ["", "", "", ""];
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return geographicArray;
}

/**********************************************************************************/
/******************************** GET OPPORTUNITIES *******************************/
/**********************************************************************************/
// Get All Opportunities
function getOpportunities(usersToShowMe, statusToShowMe, timeToShowMe){
	var stringConnection = stringConnections.strConnectionPipeline;
	var tbody = "<tbody>";
	var tfoot = "<tfoot class='footerFilter'><tr>";
	
	if (compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT")){
		var query = replaceAll(queries.queryGetOpportunitiesT, "rOrigen", "Tesorer�a") + usersToShowMe + statusToShowMe + timeToShowMe;
		if(compareString(userType, "CoordinadorT")){
			query= query + "and Geografia.Segmento in ("+grupoCoordinador+")"
		}
		for (i = 0; i < 32; i++){tfoot = tfoot + "<td></td>"};
		
		try{
			connection.Open(stringConnection);
			recordSet.Open(query, connection);
			
			while (!recordSet.EOF){
				var id = recordSet(0) + "";
				var registrationDate = $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(1)));
				var year = (new Date(recordSet(2))).getFullYear();
				var month = convertNumericMonthToStringMonth((new Date(recordSet(2))).getMonth() + 1);
				var nit = recordSet(3) + "";
				var customer = recordSet(4) + "";
				var product = productItemsArray[productIds.indexOf(recordSet(5) + "")];
				var term = addCommas(recordSet(6));
				var duration = addCommas(recordSet(7));
				var position = compareString(recordSet(8) + "", "null") || compareString(recordSet(8) + "", "undefined") || compareString(recordSet(8) + "", "") ? "" : positionItemsArray[positionIds.indexOf(recordSet(8) + "")];
				var originalAmount = addCommas(parseFloat(recordSet(9)).toFixed(2));
				var usdAmount = addCommas(parseFloat(recordSet(10)).toFixed(2));
				var utility = addCommas(parseFloat(recordSet(11)).toFixed(2));
				var expectedUtility = addCommas(parseFloat(recordSet(12)).toFixed(2));
				var probability = recordSet(13) + "%";
				var consumedQuota = compareString(recordSet(14) + "", "") || compareString(recordSet(14) + "", "null") ? "" : addCommas(parseFloat(recordSet(14)).toFixed(2));
				var rr = compareString(recordSet(15) + "", "") || compareString(recordSet(15) + "", "null") ? "" : addCommas(parseFloat(recordSet(15)).toFixed(3));
				var trader = compareString(recordSet(16) + "", "null") ? "" : recordSet(16) + "";
				var currency = compareString(recordSet(17) + "", "null") ? "" : currencyItemsArray[currencyIds.indexOf(recordSet(17) + "")];
				var rate = addCommas(parseFloat(recordSet(18)).toFixed(2));
	/*Nestor*/	var statusOperation = (compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")) ? "Cerrada" : "Abierta";
	/*Nestor*/	var status = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida") ? recordSet(19) + "" : statusItemsArray[statusIds.indexOf(recordSet(19) + "")];
				var observations = compareString(recordSet(20) + "", "null") ? "" : recordSet(20);
				var pendingBank = compareString(recordSet(21) + "", "null") ? "" : pendingBankItemsArray[pendingBankIds.indexOf(recordSet(21) + "")];
				var pendingCustomer = compareString(recordSet(22) + "", "null") ? "" : pendingCustomerItemsArray[pendingCustomerIds.indexOf(recordSet(22) + "")];
				var coordinator = compareString(recordSet(23) + "", "null") ? "" : recordSet(23) + "";
				var bank = compareString(recordSet(24) + "", "null") ? "" : recordSet(24) + "";
				var segment = compareString(recordSet(25) + "", "null") ? "" : recordSet(25) + "";
				var region = compareString(recordSet(26) + "", "null") ? "" : recordSet(26) + "";
				var operationStrategy = compareString(recordSet(27) + "", "null") ? "" : operationStrategyItemsArray[operationStrategyIds.indexOf(recordSet(27) + "")];
				var ReferredBy = compareString(recordSet(28) + "", "null") ? "" : referredByItemsArray[referredByIds.indexOf(recordSet(28) + "")];
				var unit = compareString(recordSet(29) + "", "null") ? "" : recordSet(29) + "";
				var closeDate = recordSet(30) == undefined || compareString(recordSet(30) + "", "null") || compareString(recordSet(30) + "", "NULL") ? "" : $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(30)));
				
	/*Nestor*/	var rowClass = compareString(recordSet(19) + "", "Oper. Exitosa") ? "operationSuccess" : (compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")? "operationFailed" : "");
	/*Nestor*/	var editButtonClass = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida") ? "hide" : "";
	/*Nestor*/	var editableDateClass = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")? "estimatedDateEditableDismiss" : "estimatedDateEditable";
				var editableProbabilityClass = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")? "estimatedProbabilityEditableDismiss" : "estimatedProbabilityEditable";
// /*Nestor*/	var reuseOpportunity = (invalidItemsArray.indexOf(recordSet(19) + "") != -1) ? "hide" : "";
				var reuseOpportunity = "";
				//Se deshabilita la funci�n 'Reutilizar', para habilitarla de nuevo hay que asignarle el valor "" a la variable 'reuseOpportunity'
				tbody = tbody + "<tr value='" + id + "' class='" + rowClass + "'><td><a title='Editar Oportunidad' class='openEditOpportunityForm " + editButtonClass + "'>Editar</a><br><a title='Reutilizar Oportunidad' class='openReuseOpportunityForm " + reuseOpportunity + "' >Reutilizar</a></td><td>" + registrationDate + "</td><td>" + month + " <a class='" + editableDateClass + "' value='" + year + "' title='Editar fecha'><i class='fa fa-edit'></i></a></td><td>" + closeDate + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + product + "</td><td>" + term + "</td><td>" + duration + "</td><td>" + position + "</td><td>" + originalAmount + "</td><td>" + currency + "</td><td>" + usdAmount + "</td><td>" + utility + "</td><td>" + expectedUtility + "</td><td>" + probability + " <a class='" + editableProbabilityClass + "' title='Editar probabilidad'><i class='fa fa-edit'></i></a></td><td>" + consumedQuota + "</td><td>" + rr + "</td><td>" + trader + "</td><td>" + rate + "</td><td>" + statusOperation + "</td><td>" + status + "</td><td>" + operationStrategy + "</td><td>" + ReferredBy + "</td><td>" + observations + "</td><td>" + pendingBank + "</td><td>" + pendingCustomer + "</td><td>" + unit + "</td><td>" + coordinator + "</td><td>" + bank + "</td><td>" + segment + "</td><td>" + region + "</td></tr>";
				
				recordSet.MoveNext();
			}
		} 
		catch(e){alert("Ocurri� un error al intentar consultar la base de datos (" + e.message + ")")}
		finally{recordSet.Close();connection.Close()}
		
		return tbody + "</tbody>" + tfoot + "</tr></tfoot>";
	} else if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){
		var query = replaceAll(queries.queryGetOpportunitiesI, "rOrigen", "Internacional") + usersToShowMe + statusToShowMe + timeToShowMe;
		
		for (i = 0; i < 20; i++){tfoot = tfoot + "<td></td>"};
		
		try{
			connection.Open(stringConnection);
			recordSet.Open(query, connection);
			
			while (!recordSet.EOF){
				var id = recordSet(0) + "";
				var registrationDate = $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(1)));
				var year = (new Date(recordSet(2))).getFullYear();
				var month = convertNumericMonthToStringMonth((new Date(recordSet(2))).getMonth() + 1);
				var nit = recordSet(3) + "";
				var customer = recordSet(4) + "";
				var productSubproduct = replaceAll(productItemsArray[productIds.indexOf((recordSet(5) + "").substring(0,2))] + (recordSet(5) + "").substring(2,3) + concatArrays(subProductItemsArray, subProductItemsArray2)[concatArrays(subProductIds, subProductIds2).indexOf((recordSet(5) + "").substring(3,4))] + (recordSet(5) + "").substring(4,5), "undefined", "");
				var term = addCommas(recordSet(6));
				var vehicle = compareString(recordSet(7) + "", "null") ? "" : vehicleItemsArray[vehicleIds.indexOf(recordSet(7) + "")];
				var usdAmount = compareString(recordSet(8) + "", "") ? "" : addCommas(parseFloat(recordSet(8)).toFixed(2));
				var COPingress = compareString(recordSet(9) + "", "") ? "" : addCommas(parseFloat(recordSet(9)).toFixed(2));
				var probability = recordSet(10) + "%";
	/*Nestor*/	var statusOperation = (compareString(recordSet(11) + "", "Oper. Exitosa") || compareString(recordSet(11) + "", "Oper. Fallida") || compareString(recordSet(11) + "", "Oper. Invalida")) ? "Cerrada" : "Abierta";
	/*Nestor*/	var status = compareString(recordSet(11) + "", "Oper. Exitosa") || compareString(recordSet(11) + "", "Oper. Fallida") || compareString(recordSet(11) + "", "Oper. Invalida") ? recordSet(11) + "" : concatArrays(["", "", "", "", ""], statusItemsArray)[concatArrays(["", "", "", "", ""], statusIds).indexOf(recordSet(11) + "")];
				var observations = compareString(recordSet(12) + "", "null") ? "" : recordSet(12) + "";
				var coordinator = compareString(recordSet(13) + "", "null") ? "" : recordSet(13) + "";
				var consultant = compareString(recordSet(14) + "", "null") ? "" : recordSet(14) + "";
				var bank = compareString(recordSet(15) + "", "null") ? "" : recordSet(15) + "";
				var segment = compareString(recordSet(16) + "", "null") ? "" : recordSet(16) + "";
				var region = compareString(recordSet(17) + "", "null") ? "" : recordSet(17) + "";
				var closeDate = recordSet(18) == undefined || compareString(recordSet(18) + "", "null") || compareString(recordSet(18) + "", "NULL") ? "" : $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(18)));
				
	/*Nestor*/	var rowClass = compareString(recordSet(11) + "", "Oper. Exitosa") ? "operationSuccess" : ((compareString(recordSet(11) + "", "Oper. Fallida") || compareString(recordSet(11) + "", "Oper. Invalida")) ? "operationFailed" : "");
	/*Nestor*/	var editButtonClass = compareString(recordSet(11) + "", "Oper. Exitosa") || compareString(recordSet(11) + "", "Oper. Fallida") || compareString(recordSet(11) + "", "Oper. Invalida")? "hide" : "";
	/*Nestor*/	var editableDateClass = compareString(recordSet(11) + "", "Oper. Exitosa") || compareString(recordSet(11) + "", "Oper. Fallida") || compareString(recordSet(11) + "", "Oper. Invalida") ? "estimatedDateEditableDismiss" : "estimatedDateEditable";
				var editableProbabilityClass = compareString(recordSet(11) + "", "Oper. Exitosa") || compareString(recordSet(11) + "", "Oper. Fallida") || compareString(recordSet(11) + "", "Oper. Invalida") ? "estimatedProbabilityEditableDismiss" : "estimatedProbabilityEditable";
				//Se deshabilita la funci�n 'Reutilizar', para habilitarla de nuevo hay que asignarle el valor "" a la variable 'reuseOpportunity'
	// /*Nestor*/	var reuseOpportunity = (invalidItemsArray.indexOf(recordSet(11) + "") != -1) ? "hide" : "";
				var reuseOpportunity = "";
				
				tbody = tbody + "<tr value='" + id + "' class='" + rowClass + "'><td><a title='Editar Oportunidad' class='openEditOpportunityForm " + editButtonClass + "'>Editar</a><br><a value='" + id + "' title='Reutilizar Oportunidad' class='openReuseOpportunityForm " + reuseOpportunity + "' >Reutilizar</a></td><td>" + registrationDate + "</td><td>" + month + " <a class='" + editableDateClass + "' value='" + year + "' title='Editar fecha'><i class='fa fa-edit'></i></a></td><td>" + closeDate + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + productSubproduct + "</td><td>" + term + "</td><td>" + vehicle + "</td><td>" + usdAmount + "</td><td>" + COPingress + "</td><td>" + probability + " <a class='" + editableProbabilityClass + "' title='Editar probabilidad'><i class='fa fa-edit'></i></a></td><td>" + statusOperation + "</td><td>" + status + "</td><td>" + observations + "</td><td>" + coordinator + "</td><td>" + consultant + "</td><td>" + bank + "</td><td>" + segment + "</td><td>" + region + "</td></tr>";
				
				recordSet.MoveNext();
			}
		} 
		catch(e){alert("Ocurri� un error al intentar consultar la base de datos (" + e.message + ")")}
		finally{recordSet.Close();connection.Close()}
		
		return tbody + "</tbody>" + tfoot + "</tr></tfoot>";
	} else{
		var query = queries.queryGetOpportunitiesA + usersToShowMe + statusToShowMe + timeToShowMe;
		for (i = 0; i < 39; i++){tfoot = tfoot + "<td></td>"};
		
		try{
			connection.Open(stringConnection);
			recordSet.Open(query, connection);
			
			while (!recordSet.EOF){
				var id = recordSet(0) + "";
				var registrationDate = $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(1)));
				var year = (new Date(recordSet(2))).getFullYear();
				var month = convertNumericMonthToStringMonth((new Date(recordSet(2))).getMonth() + 1);
				var nit = recordSet(3) + "";
				var customer = recordSet(4) + "";
				var productSubproduct = recordSet(5) + "";
				var originalAmount = compareString(recordSet(6) + "", "") || compareString(recordSet(6) + "", "null") ? "" : addCommas(parseFloat(recordSet(6)).toFixed(2));
				var usdAmount = compareString(recordSet(7) + "", "") ? "" : addCommas(parseFloat(recordSet(7)).toFixed(2));
				var COPingress = compareString(recordSet(8) + "", "") ? "" : addCommas(parseFloat(recordSet(8)).toFixed(2));
				var estimatedUtility = compareString(recordSet(9) + "", "") || compareString(recordSet(9) + "", "null") ? "" : addCommas(parseFloat(recordSet(9)).toFixed(2));
				var expectedUtility = compareString(recordSet(10) + "", "") || compareString(recordSet(10) + "", "null") ? "" : addCommas(parseFloat(recordSet(10)).toFixed(2));
				var consumedQuota = compareString(recordSet(11) + "", "") || compareString(recordSet(11) + "", "null") ? "" : addCommas(parseFloat(recordSet(11)).toFixed(2));
				var rr = compareString(recordSet(12) + "", "") || compareString(recordSet(12) + "", "null") ? "" : addCommas(parseFloat(recordSet(12)).toFixed(3));
				var position = compareString(recordSet(13) + "", "null") ? "" : recordSet(13) + "";
				var vehicle = compareString(recordSet(14) + "", "null") ? "" : recordSet(14) + "";
				var currency = compareString(recordSet(15) + "", "null") ? "" : recordSet(15) + "";
				var rate = compareString(recordSet(16) + "", "") || compareString(recordSet(16) + "", "null") ? "" : addCommas(parseFloat(recordSet(16)).toFixed(2));
				var term = addCommas(recordSet(17));
				var duration = addCommas(recordSet(18));
	/*Nestor*/	var statusOperation = (compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")) ? "Cerrada" : "Abierta";
				var status = compareString(recordSet(19) + "", "null") ? "" : recordSet(19) + "";
				var probability = recordSet(20) + "%";
				var observations = compareString(recordSet(21) + "", "null") ? "" : recordSet(21);
				var reason = compareString(recordSet(22) + "", "null") ? "" : recordSet(22) + "";
				var unit = recordSet(23) + "";
				var coordinatorI = compareString(recordSet(24) + "", "null") ? "" : recordSet(24) + "";
				var consultant = compareString(recordSet(25) + "", "null") ? "" : recordSet(25) + "";
				var coordinatorT = compareString(recordSet(26) + "", "null") ? "" : recordSet(26) + "";
				var trader = compareString(recordSet(27) + "", "null") ? "" : recordSet(27) + "";
				var bank = compareString(recordSet(28) + "", "null") ? "" : recordSet(28) + "";
				var segment = compareString(recordSet(29) + "", "null") ? "" : recordSet(29) + "";
				var region = compareString(recordSet(30) + "", "null") ? "" : recordSet(30) + "";
				var referredBy = compareString(recordSet(31) + "", "null") ? "" : recordSet(31) + "";
				var pendingBank = compareString(recordSet(32) + "", "null") ? "" : recordSet(32) + "";
				var pendingCustomer = compareString(recordSet(33) + "", "null") ? "" : recordSet(33) + "";
				var operationStrategy = compareString(recordSet(34) + "", "null") ? "" : recordSet(34) + "";
				var uploadBy = recordSet(35) + "";
				var origin = recordSet(36) + "";
				var closeDate = recordSet(37) == undefined || compareString(recordSet(37) + "", "null") || compareString(recordSet(37) + "", "NULL") ? "" : $.datepicker.formatDate('yy/mm/dd', new Date(recordSet(37)));
				
				
	/*Nestor*/	var rowClass = compareString(recordSet(19) + "", "Oper. Exitosa") ? "operationSuccess" : ((compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")) ? "operationFailed" : "");
	/*Nestor*/	var editButtonClass = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida")? "hide" : "";
	/*Nestor*/	var editableDateClass = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida") ? "estimatedDateEditableDismiss" : "estimatedDateEditable";
				var editableProbabilityClass = compareString(recordSet(19) + "", "Oper. Exitosa") || compareString(recordSet(19) + "", "Oper. Fallida") || compareString(recordSet(19) + "", "Oper. Invalida") ? "estimatedProbabilityEditableDismiss" : "estimatedProbabilityEditable";
				//Se deshabilita la funci�n 'Reutilizar', para habilitarla de nuevo hay que asignarle el valor "" a la variable 'reuseOpportunity'
// /*Nestor*/	var reuseOpportunity = (invalidItemsArray.indexOf(recordSet(11) + "") != -1) ? "hide" : "";
				var reuseOpportunity = "";
				
				tbody = tbody + "<tr value='" + id + "' class='" + rowClass + "'><td><a title='Editar Oportunidad' class='openEditOpportunityForm " + editButtonClass + "'>Editar</a><br><a value='" + id + "' title='Reutilizar Oportunidad' class='openReuseOpportunityForm " + reuseOpportunity + "' >Reutilizar</a></td><td>" + registrationDate + "</td><td>" + month + " <a class='" + editableDateClass + "' value='" + year + "' title='Editar fecha'><i class='fa fa-edit'></i></a></td><td>" + closeDate + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + productSubproduct + "</td><td>" + originalAmount + "</td><td>" + usdAmount + "</td><td>" + COPingress + "</td><td>" + estimatedUtility + "</td><td>" + expectedUtility + "</td><td>" + consumedQuota + "</td><td>" + rr + "</td><td>" + position + "</td><td>" + vehicle + "</td><td>" + currency + "</td><td>" + rate + "</td><td>" + term + "</td><td>" + duration + "</td><td>" + statusOperation + "</td><td>" + status + "</td><td>" + probability + " <a class='" + editableProbabilityClass + "' title='Editar probabilidad'><i class='fa fa-edit'></i></a></td><td>" + observations + "</td><td>" + reason + "</td><td>" + unit + "</td><td>" + coordinatorI + "</td><td>" + consultant + "</td><td>" + coordinatorT + "</td><td>" + trader + "</td><td>" + bank + "</td><td>" + segment + "</td><td>" + region + "</td><td>" + referredBy + "</td><td>" + pendingBank + "</td><td>" + pendingCustomer + "</td><td>" + operationStrategy + "</td><td>" + uploadBy + "</td><td>" + origin + "</td></tr>";
				
				recordSet.MoveNext();
			}
		} 
		catch(e){alert("Ocurri� un error al intentar consultar la base de datos (" + e.message + ")")}
		finally{recordSet.Close();connection.Close()}
		
		return tbody + "</tbody>" + tfoot + "</tr></tfoot>";
	}
}

/**********************************************************************************/
/************************************* FOR EDIT ***********************************/
/**********************************************************************************/
function putInfoGeographicForEdit(){
	//var query = replaceAll(queries.queryGeographyInfo, "rNit", $("#nit").val());
	var query = replaceAll(queries.queryGeographyInfo, "c.NIT = 'rNit'", "c.Unidad = '" + $("#unit").val() + "'");
	query = compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? replaceAll(replaceAll(query, "Trader", "Consultor"), "Facilitador", "Coordinador") : query;
	
	var stringConnection = stringConnections.strConexionDataMart;
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		coordinator = recordSet(0).Value;
		assignValue("#trader", recordSet(1));assignValue("#bank", recordSet(3));assignValue("#segment", recordSet(4));assignValue("#region", recordSet(5));assignValue("#priorization", recordSet(6));
	} catch(e){alert("Error obteniendo datos II: " + e.message);
	} finally{recordSet.Close();connection.Close();}
}

function putDataOpportunityForEdit(id){
	var query = replaceAll(queries.queryGetFullOpportunities, "rId", id);
	var stringConnection = stringConnections.strConnectionPipeline;
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);	
		
		var estimatedDate = compareString(recordSet(0) + "", "null") ? "" : $.datepicker.formatDate('dd/mm/yy', new Date(recordSet(0)));
		var nit = compareString(recordSet(1) + "", "null") ? "" : recordSet(1);
		var customer = compareString(recordSet(2) + "", "null") ? "" : recordSet(2);
		var product = compareString(recordSet(3) + "", "null") ? "" : productItemsArray[productIds.indexOf(recordSet(3) + "")];
		var subProduct = compareString(recordSet(4) + "", "null") ? "" : concatArrays(subProductItemsArray, subProductItemsArray2)[concatArrays(subProductIds, subProductIds2).indexOf(recordSet(4) + "")];
		var position = compareString(recordSet(5) + "", "null") ? "" : positionItemsArray[positionIds.indexOf(recordSet(5) + "")] == undefined ? "" : positionItemsArray[positionIds.indexOf(recordSet(5) + "")];
		var currency = compareString(recordSet(6) + "", "null") ? "" : currencyItemsArray[currencyIds.indexOf(recordSet(6) + "")];
		var rate = compareString(recordSet(7) + "", "null") ? "" : addCommas(recordSet(7));
		var originalAmount = compareString(recordSet(8) + "", "null") ? "" : addCommas(recordSet(8));
		var usdAmount = compareString(recordSet(9) + "", "null") ? "" : addCommas(recordSet(9));
		var copIngress = compareString(recordSet(10) + "", "null") ? "" : addCommas(recordSet(10));
		var term = compareString(recordSet(11) + "", "null") ? "" : addCommas(recordSet(11));
		var vehicle = compareString(recordSet(12) + "", "null") ? "" : vehicleItemsArray[vehicleIds.indexOf(recordSet(12) + "")];
		var duration = compareString(recordSet(13) + "", "null") ? "1" : addCommas(recordSet(13));
		var operationStrategy = compareString(recordSet(14) + "", "null") ? "" : operationStrategyItemsArray[operationStrategyIds.indexOf(recordSet(14) + "")];
		var estimatedUtility = compareString(recordSet(15) + "", "null") ? "" : addCommas(recordSet(15));
		var expectedUtility = compareString(recordSet(16) + "", "null") ? "" : addCommas(recordSet(16));
		var consumedQuota = compareString(recordSet(17) + "", "null") ? "" : addCommas(recordSet(17));
		var rr = compareString(recordSet(18) + "", "null") ? "" : addCommas(recordSet(18));
		var unit = compareString(recordSet(19) + "", "null") ? "" : recordSet(19);
		var referredBy = compareString(recordSet(20) + "", "null") ? "" : referredByItemsArray[referredByIds.indexOf(recordSet(20) + "")];
		var status = compareString(recordSet(21) + "", "null") ? "" : statusItemsArray[statusIds.indexOf(recordSet(21) + "")];
		var pendingBank = compareString(recordSet(22) + "", "null") ? "" : pendingBankItemsArray[pendingBankIds.indexOf(recordSet(22) + "")];
		var pendingCustomer = compareString(recordSet(23) + "", "null") ? "" : pendingCustomerItemsArray[pendingCustomerIds.indexOf(recordSet(23) + "")];
		var probability = compareString(recordSet(24) + "", "null") ? "" : recordSet(24) + "";
		var statusOperation = compareString(recordSet(25) + "", "null") ? "" : recordSet(25);
		var reason = compareString(recordSet(28) + "", "null") ? "" : reasonItemsArray[reasonIds.indexOf(recordSet(28) + "")];
		var invalidReason = compareString(recordSet(29) + "", "null") ? "" : invalidItemsArray[invalidIds.indexOf(recordSet(29) + "")];
		var observations = compareString(recordSet(27) + "", "null") ? "" : recordSet(27);
		var origin = compareString(recordSet(26) + "", "null") ? "" : recordSet(26);
		var subProductInput = recordSet(3) == 17 ? "#subProduct2" : recordSet(3) == 18 ? "#subProduct" : "";
		
		// Muestra en la consola lo que trae para poner en el formulario
		// console.log("estimatedDate: " + estimatedDate);console.log("nit: " + nit);console.log("customer: " + customer);console.log("product: " + product);console.log("subProduct: " + subProduct);console.log("position: " + position);console.log("currency: " + currency);console.log("rate: " + rate);console.log("originalAmount: " + originalAmount);console.log("usdAmount: " + usdAmount);console.log("copIngress: " + copIngress);console.log("term: " + term);console.log("vehicle: " + vehicle);console.log("duration: " + duration);console.log("operationStrategy: " + operationStrategy);console.log("estimatedUtility: " + estimatedUtility);console.log("expectedUtility: " + expectedUtility);console.log("consumedQuota: " + consumedQuota);console.log("rr: " + rr);console.log("unit: " + unit);console.log("referredBy: " + referredBy);console.log("status: " + status);console.log("pendingBank: " + pendingBank);console.log("pendingCustomer: " + pendingCustomer);console.log("probability: " + probability);console.log("statusOperation: " + statusOperation);console.log("reason: " + reason);console.log("observations: " + observations);console.log("origin: " + origin);
		
		changeProperty("#nit", "disabled", true);
		changeProperty("#customer", "disabled", true);
		changeProperty("#unit", "disabled", true);
		addClass("#searchCoincidencesButton", " hide");
		addClass("#restartButton", " hide");
		
		assignValue("#estimatedDate", estimatedDate);
		assignValue("#nit", nit);
		assignValue("#customer", customer);
		assignValue("#product", product);
		validateProductSelected();
		assignValue("#unit", unit);
		assignValue("#referredBy", referredBy);
		updateProgressBar(probability + "%");
		assignValue("#status", status);
		validateStatusSelected();
		assignValue("#observations", observations);
		if (compareString(statusOperation + "", "Oper. Exitosa")){$("#successRadioLabel").click();} 
		else if (compareString(statusOperation + "", "Oper. Fallida")){$("#failedRadioLabel").click();}
		else if (compareString(statusOperation + "", "Oper. Fallida")){$("#failedRadioLabel").click();}
		else if (invalidItemsArray.indexOf(statusOperation + "") != -1){$("#invalidRadioLabel").click();}//Nestor
		assignValue("#invalid", invalidReason);//Nestor
		assignValue("#reason", reason);
		
		if (compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT") || compareString(userType, "Administrador")){
			assignValue("#position", position);
			assignValue("#currency", currency);
			assignValue("#usdAmount", usdAmount);
			assignValue("#term", term);
			assignValue("#originalAmount", originalAmount);
			validateCurrencySelected();
			assignValue("#rate", rate);
			assignValue("#duration", duration);
			assignValue("#operationStrategy", operationStrategy);
			assignValue("#estimatedUtility", estimatedUtility);
			assignValue("#expectedUtility", expectedUtility);
			assignValue("#consumedQuota", consumedQuota);
			assignValue("#rr", rr);
			assignValue("#pendingBank", pendingBank);
			assignValue("#pendingCustomer", pendingCustomer);
		} else if (compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI")){
			assignValue(subProductInput, subProduct);
			if (compareString(subProductInput, "#subProduct2")) validateSubproduct2Selected();
			assignValue("#rate", rate);
			assignValue("#usdAmount", usdAmount);
			assignValue("#term", term);
			assignValue("#copIngress", copIngress);
			assignValue("#vehicle", vehicle);
		} 
		
	} catch(e){alert("Error poniendo datos en el formulario: " + e.message);
	} finally{recordSet.Close();connection.Close();}
}



