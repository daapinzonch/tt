// Select Items
var productItems = "";
var subProductItems = "";
var subProductItems2 = "";
var positionItems = "";
var currencyItems = "";
var vehicleItems = "";
var operationStrategyItems = "";
var operationStrategyCriteria = "";
var referredByItems = "";
var statusItems = "";
var pendingBankItems = "";
var pendingCustomerItems = "";
var reasonItems = "";
// Select Items In Array
var productItemsArray = [];
var subProductItemsArray = [];
var subProductItemsArray2 = [];
var positionItemsArray = [];
var currencyItemsArray = [];
var vehicleItemsArray = [];
var operationStrategyItemsArray = [];
var referredByItemsArray = [];
var statusItemsArray = [];
var pendingBankItemsArray = [];
var pendingCustomerItemsArray = [];
var reasonItemsArray = [];
// Select Options Ids
var productIds = [];
var subProductIds = [];
var subProductIds2 = [];
var positionIds = [];
var currencyIds = [];
var vehicleIds = [];
var operationStrategyIds = [];
var bankIds = [];
var referredByIds = [];
var statusIds = [];
var pendingBankIds = [];
var pendingCustomerIds = [];
var reasonIds = [];

// Get Ids & Items Selects
function getSelectsContent(){
	var criterion = compareString(userType, "TraderT") || compareString(userType, "GerencialT") || compareString(userType, "CoordinadorT") ? " WHERE Destino = 'Tesorer�a'" : compareString(userType, "ConsultorI") || compareString(userType, "GerencialI") || compareString(userType, "CoordinadorI") ? " WHERE Destino = 'Internacional'" : "";
	
	var products = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Producto"), "rTable", "TipoProducto " + criterion), "", stringConnections.strConnectionPipeline);
	var subProducts = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "SubProducto"), "rTable", "TipoSubProducto WHERE Producto = 'Comisi�n'"), "", stringConnections.strConnectionPipeline);
	var subProducts2 = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "SubProducto"), "rTable", "TipoSubProducto WHERE Producto = 'Captaci�n'"), "", stringConnections.strConnectionPipeline);
	var positions = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Posici�n"), "rTable", "TipoPosici�n"), "", stringConnections.strConnectionPipeline);
	var currencies = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Moneda"), "rTable", "TipoMoneda"), "", stringConnections.strConnectionPipeline);
	var vehicles = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Vehiculo"), "rTable", "TipoVehiculo"), "", stringConnections.strConnectionPipeline);
	var strategies = contain(location.href, "???") ? location.href.split("???")[1].split(" ") : consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Estrategia"), "rTable", "TipoEstrategia"), "");
	var referreds = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "ReferidoPor"), "rTable", "TipoReferidoPor"), "", stringConnections.strConnectionPipeline);
	var statuses = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Estado"), "rTable", "TipoEstado " + criterion), "", stringConnections.strConnectionPipeline);
	var pendingBanks = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "PendienteBanco"), "rTable", "TipoPendienteBanco"), "", stringConnections.strConnectionPipeline);
	var pendingCustomers = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "PendienteCliente"), "rTable", "TipoPendienteCliente"), "", stringConnections.strConnectionPipeline);
	var reasons = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "Motivo"), "rTable", "TipoMotivo " + criterion), "", stringConnections.strConnectionPipeline);
	var invalid = consultSelectsContent(replaceAll(replaceAll(queries.queryItemsSelects, "rCol", "RazonInvalida"), "rTable", "TipoInvalida "), "", stringConnections.strConnectionPipeline);//Nestor
	
	productItems = getItems(products);
	subProductItems = getItems(subProducts);
	subProductItems2 = getItems(subProducts2);
	positionItems = getItems(positions);
	currencyItems = getItems(currencies);
	vehicleItems = getItems(vehicles);

	if (contain(location.href, "???")){
		operationStrategyItems = "";
		strategies.forEach(function(e){operationStrategyItems = operationStrategyItems + "<option>" + e + "</option>"});		
	} else {
		operationStrategyItems = getItems(strategies);
	}
	
	referredByItems = getItems(referreds);
	statusItems = getItems(statuses);
	pendingBankItems = getItems(pendingBanks);
	pendingCustomerItems = getItems(pendingCustomers);
	reasonItems = getItems(reasons);
	invalidItems = getItems(invalid);//Nestor
	
	productItemsArray = getItemsArray(products);
	subProductItemsArray = getItemsArray(subProducts);
	subProductItemsArray2 = getItemsArray(subProducts2);
	positionItemsArray = getItemsArray(positions);
	currencyItemsArray = getItemsArray(currencies);
	vehicleItemsArray = getItemsArray(vehicles);
	
	if (contain(location.href, "???")){
		operationStrategyItemsArray = strategies
	} else {
		operationStrategyItemsArray = getItemsArray(strategies);
	}

	referredByItemsArray = getItemsArray(referreds);
	statusItemsArray = getItemsArray(statuses);
	pendingBankItemsArray = getItemsArray(pendingBanks);
	pendingCustomerItemsArray = getItemsArray(pendingCustomers);
	reasonItemsArray = getItemsArray(reasons);
	invalidItemsArray = getItemsArray(invalid);//Nestor
	
	productIds = getIds(products);
	subProductIds = getIds(subProducts);
	subProductIds2 = getIds(subProducts2);
	positionIds = getIds(positions);
	currencyIds = getIds(currencies);
	vehicleIds = getIds(vehicles);
	
	if (contain(location.href, "???")){
		operationStrategyIds = [];
		strategies.forEach(function(e){
			operationStrategyCriteria = " IN('" + e + "'";
			var qry = replaceAll(replaceAll(queries.queryItemsSelects, ", rCol", ""), "rTable", "TipoEstrategia WHERE Estrategia " + operationStrategyCriteria + ")");
			operationStrategyIds.push(
				consultSelectsContentII(qry, stringConnections.strConnectionPipeline) + ""
			);
		});
	} else {
		operationStrategyIds = getIds(strategies);
	}

	referredByIds = getIds(referreds);
	statusIds = getIds(statuses);
	pendingBankIds = getIds(pendingBanks);
	pendingCustomerIds = getIds(pendingCustomers);
	reasonIds = getIds(reasons);
	invalidIds = getIds(invalid);//Nestor
}


// Get Ids Selects In Array
function getIds(arrayItemsIds){
	var ids = [];
	for (var i = 0; i < arrayItemsIds.length; i++){ids.push(arrayItemsIds[i].split("%&")[0]);}
	return ids;
}

// Get Items Selects In String
function getItems(arrayItemsIds){
	var items = "";
	for (var i = 0; i < arrayItemsIds.length; i++){items = items + "<option>" + arrayItemsIds[i].split("%&")[1] + "</option>";}
	return items;
}

// get Items Selectes In Array
function getItemsArray(arrayItemsIds){
	var items = [];
	for (var i = 0; i < arrayItemsIds.length; i++){items.push(arrayItemsIds[i].split("%&")[1]);}
	return items;
}