// Crea una instancia de Outlook
function abrirOutlook(clientesArray){
	var query = queries.consultaOrdenesDePagoPorCliente;
	var queryII = queries.consultaTotalesMonedaPorCliente;
	var stringConnection = stringConnections.strConexionDataMart;
	var encabezados = headers.encabezadosTablaOrdenesCorreo;
	var tablaOrdenes = "<table border=1 style='text-align: center; border-collapse: collapse; padding: 8px; font-size: 14px'>";
	var network = new ActiveXObject('WScript.Network');
	var serverName = network.computerName.toUpperCase();
	
	for (l = 0; l < clientesArray.length; l++){
		tablaOrdenes = tablaOrdenes + obtenerTablaOrdenesDePago(query, queryII, stringConnection, clientesArray[l], encabezados);
	}
	
	tablaOrdenes = tablaOrdenes + "</table>";

	try {
		if (compareString(serverName, "ARIESTES02") || compareString(serverName, "ARIESTES01") || compareString(serverName, "XENAPP40") || compareString(serverName, "WIN2012P02.banbta.net") || compareString(serverName, "WIN2012P02") || compareString(serverName, "win2012p02")){
			var cdoMsg = new ActiveXObject("CDO.Message");
			
			cdoMsg.From = "Internacional@bancodebogota.com.co";
			cdoMsg.To = users.currentUser + "@bancodebogota.com.co";
			cdoMsg.Subject = "�rdenes de Pago Pendientes - Banco de Bogot�";
			cdoMsg.HTMLBody = "<span style='font-family: arial'>Estimado cliente,<br><br>A continuaci�n listamos las �rdenes de pago pendientes por reintegro.</span><br><br>" + tablaOrdenes + "<br><br><span style='font-family: arial'>Por favor comun�quese con nosotros para la negociaci�n de la operaci�n. En caso de ya haber negociado estas �rdenes de pago, por favor hacer caso omiso de este correo.</span>";

			var namespace = "http://schemas.microsoft.com/cdo/configuration/";
			cdoMsg.Configuration.Fields.Item(namespace + "sendusing") = 2;
			cdoMsg.Configuration.Fields.Item(namespace + "smtpserver") = "outlook.bancodebogota.net";
			cdoMsg.Configuration.Fields.Item(namespace + "smtpserverport") = 25;
			cdoMsg.Configuration.Fields.Item(namespace + "sendusername") = "Internacional@bancodebogota.com.co";
			cdoMsg.Configuration.Fields.Update();
			
			cdoMsg.Send();
			//cdoMsg = undefined;
			
			$("#contenidoModalInformacion").html("Un correo ha sido enviado a " + users.currentUser + "@bancodebogota.com.co.");
			$("#tituloModalInformacion").html("<b>Env�o satisfactorio</b>");
			$('#modalInformacion').modal('show');
		} else{
			// Crea y abre una instancia de Outlook
			var outlook = new ActiveXObject('Outlook.Application');
			// Abre una nueva ventana de correo
			var email = outlook.CreateItem(0);
			// Agrega Destinatarios
			email.Recipients.Add(users.currentUser).Type = 1;
			// Asunto
			email.Subject = '�rdenes de Pago Pendientes - Banco de Bogot�';
			// Muestra el contenido del correo
			email.Display();
			// Coloca contenido en el correo
			email.HTMLBody = "<span style='font-family: arial'>Estimado cliente,<br><br>A continuaci�n listamos las �rdenes de pago pendientes por reintegro.</span><br><br>" + tablaOrdenes + "<br><br><span style='font-family: arial'>Por favor comun�quese con nosotros para la negociaci�n de la operaci�n. En caso de ya haber negociado estas �rdenes de pago, por favor hacer caso omiso de este correo.</span>" + email.HTMLBody;
		}
	} catch(e) {
		alert(e.message);
		$('#tituloModalError').html('<b>Error</b>');
		$('#contenidoModalError').html('Ocurri� un error al intentar el env�o.');
		$('#modalError').modal('show');
	}
}

function obtenerTablaOrdenesDePago(query, queryII, stringConnection, cliente, encabezados){
	var tablaCorreo = "";
									
	query = replaceAll(query, "rCliente", cliente);
	tablaCorreo = "<thead><tr style='background: #337ab7; color: #fff; font-size: 17px'><th colspan=6>" + cliente + " - rNitCliente</th></tr><tr style='background: #f5f5f5'>";
	
	for(i = 0; i < encabezados.length; i++){
		tablaCorreo = tablaCorreo + "<th>" + encabezados[i] + "</th>";
	}
	
	tablaCorreo = tablaCorreo + "</tr></thead><tbody>";
	
	try{
		conexion.Open(stringConnection);
		recordSet.Open(query, conexion);
		
		while (recordSet.EOF == false){
			var fecha = new Date(recordSet(1));
			nitClienteCorreo = recordSet(2).Value;
			
			tablaCorreo = tablaCorreo + "<tr><td>" + recordSet(0).Value + "</td><td>"	+ fecha.getDate() + " " + convertNumericMonthToStringMonth(fecha.getMonth() + 1) + " " + fecha.getFullYear() + "</td><td>" + recordSet(4).Value + "</td><td>" +	addCommas(recordSet(6).Value) + "</td><td>" + recordSet(5).Value + "</td><td>" + recordSet(7).Value + "</td></tr>";
			recordSet.MoveNext();
		}
		
		recordSet.Close();
		conexion.Close();
	} catch(e){alert("Ocurri� un error al intentar consultar las �rdenes de pago (" + e.message + ")")}
	
	queryII = replaceAll(queryII, "rNit", nitClienteCorreo);
	tablaCorreo = tablaCorreo + "</tbody><tfoot><tr style='background: #ddd; font-size: 17px; text-align: center'><th colspan=6>";
	
	try{
		conexion.Open(stringConnection);
		recordSet.Open(queryII, conexion);
		var count = 0;
		
		while (recordSet.EOF == false){
			count++;
			tablaCorreo = (count == 1) ? tablaCorreo + recordSet(0) + ": " + addCommas(recordSet(1)) : tablaCorreo + "<br>" + recordSet(0) + ": " + addCommas(recordSet(1));
			recordSet.MoveNext();
		}
		
		recordSet.Close();
		conexion.Close();
	} catch(e){alert("Ocurri� un error al intentar consultar los totales (" + alert(e.message) + "")}
	
	return replaceAll(tablaCorreo, "rNitCliente", nitClienteCorreo) + "</th></tr></tfoot>";
}

function reiniciarClientes(envioVarios){
	if (envioVarios){
		myDataTable.search("").draw();
	
		$("#tablaResultados").DataTable().page.len(-1).draw();
		$("#tablaResultados .linkEnviarOrdenActivada").addClass(" linkEnviarOrdenDesactivada").removeClass(" linkEnviarOrdenActivada");
		$("#tablaResultados").DataTable().page.len(7).draw();
	} else{
		$("#tablaResultados .linkEnviarOrdenActivada").addClass(" linkEnviarOrdenDesactivada").removeClass(" linkEnviarOrdenActivada");
	}
	
	clientes = [];
	clientesUnicos = [];
	
	$("input[type='search']").val("");
	
	addClass(".enviarSeleccionadas", " desactivado");
}