// Consulta contactos sin nit
var consultaContactosArr = (queries.consultaContactos).split("numeroNit");

// Consulta los contactos de un cliente y los muestra
function traerContactos(nit){
	$("#contenidoModalInformacion").empty();
	$("#contenidoModalError").empty();
	$('#panelModalInformacion').removeClass(' panel-success');
	$("#panelModalInformacion").addClass(' panel-info');
	
	var entroCiclo = false;
	var consultaContactos = consultaContactosArr[0] + "'" + nit + "'" + consultaContactosArr[1];
 	
	conexion.Open(stringConnections.strConexionContactos);
	recordSet.Open(consultaContactos, conexion);
	var i =0;
	while (recordSet.EOF == false){
		i = i + 1;
		var numContacto = i + "";
		var nombre = recordSet(0).Value + "";
		var cargo = recordSet(1).Value + "";
		var celular = recordSet(2).Value + "";
		var telefono = recordSet(3).Value + "";
		var email = recordSet(4).Value + "";
		
		numContacto = validarString(numContacto, "");
		nombre = validarString(nombre, "No se encontr� nombre del contacto");
		cargo = validarString(cargo, "No se encontr� cargo de este contacto");
		telefono = validarString(telefono, "No se encontr� telefono de este contacto");
		celular = validarString(celular, "No se encontr� celular de este contacto");
		email = validarString(email, "No se encontr� email de este contacto");
		
		if (cargo.localeCompare("No se encontr� cargo de este contacto") != 0){
			cargo = (recordSet(1).Value).toLowerCase() + "";
		}
	
		var contacto = "<div class='panel panel-default'>" +
						"<div class='panel-body'>" +
							"<span class='numContacto'>Contacto No." + numContacto + "</span>" + 
							"<br>" + 
							"<span class='nombreContacto'>" + nombre + "</span>" + 
							"<br>" + 
							"<span class='cargoContacto'>" + cargo + "</span>" +
							"<br>" + 
							"<span class='telContacto'>" + telefono + "</span>" + 
							"<br>" + 
							"<span class='celContacto'>" + celular + "</span>" + 
							"<br>" + 
							"<span class='emailContacto'>" + email + "</span>" + 
						"</div>" +
					"</div>";
		
		$("#contenidoModalInformacion").append(contacto);
		
		recordSet.MoveNext();
		
		entroCiclo = true;
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	if(entroCiclo == false){
		$('#tituloModalError').html('Sin contactos');
		$('#contenidoModalError').html('No se encontr� ning�n contacto para este cliente.');
		$('#modalError').modal('show');
	}else{
		$("#tituloModalInformacion").html("Contactos del cliente <b>" + traerCliente(nit).cliente + "</b>");
		$('#modalInformacion').modal('show');
	}
}