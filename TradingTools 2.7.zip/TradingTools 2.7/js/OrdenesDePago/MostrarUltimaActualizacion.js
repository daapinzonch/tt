// Mostrar �ltima fecha y hora en que se actualiz�
function mostrarActualizacion(){
	var archivoUltimaActualizacion = objetoDeArchivos.GetFile(files.rutaArchivoUltimaActualizacion);
	var ultimaActualizacion = new Date(archivoUltimaActualizacion.DateLastModified);
	var ultimaActualizacionFormateada = $.datepicker.formatDate('yy-mm-dd', ultimaActualizacion);
	var mensajeUltimaActualizacion = "Ultima actualizaci�n: " + ultimaActualizacionFormateada + " ";
	
	if(ultimaActualizacion.getHours() < 10){
		mensajeUltimaActualizacion = mensajeUltimaActualizacion + "0" + ultimaActualizacion.getHours() + ":";
	} else{
		mensajeUltimaActualizacion = mensajeUltimaActualizacion + ultimaActualizacion.getHours() + ":";
	}
	
	if(ultimaActualizacion.getMinutes() < 10){
		mensajeUltimaActualizacion = mensajeUltimaActualizacion + "0" + ultimaActualizacion.getMinutes();
	} else{
		mensajeUltimaActualizacion = mensajeUltimaActualizacion + ultimaActualizacion.getMinutes();
	}
	
	$('#ultimaActualizacion').html("<b id='ultActualizacion'>" + mensajeUltimaActualizacion + "</b>");
}