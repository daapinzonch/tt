//Esta funcion de encarga de pintar los datos del cliente una vez son traidos
function pintarLabels(nit, evento){
	var cliente = traerCliente(nit);
	
	$("#labelCliente").html("");
	$("#labelUnidad").html("");
	$("#labelBanca").html("");
	$("#labelSegmento").html("");
	$("#labelRegion").html("");
	$("#labelTrader").html("");
	$("#labeldetalle").html("");
	
	if(cliente == "" && evento != null){
		$("#labelCliente").html($(evento.target).closest("tr").find('td:eq(6)').text());
		$("#labelUnidad").html($(evento.target).closest("tr").find('td:eq(3)').text());
		$("#labelBanca").html($(evento.target).closest("tr").find('td:eq(12)').text());
		$("#labelSegmento").html($(evento.target).closest("tr").find('td:eq(13)').text());
		$("#labelRegion").html($(evento.target).closest("tr").find('td:eq(14)').text());
		$("#labelTrader").html($(evento.target).closest("tr").find('td:eq(2)').text());
		//var detalle = traerDetalles($(evento.target).closest("tr").find('td:eq(5)').text());
		var detalle = traerDetalles(nit);
		alert(detalle);
		if(detalle == "LOC_BANK"){
			$("#labeldetalle").html("<h2 style='color:red'>"+detalle+"</h2>");
		}else{
			$("#labeldetalle").html(detalle);
		}
	}else{
		$("#labelCliente").html(cliente.cliente);
		$("#labelUnidad").html(cliente.unidad);
		$("#labelBanca").html(cliente.banca);
		$("#labelSegmento").html(cliente.segmento);
		$("#labelRegion").html(cliente.region);
		$("#labelTrader").html(cliente.trader);
		// var detalle = traerDetalles($(evento.target).closest("tr").find('td:eq(5)').text());
		var detalle = traerDetalles(nit);
		if(detalle == "LOC_BANK"){
			$("#labeldetalle").html("<h2 style='color:red'>"+detalle+"</h2>");
		}else{
			$("#labeldetalle").html(detalle);
		}
		clienteMostrado = cliente.cliente;
	}
}
function traerDetalles(nit){
	var consultaDetalle = queries.consultarDetallesNit + "'" + nit + "';";
	conexion.Open(stringConnections.strConexionDataMart); 
	recordSet.Open(consultaDetalle, conexion);
	var detalle = "";
	if(recordSet.EOF == true){
		detalle = "No aplica (Validar)";
	}else{
		detalle = recordSet(0).value+"";
	}
	recordSet.Close(); 
	conexion.Close();
	return detalle;
}
function traerCliente(nit){
	var consultaCliente = queries.consultaDetalleCliente + "'" + nit + "'";
	
	conexion.Open(stringConnections.strConexionDataMart); 
	recordSet.Open(consultaCliente, conexion);

	var cliente = {};
	
	while (recordSet.EOF == false){		
		cliente.nit = recordSet("Nit").Value;
		cliente.cliente= recordSet("Nombre").Value;
		cliente.unidad= recordSet("Unidad").Value;
		cliente.banca= recordSet("Banca").Value;
		cliente.segmento= recordSet("Segmento").Value;
		cliente.region= recordSet("Region").Value;
		cliente.trader= recordSet("Trader").Value;
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	return cliente;
}

function validarNull(valor){
	if (valor.localeCompare('') == 0 || valor.localeCompare(' ') == 0 || valor.localeCompare(undefined) == 0){
		return "No encontrado.";
	}
	
	return valor;
}