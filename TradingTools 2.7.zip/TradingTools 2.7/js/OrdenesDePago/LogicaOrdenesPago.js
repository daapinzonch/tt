// Objetos ActiveX
var conexion = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
var objetoDeArchivos = new ActiveXObject("Scripting.FileSystemObject");
var net = new ActiveXObject("WScript.Network");
// User type
var userType = "";
// Datos tabla
var datosTablaCompletos = "";
var myDataTable = null;
// Nit clickeado
var nNit = "";
// Cliente mostrado
var clienteMostrado = "";
// Variables usadas para enviar correo de �rdenes de pago
var nitClienteCorreo = "";
var clientes = [];
var clientesUnicos = [];

/***********************************************************/
/********************** START LOGIC ************************/
/***********************************************************/
showMessageLoading("tituloNotificacion", "cuerpoNotificacion");
showLoadingOverlay();
$(document).ready(function() {
	// Put current version
	assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), objetoDeArchivos));
	// Configura graficas que mostrar�n los Spreads
	Chart.defaults.global.legend.display = false;
	Chart.defaults.global.defaultFontSize = 11;
	// Get User Rol
	userType = getUserType(conexion, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
	// Show connected user
	showUserConnected("#connected-user");
	// Show modules for user
	showModules(userType);
	// Inserta log cada vez que el usuario ingrese a la p�gina
	insertLog(conexion, "Spread y Ordenes de Pago WEB");
	// Consulta datos para cargar en la tabla
	construirTabla(headers.encabezadosTablaOrdenes);
	// Muestra la tabla con todos sus datos
	instanciarTabla();
	// Add Horizontally Scroll on datatable
	putScrollOnTable("#tablaResultados");
	// Oculta el mensaje de inicio
	$("#loading").addClass(' hide');
	// Mostrar �ltima fecha y hora en que se actualiz� "Reporte_Orpa_Trading.txt"
	mostrarActualizacion();
	
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});
	
	$("#divTablaOrdenes").removeClass(" hide");
	
	$("#tablaResultados").on('click', 'tr td:not(:last-child)', function(e){
		obtenerNit(e);
	});
	
	// Obtiene el valor buscado luego de presionar enter y verifica que sea un n�mero
	$('div.dataTables_filter input').keyup( function (e) {
		obtenerNitBuscado(e);
	});
	
	// Muestra contactos del cliente
	$("#btnModalContacto").on('click',function(){
		traerContactos(nNit);
	});
	
	// Muestra InfoCupos del cliente
	$("#btnModalInfoCupos").on('click',function(){
		consultarInfoCupos(nNit, clienteMostrado);
	});
	
	$('#tablaResultados').on('click', '.enviarActual', function (e){
		abrirOutlook([$(e.target).closest("tr").find('td:eq(6)').text()]);
		reiniciarClientes(false);
	});
	
	$('#tablaResultados').on('click', '.enviarSeleccionadas', function (e){
		if ($(this).hasClass("desactivado")){
			e.preventDefault();
		} else{
			clientesUnicos = [];
			deleteDuplicates(clientes, clientesUnicos);
			abrirOutlook(clientesUnicos);
			reiniciarClientes(true);
		}
	});
	
	$('#tablaResultados').on('click', '.seleccionar', function (e){
		$(this).parent().parent().parent().parent().removeClass("linkEnviarOrdenDesactivada");
		$(this).parent().parent().parent().parent().addClass("linkEnviarOrdenActivada");
		clientes.push($(e.target).closest("tr").find('td:eq(6)').text());
		removeClass(".enviarSeleccionadas", " desactivado");
	});
	
	$('#tablaResultados').on('click', '.deseleccionar', function (e){
		$(this).parent().parent().parent().parent().removeClass("linkEnviarOrdenActivada");
		$(this).parent().parent().parent().parent().addClass("linkEnviarOrdenDesactivada");
		clientes = removeArrayElement(clientes, $(e.target).closest("tr").find('td:eq(6)').text());
		if (clientes.length == 0){
			addClass(".enviarSeleccionadas", " desactivado");
		}
	});
	
	hideLoadingOverlay();
});

// Crea e instancia la tabla
function instanciarTabla(){
	// $('#tablaResultados tfoot td').each(function (){$(this).html('<input class="secondFilter" type="text" placeholder="Buscar"/>')});
	
	myDataTable = $('#tablaResultados').DataTable({
		"lengthMenu": [[7, 15, 30, -1], [7, 15, 30, "Todos"]],
		"footerCallback": function (row, data, start, end, display) {
			var api = this.api(), data;
			var currencyArray = [];
			var amountArray = [];
			var usdSum = 0;var eurSum = 0;var copSum = 0;var jpySum = 0;var gbpSum = 0;var cadSum = 0;var chfSum = 0;
			var totales = "";
			
			api.column(8, {page: 'current'}).data().reduce(function (a, b){currencyArray.push(b)}, 0);
			api.column(9, {page: 'current'}).data().reduce(function (a, b){amountArray.push(replaceAll(b, ",", ""))}, 0);
			
			currencyArray.forEach(function(a, b){
				if (compareString(a, "USD")){usdSum = usdSum + parseFloat(amountArray[b])} 
				else if (compareString(a, "EUR")){eurSum = eurSum + parseFloat(amountArray[b])} 
				else if (compareString(a, "COP")){copSum = copSum + parseFloat(amountArray[b])} 
				else if (compareString(a, "JPY")){jpySum = jpySum + parseFloat(amountArray[b])} 
				else if (compareString(a, "GBP")){gbpSum = gbpSum + parseFloat(amountArray[b])} 
				else if (compareString(a, "CAD")){cadSum = cadSum + parseFloat(amountArray[b])} 
				else if (compareString(a, "CHF")){chfSum = chfSum + parseFloat(amountArray[b])}
			});

			// Actualiza la fila de totales
            $('#totalValor').html(usdSum == 0 ? "" : "USD: " + agregarComas((usdSum).toFixed(2))); 
			$('#totalValor').append(eurSum == 0 ? "" : "<br>EUR: " + agregarComas((eurSum).toFixed(2)));
			$('#totalValor').append(copSum == 0 ? "" : "<br>COP: " + agregarComas((copSum).toFixed(2)));
			$('#totalValor').append(jpySum == 0 ? "" : "<br>JPY: " + agregarComas((jpySum).toFixed(2)));
			$('#totalValor').append(gbpSum == 0 ? "" : "<br>GBP: " + agregarComas((gbpSum).toFixed(2)));
			$('#totalValor').append(cadSum == 0 ? "" : "<br>CAD: " + agregarComas((cadSum).toFixed(2)));
			$('#totalValor').append(chfSum == 0 ? "" : "<br>CHF: " + agregarComas((chfSum).toFixed(2)));
        }
	});
	
	// myDataTable.columns().eq(0).each(function (index){
		// $('input', myDataTable.column(index).footer()).on('keyup change focusout', function (){
			// myDataTable.column(index) .search( this.value ) .draw();
			// validateSecondFilter($(this));
		// });
	// });
}

// Almacena el nit que se ingreso para buscar y verifica que sea un n�mero
function obtenerNitBuscado(e){
	$("#contenidoModalError").empty();

	if (e.keyCode == 13) {
		nNit = $('.dataTables_filter input').val().trim();
		
		if (isFinite(String(nNit)) && nNit != ""){
			consultarSpreads(nNit, e);
		} else{
			$('#tituloModalError').html('Nit inv�lido');
			$('#contenidoModalError').html('El nit ingresado es inv�lido, verifique que este correcto y vuelva a intentarlo.');
			$('#modalError').modal('show');
		}
	}
}

// Obtiene el nit de la fila clickeada
function obtenerNit(evento){
	var nit = $(evento.target).closest("tr").find('td:eq(5)').text();
	
	nNit = nit.trim();
	
	if (nNit != ''){
		consultarSpreads(nit.trim(), evento);
	}
}

// Pinta Spread seg�n el nit
function consultarSpreads(nit, evento){
	pintarSpreads(nit);
	pintarLabels(nit, evento);
}

// Verifica si una cadena es "" o " " o "null" o "NULL" y la reemplaza por otra
function validarString(cadena, reemplazo){
	if (cadena.localeCompare("") == 0 || cadena.localeCompare(" ") == 0 || cadena.localeCompare("null") == 0 || cadena.localeCompare("NULL") == 0 || cadena.localeCompare(null) == 0){
		cadena = reemplazo;
	} else{
		cadena = cadena;
	}
	
	return cadena;
}