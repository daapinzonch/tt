// Arreglos de meses para convertir de numero a texto
var mesesNum = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
var mesesComp = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];

// Consulta infoCupos de un cliente en especifico
function consultarInfoCupos(nit, clienteMostrado){
	$("#contenidoModalInformacion").empty();
	$("#contenidoModalError").empty();
	
	var consulta = queries.consultaInfoCupos + nit + "'";
	var entroCiclo = false;
 	
	conexion.Open(stringConnections.strConexionDataMart);
	recordSet.Open(consulta, conexion);
	
	while (recordSet.EOF == false){
		var cupo = recordSet("cupo").Value + "";
		var utilizado = recordSet("utilizado").Value + "";
		var disponible = recordSet("disponible").Value + "";
		var plazoMaximo = recordSet("plazo_max").Value + "";
		var fechaVencimiento = recordSet("fecha_vencimiento").Value + "";
		var fechaActual = new Date();
		var vencido = false;
		
		cupo = validarString(cupo, "No se encontr� cupo de este cliente");
		utilizado = validarString(utilizado, "No se encontr� cupo utilizado por este cliente");
		disponible = validarString(disponible, "No se encontr� cupo disponible para este cliente");
		plazoMaximo = validarString(plazoMaximo, "No se encontr� el plazo m�ximo del cupo de este cliente");
		fechaVencimiento = validarString(fechaVencimiento, "No se encontr� la fecha de vencimiento de cupo para este cliente");
		
		cupo = formatearInfocupo(cupo);
		utilizado = formatearInfocupo(utilizado);
		disponible = formatearInfocupo(disponible);
		plazoMaximo = formatearInfocupo(plazoMaximo);
		
		cupo = agregarComas(cupo);
		utilizado = agregarComas(utilizado);
		disponible = agregarComas(disponible);
		plazoMaximo = agregarComas(plazoMaximo);
		
		if (fechaVencimiento.localeCompare("No se encontr� la fecha de vencimiento de cupo para este cliente") != 0){
			fechaVencimiento = new Date(fechaVencimiento);
			
			if (fechaVencimiento < fechaActual){
				vencido = true;
			}
			
			fechaVencimiento = $.datepicker.formatDate('dd-mm-yy', fechaVencimiento);
			
			fechaVencimiento = convertirMesALetras(fechaVencimiento);
		}
		
		if (vencido){
			var infoCupos = cargarInfoCupos(clienteMostrado, "vencido", "Vencido", cupo, utilizado, disponible, plazoMaximo, fechaVencimiento, fechaActual);
			$('#tituloModalError').html('InfoCupos (miles COP)');
			$('#contenidoModalError').html(infoCupos);
			$('#modalError').modal('show');
		} else{
			var infoCupos = cargarInfoCupos(clienteMostrado, "noVencido", "Vigente", cupo, utilizado, disponible, plazoMaximo, fechaVencimiento, fechaActual);
			$('#panelModalInformacion').removeClass(' panel-info');
			$("#panelModalInformacion").addClass(' panel-success');
			$("#contenidoModalInformacion").html(infoCupos);
			$("#tituloModalInformacion").html("InfoCupos (miles COP)");
			$('#modalInformacion').modal('show');
		}
		
		recordSet.MoveNext();
		
		entroCiclo = true;
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	if(entroCiclo == false){
		$('#tituloModalError').html('Sin informaci�n InfoCupos');
		$('#contenidoModalError').html('No se encontr� informaci�n de InfoCupos para este cliente.');
		$('#modalError').modal('show');
	}
}

// formatea valores de InfoCupos
function formatearInfocupo(valor){
	if ((valor.substring(0, 13)).localeCompare("No se encontr�") != 0){
		valor = Math.round(valor);
	}
	
	return valor;
}

// Agrega comas de miles a un n�mero
function agregarComas(valor){
	valor = valor + '';
	
	var x = valor.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	
	while (rgx.test(x1)) {
			x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	
	return x1 + x2;
}

// Carga los datos consultados de infocupos en el modal
function cargarInfoCupos(clienteMostrado, estado, estadoMensaje, cupo, utilizado, disponible, plazoMaximo, fechaVencimiento, fechaActual){
	var infoCupos = "<div class='detallesInfoCupos " + estado + "'><b>Cliente: </b><span class='infoCupo'>" + clienteMostrado + "</span></div>" + 
						"<br>" +
						"<div class='detallesInfoCupos " + estado + "'><b>Cupo del grupo: </b><span class='infoCupo'>" + cupo + "</span></div>" + 
						"<br>" +
						"<div class='detallesInfoCupos " + estado + "'><b>Cupo utilizado: </b><span class='infoCupo'>" + utilizado + "</span></div>" + 
						"<br>" +
						"<div class='detallesInfoCupos " + estado + "'><b>Cupo disponible: </b><span class='infoCupo'>" + disponible + "</span></div>" + 
						"<br>" +
						"<div class='detallesInfoCupos " + estado + "'><b>Plazo m�ximo: </b><span class='infoCupo'>" + plazoMaximo + "</span></div>" + 
						"<br>" +
						"<div class='detallesInfoCupos " + estado + "'><b>Fecha vencimiento: </b><span class='infoCupo'>" + fechaVencimiento + "</span></div>" + 
						"<div id='" + estado + "'>" + estadoMensaje + 
					"</div>";
						
	return infoCupos;
}

// Convierte un mes n�merico a un mes en letra (Ej. 01 -> Ene)
function convertirMesALetras(fecha){
	var diaFechaActual = fecha.substring(0, 2);
	var a�oFechaActual = fecha.substring(6, fecha.length);
	
	for (i = 0; i < mesesNum.length; i++){
		if (fecha.substring(3, 5).localeCompare(mesesNum[i]) == 0){
			fecha = diaFechaActual + " " + mesesComp[i] + " " + a�oFechaActual;
		}
	}
	
	return fecha;
}