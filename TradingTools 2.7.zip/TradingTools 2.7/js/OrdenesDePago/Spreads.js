// Graficas
var graficaFwd = null;
var graficaSpot = null;
var graficaSpotInter = null;
var graficaMoneda = null;
var graficaMonedaInter = null;
var graficaOpciones = null;
var graficaSwap = null;
// Valores graficas
var valoresFwd = [];
var valoresSpot = [];
var valoresSpotInternet = [];
var valoresMoneda = [];
var valoresMonedaInt = [];
var valoresOpciones = [];
var valoresSwap = [];
// Canvas donde esta cada grafica
var canvas;
// A�os a consultar
var currentTime = new Date();
var a�oActual = currentTime.getFullYear();
var a�oPasado = currentTime.getFullYear() - 1;
var a�oAntepasado = currentTime.getFullYear() - 2;
// Arreglo A�os a consultar
var a�os = [a�oAntepasado, a�oPasado, a�oActual];

// Almacena los valores de todas las graficas a pintar y las pinta
function pintarSpreads(nit){
	reiniciarValoresGraficas();
	
	conexion.Open(stringConnections.strConexionDataMart);
	recordSet.Open(queries.consultaSpreads + nit + "'", conexion);
			
	while (recordSet.EOF == false){
		var product = recordSet("producto").Value;
				
		switch (product){
			case 'FWD':
				almacenarValoresGrafica(a�os, recordSet, valoresFwd, null);
				break;
			
			case 'SPOT':
				almacenarValoresGrafica(a�os, recordSet, valoresSpot, valoresSpotInternet);
				break;
			
			case 'MONEDAS':
				almacenarValoresGrafica(a�os, recordSet, valoresMoneda, valoresMonedaInt);
				break;
			
			case 'OPCIONES':
				almacenarValoresGrafica(a�os, recordSet, valoresOpciones, null);
				break;
					
			case 'SWAP':
				almacenarValoresGrafica(a�os, recordSet, valoresSwap, null);
				break;		   
		}
		
		recordSet.MoveNext();
	}
			
	recordSet.Close(); 
	conexion.Close();
	
	eliminarGraficas();
	mostrarOcultarGraficas(nit);
}

// Reinicia los arreglos que contienen los valores de las graficas
function reiniciarValoresGraficas(){
	valoresFwd = [];
	valoresSpot = [];
	valoresSpotInternet = [];
	valoresMoneda = [];
	valoresMonedaInt = [];
	valoresOpciones = [];
	valoresSwap = [];
}

// Almacena valores de cada grafica dependiendo del a�o
function almacenarValoresGrafica(a�os, recordSet, valoresGraficaNoInternet, valoresGraficaInternet){
	for (i = 0; i < a�os.length; i++){
		if (recordSet("a�o") == a�os[i]){
			if (recordSet("internet") == "Internet"){
				valoresGraficaInternet[i] = recordSet("pl").Value;
			} else if (recordSet("internet") == "No Internet"){
				valoresGraficaNoInternet[i] = recordSet("pl").Value;
			}
		}
	}
}

// Elimina las graficas que esten mostradas para que no se sobreescriban
function eliminarGraficas(){
	var graficas = [graficaFwd, graficaSpot, graficaSpotInter, graficaMoneda, graficaMonedaInter, graficaOpciones, graficaSwap];
	
	for (i = 0; i < graficas.length; i++){
		if (graficas[i] != null){
			graficas[i].destroy();
		}
	}
}

function mostrarOcultarGraficas(nit){
	// Crea las graficas dandonle sus respectivos valores
	graficaFwd = crearGrafica("fwd", graficaFwd, valoresFwd, "FWD Sprd (COP/USD)");
	graficaSpot = crearGrafica("spot", graficaSpot, valoresSpot, "Spot Sprd (COP/USD)");
	graficaMoneda = crearGrafica("moneda", graficaMoneda, valoresMoneda, "Monedas Sprd (COP/USD)");
	graficaOpciones = crearGrafica("opciones", graficaOpciones, valoresOpciones, "Opciones Sprd (COP/USD)");
	graficaSpotInter = crearGrafica("spotInter", graficaSpotInter, valoresSpotInternet, "Spot Internet Sprd (COP/USD)");
	graficaSwap = crearGrafica("Swap", graficaSwap, valoresSwap, "Swap Sprd (COP/USD)");
	graficaMonedaInter = crearGrafica("monedaInter", graficaMonedaInter, valoresMonedaInt, "Monedas Internet Sprd");
				
	$("#labelNit").html(nit);
	
	// Mostrar u ocultar una grafica dependiendo si tiene o no datos
	comprobarGrafica(valoresSpot, 'grafica1');
	comprobarGrafica(valoresMoneda, 'grafica2');
	comprobarGrafica(valoresFwd, 'grafica3');
	comprobarGrafica(valoresOpciones, 'grafica4');
	comprobarGrafica(valoresSwap, 'grafica5');
	comprobarGrafica(valoresSpotInternet, 'grafica6');
	comprobarGrafica(valoresMonedaInt, 'grafica7');
	
	// Si ninguna grafica tiene datos, ocultar labels y bot�n de contactos
	// if ((valoresFwd.length == 0) && (valoresSpot.length == 0) && (valoresMoneda.length == 0) && (valoresOpciones.length == 0) && (valoresSpotInternet.length == 0) && (valoresSwap.length == 0) && (valoresMonedaInt.length == 0)){
		// $('#tituloModalError').html('Sin informaci�n del cliente');
		// $('#contenidoModalError').html('No se encontr� informaci�n del cliente.');
		// $('#modalError').modal('show');		
		
		// ocultarDetalles();
	// } else{
		mostrarDetalles();
	// }
}

// Crea una grafica especifica dandole sus valores y su t�tulo
function crearGrafica(idCanvas, grafica, valoresGrafica, tituloGrafica){
	var canvas = document.getElementById(idCanvas);
	
	canvas.style.backgroundColor = 'rgba(0,0,0,0)';
	grafica = new Chart(canvas, pintar(valoresGrafica, tituloGrafica));
	
	return grafica;
}

// Configura una grafica
function pintar(valoresGrafica, tituloGrafica){
	//calcularPromedio(valoresGrafica);
	redondearValores(valoresGrafica);

	var grafica =  {
		type: 'bar',
		data: {
			//labels: [a�oAntepasado, a�oPasado, a�oActual, "Promedio"],
			labels: [a�oAntepasado, a�oPasado, a�oActual],
			datasets: [{
				data: valoresGrafica,
				backgroundColor: [
					"rgba(54, 162, 235, 0.2)",
					"rgba(255, 99, 132, 0.2)",
					"rgba(75, 192, 192, 0.2)"
				],
				borderColor: [
					"rgba(54, 162, 235, 1)",
					"rgba(255, 99, 132, 1)",
					"rgba(75, 192, 192, 1)"
				],
				borderWidth: 1
			}]
		},
		options: {
			maintainAspectRatio: false,
			responsive:true,	
			scales: {
				xAxes: [{
					gridLines: {
						color: "rgba(0, 0, 0, 0)",
					}
				}],
				yAxes: [{
					ticks: {
						beginAtZero:true,
					},
					gridLines: {
						color: "rgba(0, 0, 0, 0)",
					}
				}]
			},
			title: {
				display: true,
				text: tituloGrafica,
				position:'top',
				padding:17
			},
			legend: {
				display: false
			},
			label: {
				display: false
			},
			tooltips: {
				enabled: false
			},
			hover: {
				animationDuration: 0
			},
			animation: {
				duration: 5,
				onComplete: function () {
					var chartInstance = this.chart,
						
					ctx = chartInstance.ctx;
					ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
					ctx.textAlign = 'center';
					ctx.textBaseline = 'bottom';

					this.data.datasets.forEach(function (dataset, i) {
						var meta = chartInstance.controller.getDatasetMeta(i);
					
						meta.data.forEach(function (bar, index) {
							var data = dataset.data[index];                            
					
							ctx.fillText(data, bar._model.x, bar._model.y - 3);
						});
					});
				}
			}
		}		
	};
				
	return grafica;
}

// Redondea los valores de las graficas a dos decimales
function redondearValores(valoresGrafica){
	for (i = 0; i < valoresGrafica.length; i++){
		if (valoresGrafica[i] != null){
			valoresGrafica[i] = parseFloat(Math.round(valoresGrafica[i] * 100) / 100).toFixed(2);
		}
	}
}

// Calcula el promedio de los 3 a�os mostrados en la grafica
/*function calcularPromedio(valoresGrafica){
	var suma = 0;
	var contador = 0;
	var promedio = 0;
	
	if (valoresGrafica.length > 0){
		if (valoresGrafica[0] != null){
			suma = suma + valoresGrafica[0];
			contador = contador + 1;
		}
		if (valoresGrafica[1] != null){
			suma = suma + valoresGrafica[1];
			contador = contador + 1;
		}
		if (valoresGrafica[2] != null){
			suma = suma + valoresGrafica[2];
			contador = contador + 1;
		}

		promedio = suma / contador;
		valoresGrafica[3] = promedio;
	}
	
	for (i = 0; i < valoresGrafica.length; i++){
		if (valoresGrafica[i] != null){
			valoresGrafica[i] = parseFloat(Math.round(valoresGrafica[i] * 100) / 100).toFixed(2);
		}
	}
}*/

// Mostrar u ocultar una grafica dependiendo si tiene o no datos
function comprobarGrafica(valoresGrafica, idGrafica) {
	if (valoresGrafica.length != 0){
		mostrarGrafica(idGrafica);
	} else {
		ocultarGrafica(idGrafica);
	}
}

// Mostrar grafica especifica
function mostrarGrafica(idGrafica) {
	$('#' + idGrafica).removeClass(' hide');
}

// Ocultar grafica especifica
function ocultarGrafica(idGrafica) {
	$('#' + idGrafica).addClass(' hide');
}

// Mostrar labels y bot�n de contactos
function mostrarDetalles() {
	$('#label1').removeClass(' hide');
	$('#label2').removeClass(' hide');
	$('#label3').removeClass(' hide');
	$('#label4').removeClass(' hide');
	$('#label5').removeClass(' hide');
	$('#label6').removeClass(' hide');
	$('#label7').removeClass(' hide');
	$('#label8').removeClass(' hide');
	$('#btnModalContacto').removeClass(' hide');
	$('#btnModalInfoCupos').removeClass(' hide');
	$('#btnEnviarOrdenes').removeClass(' hide');
}

// Ocultar labels y bot�n de contactos
function ocultarDetalles() {
	$("#label1").addClass(' hide');
	$("#label2").addClass(' hide');
	$("#label3").addClass(' hide');
	$("#label4").addClass(' hide');
	$("#label5").addClass(' hide');
	$("#label6").addClass(' hide');
	$("#label7").addClass(' hide');
	$("#label8").addClass(' hide');
	$('#btnModalContacto').addClass(' hide');
	$('#btnModalInfoCupos').addClass(' hide');
	$('#btnEnviarOrdenes').addClass(' hide');
}