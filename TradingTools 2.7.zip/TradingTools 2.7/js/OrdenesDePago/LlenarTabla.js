// Llena la tabla
function construirTabla(encabezados){
	conexion.Open(stringConnections.strConexionDataMart);
	recordSet.Open(queries.consultaOrdenesDePago, conexion);
	
	datosTablaCompletos = "<thead id='thead'></tr><tr>";
	
	for(i = 0; i < encabezados.length; i++){
		datosTablaCompletos = datosTablaCompletos + "<th>" + encabezados[i] + "</th>";
	}
	
	datosTablaCompletos = datosTablaCompletos + "</tr></thead>";
	
	datosTablaCompletos = datosTablaCompletos + "<tbody id='tbody'>";
			
	while (recordSet.EOF == false){
		var fecha = new Date(recordSet("fecha"));
		var fechaConFormato = $.datepicker.formatDate('yy/mm/dd', fecha);
		var fila = "<tr>" +
						"<td>" + recordSet("NU") + "</td>" +
						"<td>" + fechaConFormato + "</td>" +
						"<td>" + recordSet("Trader") + "</td>" +
						"<td>" + recordSet("Unidad") + "</td>" +
						"<td>" + recordSet("TipoID") + "</td>" +
						"<td>" + recordSet("Nit") + "</td>" +
						"<td>" + recordSet("Beneficiario") + "</td>" +
						"<td>" + recordSet("Ordenante") + "</td>" +
						"<td>" + recordSet("Cod_Mone") + "</td>" +
						"<td class='formatoValor'>" + recordSet("Valor") + "</td>" +
						"<td>" + recordSet("Emisor") + "</td>" +
						"<td>" + recordSet("Corresponsal") + "</td>" +
						"<td>" + recordSet("banca") + "</td>" +
						"<td>" + recordSet("segmento") + "</td>" +
						"<td>" + recordSet("region") + "</td>" + 
						//"<td class='linkEnviarOrdenDesactivada'><span class='fa fa-envelope' title='Enviar �rdenes de Pago'></span></td>" + 
						"<td class='linkEnviarOrdenDesactivada enviar'>" + 
							"<div class='btn-group'>" + 
								"<span class='dropdown-toggle' data-toggle='dropdown' style='cursor: pointer'>" + 
									"<span class='fa fa-envelope' title='Enviar �rdenes de Pago'></span>" +
								"</span>" +
								"<ul style='cursor:pointer' class='dropdown-menu' role='menu'>" + 
									"<li><a class='seleccionar'>Seleccionar</a></li>" +
									"<li><a class='deseleccionar'>Desmarcar</a></li>" +
									"<li class='divider'></li>" + 
									"<li><a class='enviarActual'>Enviar cliente actual</a></li>" +
									"<li><a class='enviarSeleccionadas desactivado'>Enviar clientes seleccionados</a></li>" +
								"</ul>" +
							"</div>" +
						"</td>"
					"</tr>";
		
		datosTablaCompletos = datosTablaCompletos + fila;
		
		recordSet.MoveNext();
	}
	
	datosTablaCompletos = datosTablaCompletos + "</tbody>";
	
	var tfoot = "<tfoot>" + 
					"<tr class='filaTotales'>" + 
						"<td class='bordeTotales' colspan='16'><span id='totalValor'></span></td>" + 
					"</tr>" + 
					// "<tr>" + 
						// "<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>" + 
					// "</tr>" + 
				"</tfoot>";
				
	datosTablaCompletos = datosTablaCompletos + tfoot;
				
	$("#tablaResultados").append(datosTablaCompletos);
	
	recordSet.Close(); 
	conexion.Close();
	
	// Da formato a la columna valor con dos decimales
	$('.formatoValor').number( true, 2 );
}