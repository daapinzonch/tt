function reactiveCustomer(connection, command, recordSet, stringConnection, nit){
	var query = replaceAll(queries.queryUpdateReactiveCustomersPEC, 'R_NIT', nit);	
	var query2 = replaceAll(queries.queryDeleteReactiveCustomersPEC, 'R_NIT', nit);
	
	if (develop){
		console.log("Query actualiza Descartado 0:  " + query);
		console.log("Query Elimina:  " + query2);
	} else{
		if (!update(query, stringConnection, connection, command)){
			alert("Error al intentar Reactivar este Cliente");
		} else{
			if(!deleteDB(query2, stringConnections.strConnectionPEC, connection)){
				alert("Error al intentar Reactivar este Cliente");
			} else{
				$("#discard-customers-table").DataTable().destroy();
				resetModal([["#discard-customers-table", "container"]]);
				buildTable(["Fecha Desc", "Nit", "Cliente", "Consultor", "Observacion", "Acción"], getDiscardCustomers(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(queries.queryDiscardCustomersPEC, 'R_USUARIOS', usersToShowMe)), "#discard-customers-table");
				$("#discard-customers-table").DataTable({"ordering": false});
				showBootstrapDialog("Información", "Se reactivó satisfactoriamente el cliente, Por favor actualice el módulo para ver reflejado este cambio", "PRIMARY", "ALERT", "NORMAL");
			}
		}
	}
}

function updateVisitStatus(connection, command, recordSet, stringConnection, selector){
	var nit = $(selector).parent().parent().children().eq(1).text().trim();
	var status = $(selector).text().trim();
	
	var statuses = ["En Proceso", "Declinada", "Realizada"];
	var nextStatusIndex = statuses.indexOf(status) == statuses.length - 1 ? 0 : statuses.indexOf(status) + 1
	var nextStatus = statuses[nextStatusIndex];
	var query = replaceAll(replaceAll(queries.queryUpdateVisitStatusPEC, "R_NIT", nit), "R_ESTADO", nextStatus);
	
	if (develop){
		console.log("Query actualiza estado de visita: " + query);
	} else{
		if (!update(query, stringConnection, connection, command)){
			alert("Error al intentar actualizar el estado de la visita");
		} else{
			$(selector).html(nextStatus + " <i class='fa fa-refresh'></i>");
		}
	}
}

function searchCustomer(nit){
	/*---------REVIEW----------*/
	var spreads = [];
	var status = true;
	
	var query = replaceAll(queries.queryDetalleClientePEC, 'R_NIT', nit);
	//showBootstrapDialog("Información", query ,"DANGER", "ALERT", "NORMAL");
	getGeographyInformation(connection, recordSet, stringConnections.strConnectionPEC, query);

	query = replaceAll(queries.queryAñoAnteriorClientePEC, 'R_CRITERIO', "Nit='" + nit + "'");
	getCustomerInformationYear(connection, recordSet, stringConnections.strConnectionPEC, query, "");
	
	query = replaceAll(queries.queryMesAnteriorClientePEC, 'R_CRITERIO', "Nit='" + nit + "'");
	getCustomerInformationMonth(connection, recordSet, stringConnections.strConnectionPEC, query, "");

	query = replaceAll(queries.queryStrategiesInfoPEC, 'R_NIT', nit);
	getStrategiesInfo(connection, recordSet, stringConnections.strConnectionPEC, query);
}

function discardCustomer(){
		var idTable = "#" + $("#hidden-id-modal").attr('class');
		var type = $("#hidden-type-modal").attr('class');
		var nit = $("#discard-nit-modal").text();
		var strategy = "DescartadoCliente";
		var reason = $("#discard-type-modal").val();
		var observation = compareString($("#discard-reason-customer-modal").val(), "Otra, cual?") || compareString($("#discard-reason-bank-modal").val(), "Otra, cual?") ? $("#discard-observation-modal").val() : (compareString(reason, "Cliente") ? $("#discard-reason-customer-modal").val() : (compareString(reason, "Banco") ? $("#discard-reason-bank-modal").val() : "NULL"));
		var area = "Internacional";
		var query1 = replaceAll(queries.queryDespriorizarClientePEC, "R_NIT", nit);
		var query2 = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracionPEC, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
		
		showBootstrapDialog("Confirmación", "¿Está seguro que desea descartar este cliente?", "DANGER", "CONFIRM", "SMALL", function(result){if(result){ 
			if (develop){
				console.log("Query desprioriza likes (descarte): " + query1);
				console.log("Query descartado en valoracion (descarte): " + query2);
			} else{
				if (!update(query1, stringConnections.strConnectionPEC, connection, command)){
					alert("Error al intentar actalizar DescarteClientes");
				} else{
					if (!insert(query2, stringConnections.strConnectionPEC, connection)){
						alert("Error al intentar insertar DescarteClientes");
					} else{
						destroyPetTable(idTable, type);
						removeClass("#hidden-id-modal", $("#hidden-id-modal").attr('class'));
						removeClass("#hidden-type-modal", $("#hidden-type-modal").attr('class'));
						$("#discard-modal").modal('hide');
						showBootstrapDialog("Información", "El cliente se descartó exitosamente", "PRIMARY", "ALERT", "NORMAL");
					}
				}
			}
		
		}});
}

function activeStrategy(selector){
	/*---------AUMENTARPS----------*/
	var strategy = $(selector).parent().attr("value");
	var nit = $(selector).parent().parent().children().eq(0).text().trim();
	var type = $(selector).attr("value");
	var s1 = compareString(strategy, "CarteraME") ? 1 : 0;
	var s2 = compareString(strategy, "PasivosME") ? 1 : 0;
	var s3 = compareString(strategy, "ComisionesME") ? 1 : 0;

	var trader = (users.currentUser).toUpperCase();

	if (s1 == 1){
		var query = replaceAll(queries.queryUpdateCarteraPEC, 'R_NIT', nit);

		if (develop){
			console.log("Query inserta en habilitaciones: " + query);
		}else{
			if (!update(query, stringConnections.strConnectionPEC, connection, command)){
				showBootstrapDialog("Información", replaceAll(queries.queryUpdateComisionesPEC, 'R_NIT', nit), "PRIMARY", "ALERT", "NORMAL" );
			}else{				
				$(selector).parent().html("<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>");
			}
		}
	}
	if (s2 == 1){
		var query = replaceAll(queries.queryUpdatePasivosPEC, 'R_NIT', nit);

		if (develop){
			console.log("Query inserta en habilitaciones: " + query);
		}else{
			if (!update(query, stringConnections.strConnectionPEC, connection, command)){
				showBootstrapDialog("Información", replaceAll(queries.queryUpdateComisionesPEC, 'R_NIT', nit), "PRIMARY", "ALERT", "NORMAL" );
			} else{			
				$(selector).parent().html("<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>");
			}
		}
	}
	if (s3 == 1){
		var query = replaceAll(queries.queryUpdateComisionesPEC, 'R_NIT', nit);

		if (develop){
			console.log("Query inserta en habilitaciones: " + query);
		}else{
			if (!update(query, stringConnections.strConnectionPEC, connection, command)){
				showBootstrapDialog("Información", replaceAll(queries.queryUpdateComisionesPEC, 'R_NIT', nit), "PRIMARY", "ALERT", "NORMAL" );
			} else{		
				$(selector).parent().html("<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>");
			}
		}
	}
	
	//var query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryCrearEstrategiaPEC, 'R_NIT', nit), 'R_CARTERA', s1), 'R_PASIVOS', s2), 'R_COMISIONES', s3), 'R_CONSULTOR', trader);
}

function scheduleVisit(selector){
	var row = $(selector).parent().parent().children();
	
	var nit = row.eq(0).text().trim();
	var customer = row.eq(1).text();
	var type = row.eq(2).text();
	var trader = row.eq(4).text();
	var visit = row.eq(5).children().eq(0).val();
	var date = row.eq(6).children().eq(0).val();
	var state = "En Proceso";
	var area = "Internacional";
	var error = validateDateInput(date);

	if (develop){
		console.log("Query Actualiza Campo Agendados:  " + replaceAll(queries.queryUpdateSchedulePEC, 'R_NIT', nit));
		console.log("Query Sin replace: " + queries.queryInsertSchedulePEC);
		console.log("Query Inserta Visita:  " + replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryInsertSchedulePEC, 'R_NIT', nit), 'R_CLIENTE', customer), 'R_FECHA', date), 'R_TRADER', trader), 'R_VISITA', visit), 'R_ESTADO', state), 'R_AREA', area));
	} else{
		if (!compareString(error, "")){
			showBootstrapDialog("Información", error, "WARNING", "ALERT", "NORMAL");
		} else{
			var query = replaceAll(queries.queryUpdateSchedulePEC, 'R_NIT', nit);
			
			if (!update(query, stringConnections.strConnectionPEC, connection, command)){
				alert("Error al intentar actualizar la agenda de este Cliente");
			} else{
				query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryInsertSchedulePEC, 'R_NIT', nit), 'R_CLIENTE', customer), 'R_FECHA', date), 'R_TRADER', trader), 'R_VISITA', visit), 'R_ESTADO', state), 'R_AREA', area);
				if (!insert(query, stringConnections.strConnectionPEC, connection, command)){
					alert("Error al intentar Agendar la visita de este Cliente");
				} else{
					var nits = [];
					
					$("#schedule-customers-table").DataTable().destroy();
					resetModal([["#schedule-customers-table", "container"]]);
					buildTable(["Nit", "Cliente", "Tipo", "Estrategia", "Consultor", "Tipo Visita", "Fecha Estimada", "Acción"], getScheduleCustomers(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(queries.queryScheduleCustomersPEC, 'R_USUARIOS', usersToShowMe), nits), "#schedule-customers-table");
					instanceDatepickers(nits);
					$("#schedule-customers-table").DataTable({"ordering": false});
					showBootstrapDialog("Información", "Se creó la visita satisfactoriamente", "PRIMARY", "ALERT", "NORMAL");
					$("#schedule-customers-modal").modal("show");		
					
				}
			}
			
		}
	}
}

function deleteVisits(connection, command, recordSet, stringConnection, nit){
	var query = replaceAll(queries.queryUpdateVisitsPEC, 'R_NIT', nit);	
	var query2 = replaceAll(queries.queryDeleteVisitsPEC, 'R_NIT', nit);
	
	if (develop){
		console.log("Query Actualiza Agendados 0:  " + query);
		console.log("Query Elimina:  " + query2);
	} else{
		if (!update(query, stringConnection, connection, command)){
			alert("Error al intentar Actualizar esta visita");
		} else{
			if(!deleteDB(query2, stringConnection, connection)){
				alert("Error al intentar Eliminar esta visita");
			} else{
				$("#visits-table").DataTable().destroy();
				resetModal([["#visits-table", "container"]]);
				buildTable(["Fecha Creación", "Nit", "Cliente", "Fecha Estimada", "Trader", "Tipo Visita", "Estado", "Acción"], getVisits(connection, recordSet, stringConnection, replaceAll(queries.queryVisitsPEC, 'R_USUARIOS', replaceAll(replaceAll(usersToShowMe, "AND ", ""), "PECNitEstrategias.", ""))), "#visits-table");
				$("#visits-table").DataTable({"ordering": false});
		
				$("#visits-modal").modal("show");
				showBootstrapDialog("Información", "Se eliminó satisfactoriamente esta visita", "PRIMARY", "ALERT", "NORMAL");
			}
		}
	}
}

function getCustomerInformationMonth(connection, recordSet, stringConnection, query, type){
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){
			//addClass($("#" + type + "exp-camb"), recordSet(3).Value < 0 ? "error" : "");
			addClass($("#" + type + "wallet-sha"), recordSet(5).Value < 0 ? "error" : "");
		
			$("#" + type + "prom-cart-m").text(!compareString(isInvalid(recordSet(0).Value + "", ""), "") ? addCommas(parseFloat(recordSet(0))) : "");
			$("#" + type + "prom-pas-m").text(!compareString(isInvalid(recordSet(1).Value + "", ""), "") ? addCommas(parseFloat(recordSet(1))) : "");
			$("#" + type + "comi-m").text(!compareString(isInvalid(recordSet(2).Value + "", ""), "") ? addCommas(parseFloat(recordSet(2))) : "");
			$("#" + type + "impo").text(!compareString(isInvalid(recordSet(3).Value + "", ""), "") ? addCommas(parseFloat(recordSet(3))) : "");
			$("#" + type + "expo").text(!compareString(isInvalid(recordSet(4).Value + "", ""), "") ? addCommas(parseFloat(recordSet(4))) : "");
			$("#" + type + "cart-ml").text(!compareString(isInvalid(recordSet(5).Value + "", ""), "") ? addCommas(parseFloat(recordSet(5))) : "");
			$("#" + type + "cart-me").text(!compareString(isInvalid(recordSet(6).Value + "", ""), "") ? addCommas(parseFloat(recordSet(6))) : "");
			$("#" + type + "wallet-sha").text(!compareString(isInvalid(recordSet(7).Value + "", ""), "") ? addCommas(parseFloat(recordSet(7))) : "");
			$("#" + type + "cre-cart").text(!compareString(isInvalid(recordSet(8).Value + "", ""), "") ? addCommas(parseFloat(recordSet(8))) : "");
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
}

function getCustomerInformationYear(connection, recordSet, stringConnection, query, type){
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		while (!recordSet.EOF){		
			$("#" + type + "prom-cart-a").text(!compareString(isInvalid(recordSet(0).Value + "", ""), "") ? addCommas(parseFloat(recordSet(0))) : "");
			$("#" + type + "prom-pas-a").text(!compareString(isInvalid(recordSet(1).Value + "", ""), "") ? addCommas(parseFloat(recordSet(1))) : "");
			$("#" + type + "comi-a").text(!compareString(isInvalid(recordSet(2).Value + "", ""), "") ? addCommas(parseFloat(recordSet(2))) : "");
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
}

function getDiscardCustomers(connection, recordSet, stringConnection, query){
	var tbody = "<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var date = new Date(recordSet(2).Value);
			var dateFormat = date.getDate() + " " + convertNumericMonthToStringMonth(date.getMonth() + 1) + " " + date.getFullYear();
			var nit = recordSet(0).Value.trim();
			var customer = recordSet(1).Value;
			var observations = recordSet(3).Value;
			var trader = recordSet(4).Value;
			var action = "<a class='reactive'>Reactivar <i class='fa fa-undo'></i></a>";
			
			tbody = tbody + "<tr><td>" + dateFormat + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + trader + "</td><td>" + observations + "</td><td>" + action + "</td></tr>";
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return tbody;
}

function getScheduleCustomers(connection, recordSet, stringConnection, query, nits){
	var tbody = "<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			nits.push(recordSet(0).Value.trim());
			
			var nit = recordSet(0).Value.trim();
			var customer = recordSet(1).Value.trim();
			var type = recordSet(2).Value.trim();
			var trader = recordSet(3).Value.trim();
			var strategies = recordSet(4).Value.trim();
			var visit = "<select class='form-control'><option>Teleconferencia</option><option>Webex</option><option>Presencial</option></select>"
			var date = "<input type='text' id='" + nit + "' class='form-control' placeholder='Selecciona Fecha'>"
			var action = "<a class='schedule'>Agendar <i class='fa fa-calendar'></i></a><br><a class='pipeline' href='Pipeline.html???" + strategies + "???" + nit + "' target='_blank'>Pipeline <i class='fa fa-bar-chart-o'></i></a>";

			tbody = tbody + "<tr><td>" + nit + "</td><td>" + customer + "</td><td>" + type + "</td><td>" + strategies + "</td><td>" + trader + "</td><td>"  + visit + "</td><td>" + date + "</td><td>" + action + "</td></tr>";
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return tbody;
}

function getVisits(connection, recordSet, stringConnection, query){
	var tbody = "<tbody>";
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var creationDate = (new Date(recordSet(0).Value));
			var creationDateFormat = creationDate.getDate() + " " + convertNumericMonthToStringMonth(creationDate.getMonth() + 1) + " " + creationDate.getFullYear();
			var nit = recordSet(1).Value;
			var customer = recordSet(2).Value;
			var estimatedDate = recordSet(3).Value;
			var estimatedDate = (new Date(recordSet(3).Value));
			var estimatedDateFormat = estimatedDate.getDate() + " " + convertNumericMonthToStringMonth(estimatedDate.getMonth() + 1) + " " + estimatedDate.getFullYear();
			var trader = recordSet(4).Value;
			var visit = recordSet(5).Value;
			var status = "<a class='status'>" + recordSet(6).Value + " <i class='fa fa-refresh'></i></a>";
			var action = "<a class='delete-visit'>Eliminar <i class='fa fa-times'></i></a>";
			
			tbody = tbody + "<tr><td>" + creationDateFormat + "</td><td>" + nit + "</td><td>" + customer + "</td><td>" + estimatedDateFormat + "</td><td>" + trader + "</td><td>" + visit + "</td><td>" + status + "</td><td>" + action + "</td></tr>";
			
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return tbody;
}

function getStrategiesInfo(connection, recordSet, stringConnection, query){
	var strategies = [];
	var reasons = [];
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);

		var cartera = recordSet(0).Value;
		var pasivos = recordSet(1).Value;
		var comisiones = recordSet(2).Value;
		
		var carteraEnabled = recordSet(5).Value;
		var pasivosEnabled = recordSet(6).Value;
		var comisionesEnabled = recordSet(7).Value;

		while (!recordSet.EOF){
			if(!compareString(recordSet(3).Value, "No")) strategies.push(recordSet(3).Value);
			if(!compareString(recordSet(4).Value, "No")) reasons.push(recordSet(4).Value);

			recordSet.MoveNext();
		}

		// Put All Strategies
		[[cartera, carteraEnabled, "CarteraME"],[pasivos, pasivosEnabled, "PasivosME"], [comisiones, comisionesEnabled, "ComisionesME"]].forEach(function(e){$("#stra-apply").append(e[0] == 0 ? "" : (e[1] == 1 ? "<span class='info'>" + e[2] + " (H)</span><br>" : "<span class='info'>" + e[2] + "</span><br>"))});
		
		// Put Priorizate/Despriorizate Strategies
		for (var i = 0; i < strategies.length; i++){
			reasons[i] == "Descartado" ? $("#stra-desprio").append("<span class='info error'> "+ strategies[i] +" </span><br>") : reasons[i] == "AceptadoConsultor" ? $("#stra-prio").append("<span class='check'> "+ strategies[i] +" </span><br>") : "";
		}
		
	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

function getStrategies(connection, recordSet, stringConnection, query, type){
	var strategiesHtml = "<tbody>";
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var nit = recordSet(0).Value;
			var customer = recordSet(1).Value;
			var strategy1 = recordSet(2).Value == 9999 ? "<i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(2).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var strategy2 = recordSet(3).Value == 9999 ? "<i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(3).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var strategy3 = recordSet(4).Value == 9999 ? "<i class='fa fa-check-square-o done' title='Evaluado'></i> <i class='hidden'>2</i>" : recordSet(4).Value == 1 ? "<i class='fa fa-check like' title='Priorizar'></i> <i class='fa fa-times dislike' title='Despriorizar'></i> <i class='hidden'>0</i>" : "<a class='active-strategy' value='" + type + "'>  <i class='fa fa-plus' title='Habilitar'></i><i class='hidden'>1</i></a>";
			var consul = recordSet(5).Value;
			var observations = "<textarea class='form-control observations' rows='1'>" + recordSet(7).Value + "</textarea>"; 
			var action = "<a class='ban' value='" + type + "'>Descartar <i class='fa fa-ban'></i></a> <br> <a class='save hide' value='" + type + "'>Guardar <i class='fa fa-save'></i></a>";
			var strategyNames = ["CarteraME", "PasivosME", "ComisionesME"];

			strategiesHtml = strategiesHtml + "<tr value='false'><td><a class='search'>" + nit + "</a></td><td>" + customer +  " </td><td value='" + strategyNames[0] + "'>" + strategy1 + "</td><td value='" + strategyNames[1] + "'>" + strategy2 + "</td><td value='" + strategyNames[2] + "'>" + strategy3 + "</td><td>" + observations + "</td><td>" + action + "</td></tr>";
		
			recordSet.MoveNext();
		}
	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}
	
	return strategiesHtml + "</tbody>";
}

function consultItems(connection, recordSet, stringConnection, query){
	var myItems = "";
	
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
	
		while (!recordSet.EOF){
			myItems = myItems + "<option>" + recordSet(0).Value + "</option>";
			recordSet.MoveNext();
		}
	} catch(e){	
		alert("Ocurrió un error a obtener los items de las listas desplegables")
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return myItems;
}

function insertLikes(connection, nit){
	for (var i = 0; i < selections.likes.length; i++){
		if (compareString(selections.likes[i].Nit, nit)){
			var strategy = selections.likes[i].Estrategia;
			var reason = "AceptadoConsultor";
			var observation = "Dado por el Consultor";
			var area = "Internacional";
			var query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracionPEC, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
			
			if (develop){
				console.log("Query inserta likes: " + query);
			} else {
				if (!insert(query, stringConnections.strConnectionPEC, connection)){
					alert("Ocurrió un error al intentar almacenar las priorizaciones like");
				}
			}
		}
	}
}

function insertDislikes(connection, nit){
	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			var strategy = selections.dislikes[i].Estrategia;
			var reason = "Descartado";
			var observation = "Dado por el Consultor";
			var area = "Internacional";
			var query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracionPEC, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
			
			if (develop){
				console.log("Query inserta dislikes: " + query);
			} else{
				if (!insert(query, stringConnections.strConnectionPEC, connection)){
					alert("Ocurrió un error al intentar almacenar las priorizaciones dislike");
				}
			}
		}
	}
}

function priorizateCustomers(connection, nit){
	/*---------PRIORIZACION----------*/
	var totalNits = []
	var uniqueNits = [];
	
	for (var i = 0; i < selections.likes.length; i++){
		totalNits.push(selections.likes[i].Nit);
	}
	
	deleteDuplicates(totalNits, uniqueNits);
	
	for (var i = 0; i < uniqueNits.length; i++){
		if (compareString(uniqueNits[i], nit)){
			var query = replaceAll(queries.queryPriorizarClientePEC, "R_NIT", nit);
			
			if (develop){
				console.log("Query prioriza likes: " + query);
			} else{
				if (!update(query, stringConnections.strConnectionPEC, connection, command)){
					alert("Ocurrió un error al intentar actualizar nit en priorizacion");
				}
			}
			
			break;
		}
	}
}

function validateDislikes(connection, nit){
	/*---------PRIORIZACION----------*/
	var strategyDislikesCount = 0;

	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			strategyDislikesCount = strategyDislikesCount + 1;
		}
	}
	
	var traderWeight = 0;
	
	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			var query = replaceAll(queries.queryPesoCliente, "R_NIT", nit);
			var newTraderWeight = 0;
			
			traderWeight = getTraderWeight(connection, recordSet, stringConnections.strConnectionPEC, query);
			newTraderWeight = (traderWeight - strategyDislikesCount);
			
			query = replaceAll(replaceAll(queries.queryPesoTrader, "R_NIT", nit), "R_PESOTRADER", newTraderWeight);
			
			if (develop){
				console.log("Query actualiza peso: " + query);
			} else{
				if (!update(query, stringConnections.strConnectionPEC, connection, command)){
					alert("Ocurrió un error al intentar actualizar PesoTrader");
				}
			}
			
			if(traderWeight == 0){
				query = replaceAll(queries.queryDespriorizarCliente, "R_NIT", nit);
				
				if (develop){
					console.log("Query desprioriza dislikes: " + query);
				} else{
					if (!update(query, stringConnections.strConnectionPEC, connection, command)){
						alert("Ocurrió un error al intentar despriorizar cliente");
					}
				}
				
				var strategy = "DescartadoCliente";
				var reason = "No aplican estrategias";
				var observation = "Trader: No aplican estrategias";
				var area = "Internacional";
				
				query = replaceAll(replaceAll(replaceAll(replaceAll(replaceAll(queries.queryAgregarValoracion, "R_NIT", nit), "R_ESTRATEGIA", strategy), "R_MOTIVO", reason), "R_OBSERVACION", observation), "R_AREA", area);
				
				if (develop){
					console.log("Query inserta no aplican estrategias: " + query);
				} else{
					if (!insert(query, stringConnections.strConnectionPEC, connection)){
						alert("Ocurrió un error al intentar insertar DescartadoCliente");
					}
				}
			}
			
			break;
		}
	}
}

function getTraderWeight(connection, recordSet, stringConnection, query){
	/*---------PRIORIZACION----------*/
	var weight = 0;
	
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		weight = recordSet(1).value == 0 ? recordSet(0).value : recordSet(1).value;
	} catch(e){
		alert("Ocurrió un error al intentar obtener el peso del cliente (" + e.message + ")");
	} finally{
		recordSet.Close();
		connection.Close();
	}
	
	return weight;
}

function insertObservations(connection, nit, observations){
	var obs = replaceAll(replaceAll(replaceAll(observations, '\n', ' '), '\t', ' '), '\r', '');
	var query = replaceAll(replaceAll(queries.queryUpdateObservationsPEC, "R_NIT", nit), "R_OBSERVACIONES", obs);
			
	if (develop){
		console.log("Query actualiza observationes: " + query);
	} else{
		if (!update(query, stringConnections.strConnectionPEC, connection, command)){
			alert("Ocurrió un error al intentar actualizar observaciones");
		}
	}
}

function getGeographyInformation(connection, recordSet, stringConnection, query) {
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);	

		while (!recordSet.EOF){

			$("#nit-info-modal").text(recordSet(0).Value);
			$("#customer-info-modal").text(recordSet(1).Value);
			$("#bank-info-modal").text(recordSet(2).Value);
			$("#segment-info-modal").text(recordSet(3).Value);
			$("#region-info-modal").text(recordSet(4).Value);
			$("#trader-info-modal").text(recordSet(5).Value);
			$("#type-info-modal").text(recordSet(6).Value);

			recordSet.MoveNext();
		}

	} catch(e){
		alert(e.message);
	} finally{
		recordSet.Close();
		connection.Close();
	}
}

function countStrategies (connection, recordSet, stringConnection, query){
	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);	
		
		while (!recordSet.EOF){
			$("#maintenance-tab").children().eq(0).text($("#maintenance-tab").children().eq(0).text() + " (" + recordSet(4).Value + ")"); 
			$("#news-tab").children().eq(0).text($("#news-tab").children().eq(0).text() + " (" + recordSet(1).Value + ")"); 
			$("#deepening-tab").children().eq(0).text($("#deepening-tab").children().eq(0).text() + " (" + recordSet(3).Value + ")"); 
			$("#reactivation-tab").children().eq(0).text($("#reactivation-tab").children().eq(0).text() + " (" + recordSet(2).Value + ")"); 
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
}


//Function that Convert JSON for Download
function reportDownload (connection, recordSet, stringConnection, query){
	var report = [];
	try {
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var date = new Date(recordSet(0));
			var nit = recordSet(1).Value;
			var customer = recordSet(2).Value;
			var strategy = recordSet(3).Value;
			var type = recordSet(4).Value;
			var unity = recordSet(5).Value;
			var trader = recordSet(6).value;
			var bank = recordSet(7).Value;
			var segment = recordSet(8).Value;
			var region = recordSet(9).Value;
			var prioritized = recordSet(10).Value;
			var visit = recordSet(11).Value;
			var stateVisit = recordSet(12).Value;
			var visitMade = recordSet(13).Value;
			var registerPipeline = recordSet(14).Value;
			var closeOperation = recordSet(15).Value; 
			report.push({"FechaActualizacion":date, "Nit":nit, "Cliente":customer, "Estrategia":strategy, "Tipo":type, "Unidad":unity, "Trader":trader, "Banca":bank, "Segmento":segment, "Region":region, "Priorizado": prioritized, "Visita Agendada":visit, "Estado Visita":stateVisit, "Registro Pipeline":registerPipeline, "Operacion Cerrada":closeOperation})
			recordSet.MoveNext(); 	
		}

	} catch(e){	
		alert(e.message);
	} finally {
		recordSet.Close();
		connection.Close();
	}

	return report;
}


function dataToExcel(data, sheetName, fileName){
	try{		
		if(typeof XLSX == 'undefined') XLSX = require('xlsx');
		var ws = XLSX.utils.json_to_sheet(data);
		var wb = XLSX.utils.book_new();
		XLSX.utils.book_append_sheet(wb, ws, sheetName);
		var wbout = XLSX.write(wb, {bookType:'xlsx', bookSST:false, type:'array'});
		var blob = new Blob([wbout], {type: "application/octet-stream"});
		saveAs(new Blob([wbout], {type:"application/octet-stream"}), fileName + ".xlsx"); // Use "FileSaver.js"

	} catch(e){
		showBootstrapDialog("Error", "Ocurrió un error en proceso de exportación (" + e.message + ")." ,"PRIMARY", "ALERT", "NORMAL" );
	}
}

