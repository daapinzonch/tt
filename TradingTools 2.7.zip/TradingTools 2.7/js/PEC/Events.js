// Add events
function addAllEventsPEC(){
	// Botones tab
		
	$("#news-button").on('click', function(){
		addClass(".news-get-container", " hide");
		removeClass(".news-table-container", " hide");
		//showBootstrapDialog("Información", replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "N"), "R_USUARIOS", usersToShowMe), "PRIMARY", "ALERT", "NORMAL" );
		buildTable(headers.PECheadersStrategies, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "N"), "R_USUARIOS", usersToShowMe), "N"), "#news-table");
		$("#news-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#news-table");
		PutAllCustomersPEC("#news-table","N");
	});

	$("#deepening-button").on('click', function(){
		addClass(".deepening-get-container", " hide");
		removeClass(".deepening-table-container", " hide");
		//showBootstrapDialog("Información", replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "P"), "R_USUARIOS", usersToShowMe), "PRIMARY", "ALERT", "NORMAL" );
		buildTable(headers.PECheadersStrategies, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "P"), "R_USUARIOS", usersToShowMe), "P"), "#deepening-table");
		$("#deepening-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#deepening-table");
		PutAllCustomersPEC("#deepening-table","P");
	});
	
	$("#reactivation-button").on('click', function(){
		addClass(".reactivation-get-container", " hide");
		removeClass(".reactivation-table-container", " hide");
		//showBootstrapDialog("Información", replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "R"), "R_USUARIOS", usersToShowMe), "PRIMARY", "ALERT", "NORMAL" );
		buildTable(headers.PECheadersStrategies, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "R"), "R_USUARIOS", usersToShowMe), "R"), "#reactivation-table");
		$("#reactivation-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#reactivation-table");
		PutAllCustomersPEC("#reactivation-table","R");
	});
	
	$("#maintenance-button").on('click', function(){
		addClass(".maintenance-get-container", " hide");
		removeClass(".maintenance-table-container", " hide");
		//showBootstrapDialog("Información", replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "N"), "R_USUARIOS", usersToShowMe), "PRIMARY", "ALERT", "NORMAL" );
		buildTable(headers.PECheadersStrategies, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", "M"), "R_USUARIOS", usersToShowMe), "M"), "#maintenance-table");
		$("#maintenance-table").DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		putScrollOnTable("#maintenance-table");
		PutAllCustomersPEC("#maintenance-table","M");
	});
		
	//Reporte PET
	$("#report-button").on('click', function (){ 

		showBootstrapDialog("Confirmación", "Esta seguro que desea descargar el reporte, ¿Desea continuar?", "DANGER", "CONFIRM", "NORMAL", function(result){if(result){ 
			var data = reportDownload(connection, recordSet, stringConnections.strConnectionPEC, queries.queryReportPEC);
			dataToExcel(data, "Reporte_PEC", "Reporte_PEC_" + users.currentUser.toUpperCase());
		}});

	});


	// Like/Dislike/Ban
	$("#news-table, #deepening-table, #reactivation-table, #maintenance-table").on('click', '.like', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var strategy = $(this).parent().attr("value");
		var type = $(this).parent().parent().parent().parent().attr("value");
		
		if (hasClass($(this), "like-selected")){
			for (var i = 0; i < selections.likes.length; i++){
				if (compareString(selections.likes[i].Nit, nit) && compareString(selections.likes[i].Estrategia, strategy)){
					selections.likes.splice(i, 1);
					break;
				}
			}
			removeClass($(this), "like-selected");
			removeClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		} else{
			for (var i = 0; i < selections.dislikes.length; i++){
				if (compareString(selections.dislikes[i].Nit, nit) && compareString(selections.dislikes[i].Estrategia, strategy)){
					selections.dislikes.splice(i, 1);
					break;
				}
			}
			
			selections.likes.push({"Nit":nit, "Estrategia":strategy});
			console.log($(this).parent().parent());
			removeClass($(this).parent().children("i").eq(1), "dislike-selected");
			addClass($(this), "like-selected");
			addClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		}
	});
	
	$("#news-table, #deepening-table, #reactivation-table, #maintenance-table").on('click', '.dislike', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var strategy = $(this).parent().attr("value");
		var type = $(this).parent().parent().parent().parent().attr("value");
	
		if (hasClass($(this), "dislike-selected")){
			for (var i = 0; i < selections.dislikes.length; i++){
				if (compareString(selections.dislikes[i].Nit, nit) && compareString(selections.dislikes[i].Estrategia, strategy)){
					selections.dislikes.splice(i, 1);
					break;
				}
			}
				
			removeClass($(this), "dislike-selected");
			removeClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		} else{
			for (var i = 0; i < selections.likes.length; i++){
				if (compareString(selections.likes[i].Nit, nit) && compareString(selections.likes[i].Estrategia, strategy)){
					selections.likes.splice(i, 1);
					break;
				}
			}
			//console.log("dislike");			
			selections.dislikes.push({"Nit":nit, "Estrategia":strategy});
		
			removeClass($(this).parent().children("i").eq(0), "like-selected");
			addClass($(this), "dislike-selected");
			addClass($(this).parent(), "modified");
			validateChangesOnRow($(this).parent().parent(), type);
		}
	});
	
	// Active strategies
	$("#news-table, #deepening-table, #reactivation-table,#maintenance-table").on('click', '.active-strategy', function (){
		var selector = $(this);
		showBootstrapDialog("Confirmación", "¿Está seguro que desea habilitar esta estrategia?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			activeStrategy(selector);
		}});
	});
	
	// Show modal for discard
	$("#reactivation-table, #maintenance-table, #news-table, #deepening-table").on('click', '.ban', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var customer = $(this).parent().parent().children().eq(1).text().trim();
		
		$("#discard-nit-modal").text(nit);
		$("#discard-customer-modal").text(customer);
		$("#discard-type-modal").val("Banco");
		$("#discard-observation-modal").val("");
		removeClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
		addClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
		$("#discard-reason-bank-modal").val("Plazo");
		addClass("#hidden-id-modal", $(this).parent().parent().parent().parent().attr('id'));
		addClass("#hidden-type-modal", $(this).attr('value'));
		$("#discard-modal").modal('show');
	});
	
	$("#reactivation-table, #maintenance-table, #news-table, #deepening-table").on('click', '.search', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		resetModal([[".graphs-container", "container"],
					["#stra-apply", "container"],
					["#stra-prio", "container"],
					["#stra-desprio", "container"],
					["#prom-cart-a", "text"],
					["#prom-pas-a", "text"],
					["#comi-a", "text"],
					["#prom-cart-m", "text"],
					["#prom-pas-m", "text"],
					["#comi-m", "text"],
					["#impo", "text"],
					["#expo", "text"],
					["#cart-ml", "text"],
					["#cart-me", "text"],
					["#wallet-sha", "text"],
					["#cre-cart", "text"],
					["#monto-dtf", "text"]]);
		searchCustomer(nit);
		$("#customer-information-modal").modal('show');
	});
	
	// Validate Type Discard Value
	$("#discard-type-modal").on('change', function(){
		var valor = $("#discard-type-modal").val();
		
		if (compareString(valor, "Cliente")){
			removeClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
			addClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
		} else if(compareString(valor, "Banco")){
			removeClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
			addClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
		} else{
			addClass($("#discard-reason-customer-modal").parent().parent().parent(), "hide");
			addClass($("#discard-reason-bank-modal").parent().parent().parent(), "hide");
		}
	});
	
	// Validate Reason Discard Value
	$("#discard-reason-customer-modal, #discard-reason-bank-modal").on('change',function(){
		var valor = $(this).val();
		
		if (compareString(valor, "Otra, cual?")){
			removeClass($("#discard-observation-modal").parent().parent().parent(), "hide");
		} else {
			addClass($("#discard-observation-modal").parent().parent().parent(), "hide");
		}
	});
	
	// Discard Customer
	$("#discard-button").on('click', function(){
		discardCustomer();
	});
	
	// Insert Priorization/Depriorization & Observations
	$("#reactivation-table, #maintenance-table, #news-table, #deepening-table").on('click', '.save', function (){
		var nit = $(this).parent().parent().children().eq(0).text().trim();
		var tableSelector = "#" + $(this).parent().parent().parent().parent().attr("id");
		var type = $(this).attr("value");	
		var observations = $(this).parent().parent().children().eq(5).children().eq(0).val();
		
		showBootstrapDialog("Confirmación", "¿Está seguro que desea guardar los cambios hechos de este cliente?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			insertLikes(connection, nit);
			insertDislikes(connection, nit);
			resetSelections(nit);
			if(!compareString(observations, "")) insertObservations(connection, nit, observations);
			destroyPetTable(tableSelector, type);
			showBootstrapDialog("Información", "Los cambios se aplicaron exitosamente", "PRIMARY", "ALERT", "NORMAL" );

		}});				
	});
	
	// Show Search Modal
	$("#search-button").on('click', function(){
		resetModal([["#nit-search-modal", "input"]]);
		$("#search-modal").modal('show');
	});
	
	$("#search-modal").on('shown.bs.modal', function () {
		$('#nit-search-modal').focus();
	});
	
	// Show Customer Information Modal
	$("#search-button-modal").on('click', function(){
		/********COMPLETE DATA TO SHOW********/
		var nit = $("#nit-search-modal").val().trim();
		
		resetModal([[".graphs-container", "container"],
					["#stra-apply", "container"],
					["#stra-prio", "container"],
					["#stra-desprio", "container"],
					["#prom-cart-a", "text"],
					["#prom-pas-a", "text"],
					["#comi-a", "text"],
					["#prom-cart-m", "text"],
					["#prom-pas-m", "text"],
					["#comi-m", "text"],
					["#impo", "text"],
					["#expo", "text"],
					["#cart-ml", "text"],
					["#cart-me", "text"],
					["#wallet-sha", "text"],
					["#cre-cart", "text"],
					["#monto-dtf", "text"]]);
		
		if (!compareString(nit, "")){
			searchCustomer(nit)
			
			$(".AñoAnterior").text((new Date()).getFullYear()- 1)
			$(".AñoActual").text((new Date()).getFullYear())
			$("#search-modal").modal('hide');
			$("#customer-information-modal").modal('show');
		} else{
			showBootstrapDialog("Información", "Por favor ingrese un nit para realizar la búsqueda", "WARNING", "ALERT", "NORMAL");
		}
	});
	
	// Show Discard Customers Modal
	$("#open-discard-customers-button").on('click', function(){
		var query = replaceAll(queries.queryDiscardCustomersPEC, 'R_USUARIOS', usersToShowMe);
		
		resetModal([["#discard-customers-table", "container"]]);
		buildTable(["Fecha Desc", "Nit", "Cliente", "Consultor", "Observacion", "Acción"], getDiscardCustomers(connection, recordSet, stringConnections.strConnectionPEC, query), "#discard-customers-table");
		$("#discard-customers-table").DataTable({"ordering": false});
		$("#discard-customers-modal").modal("show");
	});
	
	$("#discard-customers-modal, #schedule-customers-modal, #visits-modal").on('hidden.bs.modal', function (){
		$("#" + replaceAll($(this).attr('id'), "modal", "table")).DataTable().destroy();
	});
	
	// Show Schedule Customers Modal
	$("#open-schedule-customers-button").on('click', function(){
		var query = replaceAll(queries.queryScheduleCustomersPEC, 'R_USUARIOS', usersToShowMe);
		var nits = [];

		//showBootstrapDialog("Información", query, "PRIMARY", "ALERT", "NORMAL" );
		
		resetModal([["#schedule-customers-table", "container"]]);
		buildTable(["Nit", "Cliente", "Tipo", "Estrategia", "Consultor", "Tipo Visita", "Fecha Estimada", "Acción"], getScheduleCustomers(connection, recordSet, stringConnections.strConnectionPEC, query, nits), "#schedule-customers-table");
		instanceDatepickers(nits);
		$("#schedule-customers-table").DataTable({"ordering": false});
		$("#schedule-customers-modal").modal("show");				
	});
	
	// Show Visits Modal
	$("#open-visits-button").on('click', function(){
		var query = replaceAll(queries.queryVisitsPEC, 'R_USUARIOS', replaceAll(replaceAll(usersToShowMe, "AND ", ""), "PECNitEstrategias.", ""));
		
		resetModal([["#visits-table", "container"]]);
		buildTable(["Fecha Creación", "Nit", "Cliente", "Fecha Estimada", "Consultor", "Tipo Visita", "Estado", "Acción"], getVisits(connection, recordSet, stringConnections.strConnectionPEC, query), "#visits-table");
		$("#visits-table").DataTable({"ordering": false});
		
		$("#visits-modal").modal("show");
	});
	
	// Reactivate Customer
	$("#discard-customers-table").on('click', '.reactive', function (){
		var nit = $(this).parent().parent().children().eq(1).text().trim();
		showBootstrapDialog("Confirmación", "¿Está seguro que desea reactivar este cliente?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			reactiveCustomer(connection, command, recordSet, stringConnections.strConnectionPEC, nit);
		}});	
	});
	
	// Schedule Customer
	$("#schedule-customers-table").on('click', '.schedule', function (){
		var selector = $(this);
		showBootstrapDialog("Confirmación", "¿Está seguro que desea agendar este cliente?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			scheduleVisit(selector);
		}});	
	});

	// Delete Visit
	$("#visits-table").on('click', '.delete-visit', function (){
		var nit = $(this).parent().parent().children().eq(1).text().trim();
		showBootstrapDialog("Confirmación", "¿Está seguro que desea eliminar esta visita?", "PRIMARY", "CONFIRM", "NORMAL", function(result){if(result){ 
			deleteVisits(connection, command, recordSet, stringConnections.strConnectionPEC, nit);
		}});
	});
	
	// Change Visit Status
	$("#visits-table").on('click', '.status', function (){
		updateVisitStatus(connection, command, recordSet, stringConnections.strConnectionPEC, $(this));
	});
	
	// Allow Only Numeric Values For All Numeric Inputs 
	$("#nit-search-modal").keydown(function (e){allowNumericValues(e)});
	
	// When Enter Key is pressed, button too
	$('#nit-search-modal').keydown(function(e){if (e.keyCode == 13) {$('#search-button-modal').click()}});
	
	// Customer Observations on Table
	$('#news-table, #deepening-table, #reactivation-table, #maintenance-table').on('keyup', '.observations', function (){
		var type = $(this).parent().parent().parent().parent().attr("value");
		validateChangesOnTextArea($(this));
		validateChangesOnRow($(this).parent().parent(),type);
	});
	
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});
	
	// Tooltips
	$('.has-tooltip').tooltip({
		selector: "[data-toggle=tooltip]",
		container: "body"
	});
}