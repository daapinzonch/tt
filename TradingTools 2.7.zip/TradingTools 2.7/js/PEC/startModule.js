// ActiveX DB Objects
var fileSystem = new ActiveXObject("Scripting.FileSystemObject");
var connection = new ActiveXObject("ADODB.Connection");
var command = new ActiveXObject("ADODB.Command");
var recordSet = new ActiveXObject("ADODB.Recordset");

// Other Variables
var userType = "";
var usersToShowMe = "";
var traders = [];
var items = [];
var selections = {"likes":[], "dislikes":[]};
var strategiesSchedule = [];
var strategiesSchedule2 = [];

var develop = false;

addClass(".loading-container", " hide");
removeClass(".tables-container", "hide");
removeClass(".has-tooltip", "hide");

$(document).ready(function (){
	// Put Version
	assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), fileSystem));
	
	// Get Traders mail and name
	getUserInformation(connection, 
						recordSet, 
						replaceAll(queries.queryGetUserInformation, 
									"R_AREA", 
									"Internacional"), 
						stringConnections.strConexionDataMart, 
						traders);
	
	// Get My Rol
	userType = getUserType(connection, 
							recordSet, 
							queries.queryGetRol, 
							stringConnections.strConexionDataMart);
	
	//Ocultar panel de instrucciones
	showModules(userType);
	
	// Users to show Me
	if (compareString(userType, "GerencialT") || compareString(userType, "GerencialI")){
		usersToShowMe = replaceAll(getUsersToShowMe(replaceAll(queries.queryGetUsersByArea, "rUsuario", users.currentUser), stringConnections.strConexionDataMart, connection, recordSet), "Geografia.Consultor", "PECNitEstrategias.Consultor");
	} else if (compareString(userType, "Administrador")){
		usersToShowMe = "";
	} else{
		usersToShowMe = replaceAll(getUsersToShowMeCurrentGeography(replaceAll(queries.queryGetUsersToShow, "rUsuario", users.currentUser), stringConnections.strConexionDataMart, connection, recordSet), "Geografia.Consultor", "PECNitEstrategias.Consultor");
	}

	// Get Items
	getItems(connection, recordSet, stringConnections.strConnectionPEC);
	
	// Load Selects
	loadSelects();
	
	//Count Strategies
	//showBootstrapDialog("Información",  replaceAll(queries.queryCountStrategiesPEC, "R_USUARIOS", usersToShowMe), "PRIMARY", "ALERT", "NORMAL" );
	countStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(queries.queryCountStrategiesPEC, "R_USUARIOS", usersToShowMe));     

	// Show connected user
	showUserConnected("#connected-user");
	
	// Insert Log
	//insertLog(connection, "PEC WEB");
	
	// Events
	addAllEventsPEC();
});


function resetModal(selectorsArray){
	selectorsArray.forEach(function(e){
		if(compareString(e[1], "text")){
			$(e[0]).text("");
		} else if(compareString(e[1], "input")){
			$(e[0]).val("");
		} else if(compareString(e[1], "container")){
			$(e[0]).html("");
			removeClass($(e[0]), "hide");
		}
	});
}

function resetSelections(nit){
	for (var i = 0; i < selections.likes.length; i++){
		if (compareString(selections.likes[i].Nit, nit)){
			selections.likes.splice(i, 1);
		}
	}
	for (var i = 0; i < selections.dislikes.length; i++){
		if (compareString(selections.dislikes[i].Nit, nit)){
			selections.dislikes.splice(i, 1);
		}
	}
}

function destroyPetTable(selector, type){
	var tableHeaders = headers.PECheadersStrategies;
	var data = $(selector).DataTable().page.info().recordsTotal;
	$($(selector)).DataTable().destroy();
	if( data == 30){
		buildTable(tableHeaders, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", type), "R_USUARIOS", usersToShowMe), type), selector);
		$(selector).DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
		PutAllCustomersPEC(selector,type);
	} else {
		buildTable(tableHeaders, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", type), "R_USUARIOS", usersToShowMe), "TOP 30", ""), type), selector);
		$(selector).DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: []});
	}
	if(scroll)putScrollOnTable(selector);
}

function PutAllCustomersPEC(selector, type){
	var tableHeaders = headers.PECheadersStrategies;
	var id = selector.replace("#", "") + "_length";

	$('select[name='+id+']').on('change', function() {
			var selectedCountry = $(this).children("option:selected").val();
		   	if (selectedCountry == -1) {
		   		$($(selector)).DataTable().destroy();
		   		//showBootstrapDialog("Información", replaceAll(replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", type), "R_USUARIOS", usersToShowMe), "TOP 30", ""), "PRIMARY", "ALERT", "NORMAL" );
		   		buildTable(tableHeaders, getStrategies(connection, recordSet, stringConnections.strConnectionPEC, replaceAll(replaceAll(replaceAll(queries.queryClientesPEC, "R_TIPO", type), "R_USUARIOS", usersToShowMe), "TOP 30", ""), type), selector);
		   		$(selector).DataTable({"lengthMenu": [[10, 30, 50, -1], [10, 30, 50, "Todos"]], aaSorting: [], "pageLength": -1});
		   		if(scroll)putScrollOnTable(selector);
		   	}
	});
}


function getItems(connection, recordSet, stringConnection){
	items.push({"origin":consultItems(connection, recordSet, stringConnection, queries.queryOrigenDescartePEC)});
	items.push({"customerReasons":consultItems(connection, recordSet, stringConnection, queries.queryMotivoOrigenClienteDescartePEC)});
	items.push({"bankReasons":consultItems(connection, recordSet, stringConnection, queries.queryMotivoOrigenBancoDescartePEC)});
}

function loadSelects(){
	$("#discard-type-modal").html(items[0].origin);
	$("#discard-reason-customer-modal").html(items[1].customerReasons);
	$("#discard-reason-bank-modal").html(items[2].bankReasons);
}

function instanceDatepickers(nits){
	var datepickerConfiguration = {
			dateFormat : 'dd/mm/yy',
			beforeShowDay: $.datepicker.noWeekends,
			prevText: 'Anterior',
			nextText: 'Siguiente',
			currentText: 'Hoy',
			monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
			monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
			dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
			dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié;', 'Juv', 'Vie', 'Sáb'],
			dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'Sá'],
			minDate: '-d'
	};
	
	nits.forEach(function(e){$("#" + e).datepicker(datepickerConfiguration)});
}

function showSpreads(spreads){
	var graphsNumber = spreads.length;
	var offSet = graphsNumber <= 6 ? "col-md-offset-" + (6 - graphsNumber) : "";
	
	if(spreads.length > 0){
		spreads.forEach(function(e, p){
			$(".graphs-container").append("<div class='col-md-2 " + (p == 0 ? offSet : "") + "'><div class='chart-container'><canvas id='" + e[0] + "-" + e[1].substring(0,2) + "'></canvas></div>");
			new Chart($("#" + e[0] + "-" + e[1].substring(0,2)), getGraphConfiguration([e[2], e[3], e[4]], e[0] + " " + e[1]));
		});
	} else{
		addClass($(".graphs-container"), "hide");
	}
}

// VALIDACIONES
function validateChangesOnTextArea(selector){
	var value = $(selector).val();
	
	if (value.length == 0){
		removeClass($(selector).parent(), "modified");
	} else{
		addClass($(selector).parent(), "modified");
	}
}

function validateChangesOnRow(selector, type){

	var children = selector.children();
	
	if (hasClass(children.eq(2), "modified") || hasClass(children.eq(3), "modified") || hasClass(children.eq(4), "modified") || hasClass(children.eq(5), "modified")){
		$(selector).attr({"value":"true"});
		//type == 'N' ? removeClass(children.eq(6).children().eq(2), "hide") : removeClass(children.eq(13).children().eq(2), "hide");
		removeClass(children.eq(6).children().eq(2), "hide")
	} else{
		$(selector).attr({"value":"false"});
		//type == 'N' ? addClass(children.eq(6).children().eq(2), "hide") : addClass(children.eq(13).children().eq(2), "hide");
		addClass(children.eq(6).children().eq(2), "hide")
	}
}

function validateDateInput(value){
	var currentDate = getDate(0, false).split("/");
	var day = value.substring(0,2);
	var month = value.substring(3,5);
	var year = value.substring(6,10);
	var currentDay = currentDate[0];
	var currentMonth = currentDate[1];
	var currentYear = currentDate[2];
	
	if (value.length == 0) return getEmptyError();
	if (value.length != 10) return getLengthError(10);
	if (day.indexOf("/") != -1 || month.indexOf("/") != -1 || year.indexOf("/") != -1 || day.length < 2 || month.length < 2 || year.length < 4) return getDateStructureInvalidError();
	if (parseInt(month) > 12 || parseInt(month) < 1) return getLimitMonthError();
	if (parseInt(day) > 31 || parseInt(day) < 1) return getLimitDayError();
	if ((parseInt(month) < parseInt(currentMonth) && parseInt(year) <= parseInt(currentYear)) || (parseInt(year) < parseInt(currentYear)) || (parseInt(day) < parseInt(currentDay) && parseInt(month) <= parseInt(currentMonth) && parseInt(year) <= parseInt(currentYear))) return getMinimumDateError();
	
	return "";
}