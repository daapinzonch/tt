function obtenerErrorVacio(){return "(No puede estar vac�o)"}
function obtenerErrorNoPertenece(){return "(Valor no pertenece a la lista desplegable)"}
function obtenerErrorNoEsNumerico(){return "(Valor debe ser num�rico)"}
function obtenerErrorCaracterInvalido(caracter){return "(El caracter '" + caracter + "' no es v�lido)"}
function obtenerErrorVariosPuntos(){return "(Solo debe tener un punto decimal)"}
function obtenerErrorPuntoEnExtremos(){return "(No pueden haber puntos decimales al inicio ni al final)"}
function obtenerErrorCambiarValor(){return "(Debe cambiarse este valor)"}
function obtenerErrorTieneEspacios(){return "(No debe tener espacios)"}
function obtenerErrorLongitudFecha(){return "(Debe contener 10 caracteres, recuerde que la estructura es mm/dd/aaaa)"}
function obtenerErrorFechaNoEsNumerica(){return "(El d�a, mes y a�o deben ser n�mericos)"}
function obtenerErrorFechaSinSlash(){return "(La fecha debe tener '/' como separador)"}
function obtenerErrorDiaInvalido(){return "(El d�a debe estar entre 1-31)"}
function obtenerErrorMesInvalido(){return "(El mes debe estar entre 1-12)"}
function obtenerErrorFechaFutura(){return "(La fecha no puede ser mayor que la fecha actual)"}
function obtenerErrorFechaDiferenteA�o(){return "(La fecha debe ser de este a�o)"}
function obtenerErrorCaracterInvalido(caracter){return "(El caracter " + caracter + " no esta permitido)"}
function obtenerErrorDiferenciaUnMes(){return "(La diferencia de meses no debe ser mayor a 1)"}
function obtenerErrorDiferenciaQuinceDias(){return "(La diferencia de dias no debe ser mayor a 15)"}
function obtenerErrorTama�o(num){return "(El tama�o no debe superar los " + num + " d�gitos)"}