function validarPlazoEsperado(){
	var plazoEsperado = $("#plazoEsperado").val();
	var caracteresInvalidos = [",", "-", "+", "_", "?", "�", "!", "�", "/", "*", ";", ":", "'", "#", "$", "%", "&", "(", ")", "|", "�", "�", "."];
	
	if (plazoEsperado.localeCompare("") != 0){
		for (i = 0; i < caracteresInvalidos.length; i++){
			for (j = 0; j < plazoEsperado.length; j++){
				if (plazoEsperado.charAt(j).localeCompare(caracteresInvalidos[i]) == 0){
					error = obtenerErrorCaracterInvalido(caracteresInvalidos[i]);
					return false;
				}
			}
		}
		
		if (!isFinite(plazoEsperado)){
			error = obtenerErrorNoEsNumerico();
			return false;
		}
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo razon
function validarBanco(){
	var banco = $("#bancos").val();
	var opciones = [];
	var length = 0;
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarBanco, conexion);
	while (recordSet.EOF == false){
		opciones.push(recordSet(0).value+"");
		length = length+1;
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	var pertenece = false;
	
	if (banco.localeCompare("") != 0){
		for (i = 0; i < opciones.length; i++){
			if (banco.localeCompare(opciones[i]) == 0){
				pertenece = true;
				
				break;
			}
		}
		
		if (!pertenece){
			error = obtenerErrorNoPertenece();
			return false;
		}
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el input BDB
function validarBDB(id){
	var bdb = $("#" + id).val();
	var caracteresInvalidos = [",", "-", "+", "_", "?", "�", "!", "�", "/", "*", ";", ":", "'", "#", "$", "%", "&", "(", ")", "|", "�", "�"];
	var contadorPuntos = 0;
	
	if (bdb.localeCompare("") != 0){
		for (i = 0; i < caracteresInvalidos.length; i++){
			for (j = 0; j < bdb.length; j++){
				if (bdb.charAt(j).localeCompare(caracteresInvalidos[i]) == 0){
					error = obtenerErrorCaracterInvalido(caracteresInvalidos[i]);
					return false;
				}
			}
		}
		
		for (j = 0; j < bdb.length; j++){
			if (bdb.charAt(j).localeCompare(".") == 0){
				contadorPuntos = contadorPuntos + 1;
			}
		}
		
		if (contadorPuntos > 1){
			error = obtenerErrorVariosPuntos();
			return false;
		}
		
		if (!isFinite(bdb)){
			error = obtenerErrorNoEsNumerico();
			return false;
		}
		
		if ((bdb.charAt(0)).localeCompare(".") == 0 || (bdb.charAt(bdb.length - 1)).localeCompare(".") == 0){
			error = obtenerErrorPuntoEnExtremos();
			return false;
		}
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo razon
function validarRazon(){
	var razon = $("#razones").val();
	var opciones = [];
	var length = 0;
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarRazon, conexion);
	while (recordSet.EOF == false){
		opciones.push(recordSet(0).value+"");
		length = length+1;
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	var pertenece = false;
	
	if (razon.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < opciones.length; i++){
		if (razon.localeCompare(opciones[i]) == 0){
			pertenece = true;
			
			break;
		}
	}
	
	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	
	return true;
}

function validarTxtAreaComentarios(){
	var comentarios = $("#comentario").val();
	
	for (i = 0; i < comentarios.length; i++){
		if (comentarios.charAt(i) == "'"){
			error = obtenerErrorCaracterInvalido("'");
			return false;
		}
	}
	
	return true;
}

// Valida el valor escrito en el input monto
function validarMonto(){
	var montoConComas = $("#monto").val();
	var monto = reemplazarTodos(montoConComas, ",", "");
	var contadorPuntos = 0;
	var caracteresInvalidos = ["-", "+", "_", "?", "�", "!", "�", "/", "*", ";", ":", "'", "#", "$", "%", "&", "(", ")", "|", "�", "�"];
	
	if (monto.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < caracteresInvalidos.length; i++){
		for (j = 0; j < monto.length; j++){
			if (monto.charAt(j).localeCompare(caracteresInvalidos[i]) == 0){
				error = obtenerErrorCaracterInvalido(caracteresInvalidos[i]);
				return false;
			}
		}
	}
	
	for (j = 0; j < monto.length; j++){
		if (monto.charAt(j).localeCompare(".") == 0){
			contadorPuntos = contadorPuntos + 1;
		}
	}
	
	if (contadorPuntos > 1){
		error = obtenerErrorVariosPuntos();
		return false;
	}
	
	if (!isFinite(monto)){
		error = obtenerErrorNoEsNumerico();
		return false;
	}
	
	if ((monto.charAt(0)).localeCompare(".") == 0 || (monto.charAt(monto.length - 1)).localeCompare(".") == 0){
		error = obtenerErrorPuntoEnExtremos();
		return false;
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo par moneda
function validarProducto(){
	var producto = $("#productos").val();
	var opciones = [];
	var length =0;
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarProductos, conexion);
	while (recordSet.EOF == false){
		opciones.push(recordSet(0).value+"");
		length = length+1;
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	
	var pertenece = false;
	
	if (length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < length; i++){
		if (producto.localeCompare(opciones[i]) == 0){
			pertenece = true;
			
			break;
		}
	}
	
	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;
}

// Valida el valor escrito o seleccionado en el combo par moneda
function validarParMoneda(){
	var parMoneda = $("#parMonedas").val();
	var length = 0;
	var opciones = [];
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarParMoneda, conexion);
	while (recordSet.EOF == false){
		opciones.push(recordSet(0).value+"");
		length = length+1;
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	var pertenece = false;
	
	if (length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < length; i++){
		if (parMoneda.localeCompare(opciones[i]) == 0){
			pertenece = true;
			
			break;
		}
	}
	
	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo tipo operacion
function validarTipoOperacion(){
	var tipoOperacion = $("#tiposOperacion").val();
	var opciones = [];
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarTipoOperacion, conexion);
	while (recordSet.EOF == false){
		opciones.push(recordSet(0).value+"");
		length = length+1;
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	var pertenece = false;
	
	if (tipoOperacion.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < length; i++){
		if (tipoOperacion.localeCompare(opciones[i]) == 0){
			pertenece = true;
			
			break;
		}
	}
	
	if (!pertenece){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	return true;
}

// Valida el valor escrito o seleccionado en el combo cliente
function validarCliente(){
	var cliente = $("#cliente").val();
	
	for (i = 0; i < cliente.length; i++){
		if (cliente.charAt(i) == "'"){
			error = obtenerErrorCaracterInvalido("'");
			return false;
		}
	}
	
	if (cliente.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	if (cliente.localeCompare("No se encontr� cliente para el nit introducido") == 0){
		error = "";
		return false;
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo nit
function validarNit(){
	var nit = $("#nits").val();
	var caracteresInvalidos = [",", "-", "+", "_", "?", "�", "!", "�", "*", ";", ":", "'", "#", "$", "%", "&", "(", ")", "|", "�", "�", ".", "/", '"'];
	
	if (nit.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < caracteresInvalidos.length; i++){
		for (j = 0; j < nit.length; j++){
			if (nit.charAt(j).localeCompare(" ") == 0){
				error = obtenerErrorTieneEspacios();
				return false;
			}
			
			if (nit.charAt(j).localeCompare(caracteresInvalidos[i]) == 0){
				error = obtenerErrorCaracterInvalido(caracteresInvalidos[i]);
				return false;
			}
		}
	}
	
	if (!isFinite(nit)){
		error = obtenerErrorNoEsNumerico();
		return false;
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo trader
function validarTrader(){
	var trader = $("#traders").val();
	var encontrado = false;
	
	if (trader.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	for (i = 0; i < tradersNormal.length; i++){
		if (trader.localeCompare(tradersNormal[i]) == 0){
			encontrado = true;
			
			break;
		}
	}
	
	for (i = 0; i < ConsultorNormal.length; i++){
		if (trader.localeCompare(ConsultorNormal[i]) == 0){
			encontrado = true;
			
			break;
		}
	}
	
	if (!encontrado){
		error = obtenerErrorNoPertenece();
		return false;
	}
	
	error = "";
	
	return true;
}

// Valida el valor escrito o seleccionado en el combo fecha
function validarFecha(){
	var fecha = $("#fechas").val();
	var diaTexto = fecha.substring(0,2);
	var mesTexto = fecha.substring(3,5);
	var a�oTexto = fecha.substring(6,10);
	var diaNum = parseInt(diaTexto);
	var mesNum = parseInt(mesTexto);
	var a�oNum = parseInt(a�oTexto);
	var primerSlash = fecha.charAt(2);
	var segundoSlash = fecha.charAt(5);
	var fechaActualArr = (obtenerFechaActual(0, false)).split("/");
	var diaActual = fechaActualArr[0];
	var mesActual = fechaActualArr[1];
	var a�oActual = fechaActualArr[2];
	
	if (fecha.length == 0){
		error = obtenerErrorVacio();
		return false;
	}
	
	if (fecha.length != 10){
		error = obtenerErrorLongitudFecha();
		return false;
	}
	
	if (primerSlash.localeCompare("/") != 0 || segundoSlash.localeCompare("/") != 0){
		error = obtenerErrorFechaSinSlash();
		return false;
	}
	
	if (diaNum > 31 || diaNum < 1){
		error = obtenerErrorDiaInvalido();
		return false;
	}
	
	if (mesNum > 12 || mesNum < 1){
		error = obtenerErrorMesInvalido();
		return false;
	}
	
	if (parseInt(a�oActual) - a�oNum > 1){
		error = obtenerErrorFechaDiferenteA�o();
		return false;
	} else{
		if (parseInt(mesActual) - mesNum > 1){
			error = obtenerErrorDiferenciaUnMes();
			return false;
		} else if (parseInt(mesActual) - mesNum == 0){
			if (parseInt(diaActual) - diaNum > 15){
				error = obtenerErrorDiferenciaQuinceDias();
				return false;
			}
		} else if (parseInt(mesActual) - mesNum == 1){
			if (parseInt(diaActual) > 10 || diaNum < 16){
				error = obtenerErrorDiferenciaQuinceDias();
				return false;
			}
			
		}
	}
	
	error = "";
	
	return true;
}

// Valida si un valor de un campo es num�rico
function esNumerico(num){
	return !isNaN(parseFloat(num)) && isFinite(num);
}