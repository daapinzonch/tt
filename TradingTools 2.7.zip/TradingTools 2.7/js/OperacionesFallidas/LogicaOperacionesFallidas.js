// Objetos ActiveX
var conexion = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
var red = new ActiveXObject("WScript.Network");
var objetoDeArchivos = new ActiveXObject("Scripting.FileSystemObject");
var currentUserMail = "";
// User type
var userType = "";
// Mail Traders/Consultants
var mailTradersUpper = [];var mailTradersNormal = [];
// Name Traders/Consultants
var tradersUpper = [];var tradersNormal = [];
// Mail Consultor
var mailConsultorUpper = [];var mailConsultorNormal = [];
// Name consultor
var ConsultorUpper = [];var ConsultorNormal = [];
// Arreglos de meses para convertir de numero a texto
var mesesNum = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"];
var mesesComp = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
// Almacena errores de los campos
var error = "";
// Almacena las validaciones de los campos del formulario
var validacionCampos = [false, true, false, false, false, false, false, false, false, true, true, true, true, true, true];
// Almacena todos los traders
var arregloTraders = [];
var arregloTradersCorreo = [];
var tradersParaMostrar = "";
// Almacena datos para validar si una operaci�n fallida ya existe en la base de datos
var datosParaValidar = "";

/***********************************************************/
/********************** START LOGIC ************************/
/***********************************************************/
showMessageLoading("tituloNotificacion", "cuerpoNotificacion");
showLoadingOverlay();

$(document).ready(function() {
	// Put current version
	assignContent("#version", "v" + getContentTxtFile(getUrlVersionFile(), objetoDeArchivos));
	// Oculta el mensaje de inicio
	$("#loading").addClass(' hide');
	$("#contenedorBoton").removeClass(' hide');
	$("#contenedorTabla").removeClass(' hide');
	
	// Get Traders/Consultants mail and name
	getTradersConsultantsNameAndMail(conexion, recordSet, queries.queryGetTraders, stringConnections.strConexionDataMart, tradersUpper, mailTradersUpper, tradersNormal, mailTradersNormal);
	getTradersConsultantsNameAndMail(conexion, recordSet, queries.queryGetConsultants, stringConnections.strConexionDataMart, ConsultorUpper, mailConsultorUpper, ConsultorNormal, mailConsultorNormal);
	// Get user
	currentUserMail = consultarTraderCorreo(users.currentUser);
	// Get User Rol
	userType = getUserType(conexion, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
	
	if(compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI") || compareString(userType, "GerencialI")) {
		$("#bdb2").addClass(' hide');
		// $("#panelOpcional").addClass(' hide');
		// $("#panelObligatorio").parent().addClass(' col-lg-12');
		// $("#panelObligatorio").parent().removeClass('col-lg-6');
		// $(".modal-dialog2").addClass('modal-dialog');
		// $(".modal-dialog2").removeClass('modal-dialog2');
	}
	
	// Show connected user
	showUserConnected("#connected-user");
	// Show modules for user
	showModules(userType);
	// Inserta log cada vez que el usuario ingrese a la p�gina
	insertLog(conexion, "Operaciones Fallidas WEB");
	// Users to show Me
	if (compareString(userType, "GerencialT") || compareString(userType, "GerencialI")){
		usuariosaMostrar = consultarUsuariosaMostrar(replaceAll(queries.queryGetUsersByArea, "rUsuario", users.currentUser), stringConnections.strConexionDataMart);
	} else if (compareString(userType, "Administrador")){
		usuariosaMostrar = "";
	} else{
		usuariosaMostrar = consultarUsuariosaMostrar(replaceAll(queries.queryGetUsersToShow, "rUsuario", users.currentUser), stringConnections.strConexionDataMart);
	}
	// Consulta Fallidas para mostrarlas
	var datosTabla = consultarFallidas(queries.consultaOperacionesFallidas + usuariosaMostrar, stringConnections.strConexionFailedOperations);
	// Crea, llena y muestra la tabla
	construirTabla(headers.encabezadosTablaFallidas, datosTabla);
	instanciarTabla();
	// Add Horizontally Scroll on datatable
	putScrollOnTable("#tablaResultados");
	// Muestra hora en que se abrio el formulario
	mostrarHoraActual("horaActual");
	// Agregar las opciones a los combos
	cargarCombos();
	// Crea los Combos editables
	mostrarCombos();
	// Crea el datePicker
	instanciarDatePicker();
	
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});
	
	// Valida fecha
	$("#fechas").focusout(function (){
		validarCampo(validarFecha(), "fechas", "divFecha", "Fecha", "labelFecha", 0);
	});
	// Valida trader
	$("#contenedorComboTraders").focusout(function (){
		validarCampo(validarTrader(), "traders", "contenedorComboTraders", "Trader/Consultor", "labelTrader", 1);
	});
	
	// Valida Nit
	$("#contenedorComboNits").focusout(function (){
		validarCampo(validarNit(), "nits", "contenedorComboNits", "Nit", "labelNit", 2);
	});
	
	// Valida cliente
	$("#cliente").focusout(function (){
		validarCampo(validarCliente(), "cliente", "divCliente", "Cliente", "labelCliente", 3);
	});
	
	// Valida Tipo Operacion
	$("#contenedorComboTipoOperacion").focusout(function (){
		validarCampo(validarTipoOperacion(), "tiposOperacion", "contenedorComboTipoOperacion", "Tipo de Operaci�n", "labelTipoOperacion", 4);
	});
	
	// Valida par Moneda
	$("#contenedorComboParMoneda").focusout(function (){
		validarCampo(validarParMoneda(), "parMonedas", "contenedorComboParMoneda", "Par Moneda", "labelParMoneda", 5);
	});
	
	// Valida producto
	$("#contenedorComboProductos").focusout(function (){
		validarProducto();
		validarCampo(validarProducto(), "productos", "contenedorComboProductos", "Producto", "labelProducto", 6);
		mostrarOcultarInputs();
	});
	
	// Valida monto
	$("#monto").focusout(function (){
		$("#messageUsdAmountInput").addClass("hide");
		validarCampo(validarMonto(), "monto", "divMonto", "Monto (USD)", "labelMonto", 7);
	});
	
	$("#monto").focusin(function (){
		$("#messageUsdAmountInput").removeClass("hide");
	});
	
	// Valida razon
	$("#contenedorComboRazon").focusout(function (){
		validarCampo(validarRazon(), "razones", "contenedorComboRazon", "Perdido por", "labelRazon", 8);
	});
	
	// Valida Plazo esperado
	$("#plazoEsperado").focusout(function (){
		validarCampo(validarPlazoEsperado(), "plazoEsperado", "divPlazoEsperado", "Plazo Esperado", "labelPlazoEsperado", 9);
	});
	
	// Valida tasaBDB1
	$("#bdb").focusout(function (){
		validarCampo(validarBDB("bdb"), "bdb", "divBDB", "Tasa BDB", "labelBDB", 10);
	});
	
	// Valida tasaBDB2
	$("#bdb2").focusout(function (){
		validarCampo(validarBDB("bdb2"), "bdb2", "divBDB", "Tasa BDB", "labelBDB", 11);
	});
	
	// Valida tasaOB
	$("#otroBanco").focusout(function (){
		validarCampo(validarBDB("otroBanco"), "otroBanco", "divOB", "Tasa Otro Banco", "labelOB", 12);
	});
	
	// Valida Banco
	$("#contenedorComboBanco").focusout(function (){
		validarCampo(validarBanco(), "bancos", "contenedorComboBanco", "Banco", "labelBanco", 13);
	});
	
	$("#comentario").focusout(function (){
		validarCampo(validarTxtAreaComentarios(), "comentario", "contenedorComentarios", "Comentarios", "labelComentarios", 14);
	});
	
	// Actualiza la hora del formulario
	$("#botonAgregarFallida").on('click',function(){
		mostrarHoraActual("horaActual");
		$("#traders").val(currentUserMail);
	});
	
	// Coloca opciones en el combo nits mientras que la longitud escrita sea igual a 5
	//$('#contenedorComboNits').keyup(function (e){
	//		validarLongitud(e);
	//});
	
	// Coloca opciones en el combo nits mientras que la longitud escrita sea igual a 5
	$('#contenedorComboNits').keyup(function (e){
		var longitud = $('#nits').val().length;
		var estadoBoton = longitud > 6 ? false : true;
		
		$("#botonBuscarCoincidencias").prop("disabled", estadoBoton);
		
		if (e.keyCode == 8){
			if (longitud == 6 || longitud == 0){
				vaciarCombo("nits");
				$('#nits').val($('#nits').val());
				moverCursorUltimaPosicion("nits", longitud);
			}
		}
	});
	
	$("#botonBuscarCoincidencias").on('click', function (e){
		showCoincidences(e, $("#nits").val(), replaceAll(queries.consultaNits, "rNit", $("#nits").val()), stringConnections.strConexionDataMart, "#nits", conexion)
	});
	
	
	// Coloca las comas de miles cada vez que se escriba en monto
	$("#monto").keyup(function (e){
		$("#monto").val(agregarComas(reemplazarTodos($("#monto").val(), ",", "")));
	});
	
	// Cuando se seleccione una opci�n del combo nits, trae el cliente
	$('#contenedorComboNits').on('select.editable-select', function (e){
		cargarCliente();
		cambiarEstadoBoton();
	});
	
	// Cuando se clickee el bot�n de autcompletar cliente, trae el cliente seg�n nit del combo nits
	$('#botonAutocompletar').on('click', function (e){
		cargarCliente();
		cambiarEstadoBoton();
	});
	
	$('#botonCerrarModal').on('click', function (e){
		$("#botonReiniciar").click();
		reiniciarValoresOpcionales();
	});
	
	$('#botonInsertar').on('click', function (e){
		var datos = formatearValoresParaInsertar();
		
		compararTraderParaInsertar(currentUserMail, $("#traders").val(), datos);
	});
	
	$('#botonReiniciar').on('click', function (e){
		$("#cliente").prop('disabled', false);
		desactivarBotonEnviar();
		eliminarCombos();
		cargarCombos();
		mostrarCombos();
		vaciarCombo("nits");
		reiniciarFormulario();
		reiniciarValoresOpcionales();
	});
	
	$('#exportarExcel').on('click', function (e){
		removeCommasToColumn("#tablaResultados", [6])
		exportTable("#tablaResultados", "Oper. Fallidas", "Oper-Fallidas_" + users.currentUser);
		putCommasToColumn("#tablaResultados", [6])
	});
	
	hideLoadingOverlay();
});

function reiniciarValoresOpcionales(){
	$("#plazoEsperado").val("");
	$("#bdb").val("");
	$("#bdb2").val("");
	$("#otroBanco").val("");
	$("#bancos").val("");
	$("#comentario").val("");
}

function instanciarDatePicker(){
	$( "#fechas" ).datepicker({
		dateFormat : 'dd/mm/yy',
		changeMonth : true,
		changeYear : true,
		beforeShowDay: $.datepicker.noWeekends,
		yearRange: '-1y:c+nn',
		prevText: 'Anterior',
		nextText: 'Siguiente',
		onSelect: function(dateText, inst){
					error = "";
					validarCampo(true, "fechas", "divFecha", "Fecha", "labelFecha", 0);
				},
		minDate: -15,
		currentText: 'Hoy',
		monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
		monthNamesShort: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
		dayNames: ['Domingo', 'Lunes', 'Martes', 'Mi�rcoles', 'Jueves', 'Viernes', 'S�bado'],
		dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mi�;', 'Juv', 'Vie', 'S�b'],
		dayNamesMin: ['Do', 'Lu', 'Ma', 'Mi', 'Ju', 'Vi', 'S�'],
		maxDate: '-d'
	});
}

function validarCampo(esValido, idCampo, contenedorCampo, textoLabel, idLabel, numCampo){
	if (esValido){
		validacionCampos[numCampo] = true;
	} else{
		validacionCampos[numCampo] = false;
	}

	mostrarValidacion(esValido, idCampo, contenedorCampo);
	mostrarError(textoLabel, idLabel);
	cambiarEstadoBoton();
}

// Pinta de rojo(error) o verde(satisfactorio) el combo y su label
function mostrarValidacion(esValido, idCombo, idContenedor){
	if (esValido){
		$("#" + idContenedor).removeClass(" has-error");
		$("#" + idCombo).removeClass(" errorInput");
		$("#" + idContenedor).addClass(" has-success");
		$("#" + idCombo).addClass(" successInput");
	} else {
		$("#" + idContenedor).removeClass(" has-success");
		$("#" + idCombo).removeClass(" successInput");
		$("#" + idContenedor).addClass(" has-error");
		$("#" + idCombo).addClass(" errorInput");
	}
}

// Obtiene los traders que podr� ver cada usuario
function consultarTraderCorreo(currentUser){
	currentUser = currentUser.toUpperCase();

	if(isInArray(currentUser, mailTradersUpper)){
		return tradersNormal[mailTradersUpper.indexOf(currentUser)];
	} else if (isInArray(currentUser, mailConsultorUpper)){
		return ConsultorNormal[mailConsultorUpper.indexOf(currentUser)];
	} else{
		return "";
	}
}

function mostrarOcultarInputs(){
	var producto = $("#productos").val();
	
	if (producto.localeCompare("COLLARES") == 0 || producto.localeCompare("FORWARD") == 0 || producto.localeCompare("OPCIONES") == 0 || producto.localeCompare("SINTETICO") == 0 || producto.localeCompare("SWAP DE CAJA") == 0){
		$("#divPlazoEsperado").removeClass(" hide");
	} else{
		$("#divPlazoEsperado").addClass(" hide");
	}
}

function cambiarEstadoBoton(){
	var estado = true;

	for (i = 0; i < validacionCampos.length; i++){
		if (validacionCampos[i] == false){
			desactivarBotonEnviar();
			estado = false;
			
			break;
		}
	}

	if (estado){
		activarBotonEnviar();
	}
}

function activarBotonEnviar(){
	$("#divBotonHide").addClass(" hide");
	$("#divBotonInsertar").removeClass(" hide");
}

function desactivarBotonEnviar(){
	$("#divBotonInsertar").addClass(" hide");
	$("#divBotonHide").removeClass(" hide");
}

function reiniciarFormulario(){
	reiniciarEstadosValidacion();
	reiniciarLabels();
}

function reiniciarLabels(){
	$("#labelFecha").html("Fecha");
	$("#labelTrader").html("Trader/Consultor");
	$("#labelNit").html("Nit");
	$("#labelCliente").html("Cliente");
	$("#labelTipoOperacion").html("Tipo de Operaci�n");
	$("#labelParMoneda").html("Par Moneda");
	$("#labelProducto").html("Producto");
	$("#labelMonto").html("Monto");
	$("#labelRazon").html("Perdido por");
	$("#labelPlazoEsperado").html("Plazo Esperado (D�as)");
	$("#labelBDB").html("Tasa BDB");
	$("#labelOB").html("Tasa Otro Banco");
	$("#labelBanco").html("Banco");
	$("#labelComentarios").html("Comentarios");
}

// Muestra el error de los campos
function mostrarError(nombreCampo, idLabel){
	$("#" + idLabel).html(nombreCampo + " " + error);
}

function reiniciarEstadosValidacion(){
	var clases = ["has-error", "errorInput", "has-success", "successInput"];
	
	removerClases(clases);
}

function removerClases(clases){
	for (i = 0; i < clases.length; i++){
		$("#divFecha").removeClass(" " + clases[i]);
		$("#contenedorComboTraders").removeClass(" " + clases[i]);
		$("#contenedorComboNits").removeClass(" " + clases[i]);
		$("#divCliente").removeClass(" " + clases[i]);
		$("#contenedorComboTipoOperacion").removeClass(" " + clases[i]);
		$("#contenedorComboParMoneda").removeClass(" " + clases[i]);
		$("#contenedorComboProductos").removeClass(" " + clases[i]);
		$("#divMonto").removeClass(" " + clases[i]);
		$("#contenedorComboRazon").removeClass(" " + clases[i]);
		$("#divPlazoEsperado").removeClass(" " + clases[i]);
		$("#divBDB").removeClass(" " + clases[i]);
		$("#divOB").removeClass(" " + clases[i]);
		$("#contenedorComboBanco").removeClass(" " + clases[i]);
		$("#divPlazoEsperado").removeClass(" " + clases[i]);
		$("#labelFecha").removeClass(" " + clases[i]);
		$("#labelTrader").removeClass(" " + clases[i]);
		$("#labelNit").removeClass(" " + clases[i]);
		$("#labelCliente").removeClass(" " + clases[i]);
		$("#labelTipoOperacion").removeClass(" " + clases[i]);
		$("#labelParMoneda").removeClass(" " + clases[i]);
		$("#labelProducto").removeClass(" " + clases[i]);
		$("#labelMonto").removeClass(" " + clases[i]);
		$("#labelRazon").removeClass(" " + clases[i]);
		$("#labelPlazoEsperado").removeClass(" " + clases[i]);
		$("#labelBDB").removeClass(" " + clases[i]);
		$("#labelOB").removeClass(" " + clases[i]);
		$("#labelBanco").removeClass(" " + clases[i]);
		$("#labelComentarios").removeClass(" " + clases[i]);
		$("#labelPlazoEsperado").removeClass(" " + clases[i]);
		$("#cliente").removeClass(" " + clases[i]);
		$("#monto").removeClass(" " + clases[i]);
		$("#plazoEsperado").removeClass(" " + clases[i]);
		$("#bdb").removeClass(" " + clases[i]);
		$("#bdb2").removeClass(" " + clases[i]);
		$("#otroBanco").removeClass(" " + clases[i]);
		$("#plazoEsperado").removeClass(" " + clases[i]);
	}
}

// Crea los Combos editables
function mostrarCombos(){
	instanciarCombo("traders");
	instanciarCombo("nits");
	instanciarCombo("tiposOperacion");
	instanciarCombo("parMonedas");
	instanciarCombo("productos");
	instanciarCombo("razones");
	instanciarCombo("bancos");
}

// Agregar las opciones a los combos
function cargarCombos(){
	var origen = compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT") ? "'Tesorer�a'" : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI") || compareString(userType, "GerencialI") ? "'Internacional'" : "NULL");
	var condicion = compareString(origen,"'Tesorer�a'") ? " WHERE DESTINO = 'Tesorer�a'" : (compareString(origen,"'Internacional'") ? " WHERE DESTINO = 'Internacional'" : "");
	agregarOpciones(convertItemsArrayToItemsEditableSelect(tradersNormal) + convertItemsArrayToItemsEditableSelect(ConsultorNormal), "traders");
	agregarOpciones(obtenerTipoOperacion(), "tiposOperacion");
	agregarOpciones(obtenerParMoneda(), "parMonedas");
	agregarOpciones(obtenerProductos(condicion), "productos");
	agregarOpciones(obtenerRazones(condicion), "razones");
	agregarOpciones(obtenerBanco(), "bancos");
}

function eliminarCombos(){
	eliminarCombo("traders");
	eliminarCombo("nits");
	eliminarCombo("tiposOperacion");
	eliminarCombo("parMonedas");
	eliminarCombo("productos");
	eliminarCombo("razones");
	eliminarCombo("bancos");
}

// Trae los items del archivo de configuraci�n y los deja listos para agregar a su combo
function obtenerItemsCombo(itemsArr){
	var items = "";
	
	for (i = 0; i < itemsArr.length; i++){
		items = items + "<option>" + itemsArr[i] + "</option>";
	}
	
	return items;
}
function obtenerBanco(){
	var items = "";
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarBanco, conexion);
	var totales = "";
	while (recordSet.EOF == false){
		totales = totales + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	return totales;
}
function obtenerRazones(condicion){
	var items = "";
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarRazon+condicion, conexion);
	var totales = "";
	while (recordSet.EOF == false){
		totales = totales + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	return totales;
}

function obtenerParMoneda(){
	var items = "";
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarParMoneda, conexion);
	var totales = "";
	while (recordSet.EOF == false){
		totales = totales + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	return totales;
}
function obtenerTipoOperacion(){
	var items = "";
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarTipoOperacion, conexion);
	var totales = "";
	while (recordSet.EOF == false){
		totales = totales + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	return totales;
}
function obtenerProductos(condicion){
	var items = "";
	conexion.Open(stringConnections.strConexionFailedOperations); 
	recordSet.Open(queries.consultarProductos+condicion, conexion);
	var totales = "";
	while (recordSet.EOF == false){
		totales = totales + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	recordSet.Close(); 
	conexion.Close();
	return totales;
}
// Carga el cliente en su combo dependiendo del nit ingresado en el combo nit
function cargarCliente(){
	var nit = $('#nits').val();
	var consulta = queries.consultaCliente;
	consulta = reemplazarTodos(consulta, "rNit", nit + "");
	
	var cliente = consultarBD(consulta);
		
	if (cliente.localeCompare("No hay resultados") == 0){
		$("#cliente").val("No se encontr� cliente para el nit introducido");
		$("#cliente").prop('disabled', false);
		
		validacionCampos[3] = false;
		mostrarValidacion(validarCliente(), "cliente", "divCliente");
	} else {
		cliente = reemplazarTodos(cliente, "<option>", "");
		cliente = reemplazarTodos(cliente, "</option>", "");
		
		$("#cliente").val(cliente);
		$("#cliente").prop('disabled', true);
		
		validacionCampos[3] = true;
		mostrarValidacion(validarCliente(), "cliente", "divCliente");
	}
}

// Valida longitud de el combo nits
function validarLongitud(e){
	var nit = $('#nits').val();
	var longitud = (nit).length;
	
	if (e.keyCode == 8){
		if (longitud == 5 || longitud == 0){
			vaciarCombo("nits");
			$('#nits').val(nit);
			moverCursorUltimaPosicion("nits", longitud);
		}
	} else{
		if (longitud == 6 || longitud == 7){
			eliminarCombo("nits");
			agregarOpciones(consultarBD(reemplazarTodos(queries.consultaNits, "rNit", nit)), "nits");
			instanciarCombo("nits");
			$('#nits').val(nit);
			moverCursorUltimaPosicion("nits", longitud);
		} 
	}
}

// Mueve el cursor a la �ltima posici�n
function moverCursorUltimaPosicion(id, longitud){
	$('#' + id).focus();
	$('#' + id)[0].setSelectionRange(longitud * 2, longitud * 2);
}

// Crea y muestra un combo editable
function instanciarCombo(id){
	$('#' + id).editableSelect();
}

// Elimina un combo editable
function eliminarCombo(id){
	$('#' + id).editableSelect("destroy");
}

// Vac�a un combo editable
function vaciarCombo(id){
	$('#' + id).editableSelect("clear");
}

// Obtiene resultados de consulta y los almacena en un string para agregarlos a un combo
function consultarBD(consulta){
	conexion.Open(stringConnections.strConexionDataMart);
	recordSet.Open(consulta, conexion);
	
	var totales = "";
	
	while (recordSet.EOF == false){
		totales = totales + "<option>" + recordSet(0).Value + "</option>";
		recordSet.MoveNext();
	}
	
	if (totales.localeCompare("") == 0){
		totales = "No hay resultados";
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	return totales;
}

// Obtiene las fechas del combo Fecha
function obtenerFechasCombo(){
	var hoy = obtenerFechaActual(0, false);
	var ayer = obtenerFechaActual(1, false);
	var anteayer = obtenerFechaActual(2, false);
	
	return "<option>" + hoy + "</option>" + "<option>" + ayer + "</option>" + "<option>" + anteayer + "</option>";
}

// Agrega valores a los combos del formulario
function agregarOpciones(valores, id){
	$("#" + id).html(valores);
}

// Muestra hora en que se abrio el formulario
function mostrarHoraActual(id){
	var fechaActual = obtenerFechaActual(0, true);
	var horaActual = obtenerHoraActual(true);
	var fechaHoraActuales = obtenerFechaHoraActual(fechaActual, horaActual);

	$("#" + id).html(fechaHoraActuales);
}

// Obtiene la hora actual
function obtenerHoraActual(conFormato){
	var horaActual = new Date();
	var formato = obtenerFormatoHora(horaActual);
	
	horaActual = validarHora(horaActual);
	
	if (conFormato){
		horaActual = horaActual + " " + formato;
	}
	
	return horaActual;
}

// Obtiene la fecha actual
function obtenerFechaActual(numeroDias, mesEnLetras){
	var horaActual = new Date();
	var a�o = horaActual.getFullYear();
	var mes = horaActual.getMonth() + 1;
	var dia = horaActual.getDate() - numeroDias;
	
	if (mesEnLetras){
		validarNumero(dia);
		mes = convertirMesALetras(mes);
		
		return dia + " " + mes + " " + a�o;
	} else{
		return revisarFecha(dia, mes, a�o);
	}
}

// Convierte un mes numerico a un mes en letras (Ej: 01 -> Ene)
function convertirMesALetras(mes){
	for (i = 0; i < mesesNum.length; i++){
		if (mes == (i + 1)){
			mes = mesesComp[i];
		}
	}
	
	return mes;
}

// valida si el d�a y mes son menores que 10 y les agrega un 0 antes
function revisarFecha(dia, mes, a�o){
	dia = validarNumero(dia);
	mes = validarNumero(mes);
	
	return dia + "/" + mes + "/" + a�o;
}

// Valida si un n�mero es menor a 10 y le agrega un cero a la izquierda
function validarNumero(num){
	if (num < 10){
		num = "0" + num;
	}
	
	return num;
}

// Obtiene la fecha y la hora actuales
function obtenerFechaHoraActual(fechaActual, horaActual){
	return fechaActual + " " + horaActual;
}

// Valida si una hora es am o pm
function obtenerFormatoHora(hora){
	var formato = "";

	if (hora.getHours() < 12){
		formato = "am";
	} else {
		formato = "pm";
	}
	
	return formato;
}

// valida si los segunods, minutos y horas son menores que 10 y les agrega un 0 antes
function validarHora(hora){
	var horas = "";
	var minutos = "";
	var segundos = "";

	if(hora.getHours() < 10){
		horas = horas + "0" + hora.getHours();
	} else{
		horas = horas + hora.getHours();
	}
	
	if(hora.getMinutes() < 10){
		minutos = minutos + "0" + hora.getMinutes();
	} else{
		minutos = minutos + hora.getMinutes();
	}
	
	if(hora.getSeconds() < 10){
		segundos = segundos + "0" + hora.getSeconds();
	} else{
		segundos = segundos + hora.getSeconds();
	}
	
	return horas + ":" + minutos + ":" + segundos;
}

// Crea e instancia la tabla
function instanciarTabla(){
	$('#tablaResultados tfoot td').each(function (){$(this).html('<input class="secondFilter" type="text" placeholder="Buscar"/>')});
	
	var myDataTable = $('#tablaResultados').DataTable({
		"lengthMenu": [[7, 15, 30, -1], [7, 15, 30, "Todos"]]
    });
	
	myDataTable.columns().eq(0).each(function (index){
		$('input', myDataTable.column(index).footer()).on('keyup change focusout', function (){
			myDataTable.column(index) .search( this.value ) .draw();
			validateSecondFilter($(this));
		});
	});
}

// Contruye la tabla de las operaciones fallidas
function construirTabla(encabezados, datosTabla){
	var thead = "<thead id='thead'><tr>";
	var tbody = datosTabla;
	
	for(i = 0; i < encabezados.length; i++){
		thead = thead + "<th>" + encabezados[i] + "</th>";
	}
	
	thead = thead + "</tr></thead>";
	
	$("#tablaResultados").append(thead);
	$("#tablaResultados").append(tbody);
}

// Consulta operaciones fallidas de uno o varios traders en especifico
function consultarFallidas(consulta, bd){
	conexion.Open(bd);
	recordSet.Open(consulta, conexion);
	
	var tbody = "<tbody>";
	var tfoot = "<tfoot><tr>";
	
	for (i = 0; i < 9; i++){tfoot = tfoot + "<td></td>"};
	
	while (recordSet.EOF == false){
		var fecha = new Date(recordSet("TransactionDate"));
		var fechaConFormato = $.datepicker.formatDate('yy/mm/dd', fecha);
		var tbody = tbody + 
					"<tr>" +
						"<td>" + fechaConFormato + "</td>" +
						"<td>" + recordSet("NIT") + "</td>" +
						"<td>" + recordSet("ClientName") + "</td>" +
						"<td>" + validateNullValue(recordSet("OperationType") + "") + "</td>" +
						"<td>" + recordSet("CurrencyPair") + "</td>" +
						"<td>" + recordSet("Product") + "</td>" +
						"<td>" + agregarComas(recordSet("Amount")) + "</td>" +
						"<td>" + recordSet("Quota") + "</td>" +
						"<td>" + recordSet("Trader") + "</td>" +
					"</tr>";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	tbody = tbody + "</body>" + tfoot + "</tr></tfoot>";
	
	return tbody;
}

function validateNullValue(value){
	if (compareString(value, "NULL") || compareString(value, "null") || compareString(value, "undefined") || value == null || value == undefined){
		return ""
	} else{
		return value;
	}
}

function consultarUsuariosaMostrar(query, stringConnection){
	conexion.Open(stringConnection);
	recordSet.Open(query, conexion);
	
	var usuarios = "";
	var entro = false;
	
	while (recordSet.EOF == false){
		entro = true;
		usuarios = usuarios + "'" + recordSet(0).Value + "',";
		
		recordSet.MoveNext();
	}
	
	recordSet.Close(); 
	conexion.Close();
	
	return entro ? " AND Trader IN(" + usuarios.substring(0, usuarios.length - 1) + ")" : "";
}

// Agrega comas de miles a un n�mero
function agregarComas(valor){
	valor = valor + '';
	
	var x = valor.split('.');
	var x1 = x[0];
	var x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	
	while (rgx.test(x1)) {
			x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	
	return x1 + x2;
}

// Reemplaza todas las coincidencias en una cadena por otro otro valor
function reemplazarTodos(texto, textoaBuscar, textoaReemplazar){
	return texto.replace(new RegExp(textoaBuscar, "g"), textoaReemplazar);
}