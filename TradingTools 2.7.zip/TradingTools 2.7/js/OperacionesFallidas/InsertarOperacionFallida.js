function formatearValoresParaInsertar(){
	var bdb = $("#bdb").val();
	
	if (bdb.localeCompare("") != 0){
		bdb = parseFloat($("#bdb").val()).toFixed(3);
	} else{
		bdb = "";
	}
	
	var bdb2 = $("#bdb2").val();
	
	if (bdb2.localeCompare("") != 0){
		bdb2 = parseFloat($("#bdb2").val()).toFixed(3);
	} else{
		bdb2 = "";
	}
	
	var tasaOB = $("#otroBanco").val();
	
	if (tasaOB.localeCompare("") != 0){
		tasaOB = parseFloat($("#otroBanco").val()).toFixed(3);
	} else{
		tasaOB = "";
	}
	
	var trader = "";
	
	for (i = 0; i < tradersNormal.length; i++){
		if (($("#traders").val()).localeCompare(tradersNormal[i]) == 0){
			trader = mailTradersUpper[i];
			
			break;
		}
	}
	
	for (i = 0; i < ConsultorNormal.length; i++){
		if (($("#traders").val()).localeCompare(ConsultorNormal[i]) == 0){
			trader = mailConsultorUpper[i];
			
			break;
		}
	}
	
	var fecha = $("#fechas").val();
	var dia = fecha.substring(0,2);
	var mes = fecha.substring(3,5);
	var a�o = fecha.substring(6,10);
	var fechaActual = obtenerFechaActual(0, false);
	var diaActual = fechaActual.substring(0,2);
	var mesActual = fechaActual.substring(3,5);
	var a�oActual = fechaActual.substring(6,10);
	// Valores a insertar
	var nit = $("#nits").val();
	var cliente = ($("#cliente").val()).toUpperCase();
	var tipoOperacion = $("#tiposOperacion").val();
	var parMoneda = $("#parMonedas").val();
	var fechaFormateada = a�o + "/" + mes + "/" + dia;
	var producto = $("#productos").val();
	var monto = parseFloat(reemplazarTodos($("#monto").val(), ",", "")).toFixed(2);
	var razon = $("#razones").val();
	var plazoEsperado = $("#plazoEsperado").val();
	var tasaBDB = bdb + "|" + bdb2;
	var banco = $("#bancos").val();
	var comentario = isInvalid($("#comentario").val(), "");
	var fechaInsercion = a�oActual + "/" + mesActual + "/" + diaActual + " " + obtenerHoraActual(false);
	var origen = compareString(userType, "TraderT") || compareString(userType, "CoordinadorT") || compareString(userType, "GerencialT") ? "'Tesorer�a'" : (compareString(userType, "ConsultorI") || compareString(userType, "CoordinadorI") || compareString(userType, "GerencialI") ? "'Internacional'" : "NULL");
	
	// Cadena con todos los valores
	
	datosParaValidar = "Trader='" + trader + "' AND NIT='" + nit + "' AND ClientName='" + cliente + "' AND TransactionDate=#" + fechaFormateada + "# AND CurrencyPair='" + parMoneda + "' AND Quota='" + razon + "' AND OperationType='" + tipoOperacion + "' AND Amount=" + monto;
	
	return "'" + trader + "', '" + nit + "', '" + cliente + "', '" + tipoOperacion + "', '" + parMoneda + "', '" + fechaFormateada + "', '" + producto + "', " + monto + ", '" + razon + "', '" + plazoEsperado + "', '" + tasaBDB + "', '" + tasaOB + "', '" + banco + "', '" + comentario + "', '" + fechaInsercion + "'," + origen;
}

function compararTraderParaInsertar(usuarioActualCorreo, traderSeleccionado, datos){
	if (compareString(userType, "Administrador")){
		insertarOperacionFallida(datos);
	} else{
		if (usuarioActualCorreo.localeCompare(traderSeleccionado) != 0){
			if (confirm("Ingresar� una operaci�n fallida para otro trader, �Desea continuar?")){
				insertarOperacionFallida(datos);
			}
		} else{
			insertarOperacionFallida(datos);
		}
	}
}

// Inserta la operaci�n fallida ingresado en el formulario
function insertarOperacionFallida(datos){
	var query = queries.consultaExistenciaFallida + datosParaValidar;
	var stringConnection = stringConnections.strConexionFailedOperations;

	if (!existInBD(conexion, recordSet, query, stringConnection)){
		conexion.Open(stringConnections.strConexionFailedOperations);
		var consulta = queries.consultaInsertarFallida;
		
		consulta = reemplazarTodos(consulta, "datos", datos);
		
		try{
			conexion.Execute(consulta);
			conexion.Close();
			
			$('#modalFormularioFallidas').modal('hide');
			$("#contenidoModalInf").html("La operaci�n fallida fue ingresada satisfactoriamente.");
			$("#tituloModalInf").html("Operaci�n fallida agregada");
			$('#modalInf').modal('show');
		} catch(e){
			alert("Error insertando fallida.");
		}
	} else{
		$('#modalFormularioFallidas').modal('hide');
		$("#contenidoModalInf").html("No se agreg� porque ya exist�a en la base de datos.");
		$("#tituloModalInf").html("Operaci�n Fallida duplicada.");
		$('#modalInf').modal('show');
	}

	$('#tablaResultados').dataTable().fnDestroy();
	$('#tablaResultados').html("");
	var datosTabla = consultarFallidas(queries.consultaOperacionesFallidas + usuariosaMostrar, stringConnections.strConexionFailedOperations);
	// Crea, llena y muestra la tabla
	construirTabla(headers.encabezadosTablaFallidas, datosTabla);
	instanciarTabla();
	$("#botonReiniciar").click();
	
	validacionCampos = [false, true, false, false, false, false, false, false, false, true, true, true, true, true, true];
}