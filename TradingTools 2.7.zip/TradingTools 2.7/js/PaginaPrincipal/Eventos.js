// Contiene todos los eventos usados en la p�gina principal
function addEvents(){
	/***********************************************/
	/******************* ONCLICK *******************/
	/***********************************************/
	// Show Quick tour when help button is clicked
	//$("#instrucciones").on('click',function(){mostrarTour()});
	
	/***********************************************/
	/******************** HOVER ********************/
	/***********************************************/
	putHoverEvent("#wizardOrdenesDePago", "#ordenesPago");
	putHoverEvent("#wizardFallidas", "#operacionesFallidas");
	putHoverEvent("#wizardTacticas", "#tacticasComerciales");
	putHoverEvent("#wizardPipeline", "#pipeline");
	putHoverEvent("#wizardVencimientos", "#vencimientos");
	putHoverEvent("#wizardPET", "#PET");
	putHoverEvent("#wizardDirectorio", "#directorio");
	
	// Hide Sidebar
	$('#dismiss, .overlay').on('click', function () {
		$('#sidebar').removeClass('active');
		$('.overlay').fadeOut();
	});

	// Show Sidebar
	$('#menu-button').on('click', function () {
		$('#sidebar').addClass('active');
		$('.overlay').fadeIn();
		$('.collapse.in').toggleClass('in');
		$('a[aria-expanded=true]').attr('aria-expanded', 'false');
	});

	$('.has-tooltip').tooltip({
		selector: "[data-toggle=tooltip]",
		container: "body"
	});

	// Show Search Modal
	$("#christmas-card").on('click', function(){
		resetModal([["#nit-gift-modal", "input"]]);
		resetModal([["#unity-gift-modal", "input"]]);
		resetModal([["#gift-mails", "container"]]);
		$('[name="idioma"]').prop('checked',false);
		$('[name="tipo"]').prop('checked',false);
		addClass("#informaci�n",'hide')
		correos = [[""],[]];
		$("#gift-modal").modal('show');
	});

	$("#gift-modal").on('shown.bs.modal', function () {
		$('#nit-gift-modal').focus();
	});
	
	$('[name="tipo"]').change(function() {	
		if( $('[name="tipo"]:checked').val() == "Nit"){
			removeClass("#nit-container", "hide"); 
			addClass("#unity-container", "hide");
		}else if($('[name="tipo"]:checked').val() == "Unidad"){
			removeClass("#unity-container", "hide");
			addClass("#nit-container", "hide"); 
		}

	});
	
	// Show Customer Information Modal
	$("#gift-button-modal").on('click', function(){
		resetModal([["#gift-mails", "container"]]);
		var nit = $("#nit-gift-modal").val().trim();
		correos = [[""],[]];
		if (!compareString(nit, "")){
			correos = getContacts(connection, recordSet, stringConnections.strConexionContactos, replaceAll(queries.queryGetEmailContactsNit,'R_NIT', nit));
			if (correos[1].length > 0){
				$("#gift-mails").append(correos[0]);
				removeClass("#informaci�n",'hide');
				removeClass("#gift-mails","resize");
			} else{
				var correo = prompt("Este cliente no tiene ning�n correo registrado dentro de sus Contactos, por favor ingrese uno", "");
				var html = "";
				(correo.split(";")).forEach(function(e){
					correos[1].push(e);
					html = html + "<div class='col-md-6 col-md-offset-6 text-center info mails'><p><span>"+ e +"</span></p></div>";
				})

				$("#gift-mails").append(html);
				removeClass("#informaci�n",'hide');
				//$(".mails").append(correos);
			}
		} else{
			showBootstrapDialog("Informaci�n", "Por favor ingrese un nit para realizar la b�squeda", "DANGER", "ALERT", "SMALL");
		}
	});



	$("#unity-button-modal").on('click', function(){
		resetModal([["#gift-mails", "container"]]);
		var unity = $("#unity-gift-modal").val().trim();
		correos = [[""],[]];
		if (!compareString(unity, "")){
			correos = getContacts(connection, recordSet, stringConnections.strConexionContactos, replaceAll(queries.queryGetEmailContactsUnity,'R_UNITY', unity));
			if (correos[1].length > 0){
				$("#gift-mails").append(correos[0]);
				addClass("#gift-mails","resize");
				removeClass("#informaci�n",'hide');
			} else{
				showBootstrapDialog("Informaci�n", "Esta unidad no tiene ning�n correo registrado dentro de sus Contactos", "DANGER", "ALERT", "SMALL");
			}
		} else{
			showBootstrapDialog("Informaci�n", "Por favor ingrese una unidad para realizar la b�squeda", "DANGER", "ALERT", "SMALL");
		}
	});
	

	$('#mail-form').submit(function(e) { 
		e.preventDefault();
		var network = new ActiveXObject('WScript.Network');
		var serverName = network.computerName.toUpperCase();
		var	ImgESP = "<img src='" + replaceAll(getLogoCumple(),'TradingTools.html',"\\img\\nav-esp.jpg") + "'style='width:auto;heigth:auto'>";
		var	ImgENG = "<img src='" + replaceAll(getLogoCumple(),'TradingTools.html',"\\img\\nav-eng.jpg")  + "'style='width:auto;heigth:auto'>";
		try {
			if (compareString(serverName, "ARIESTES02") || compareString(serverName, "ARIESTES01") || compareString(serverName, "WIN2012P02.banbta.net") || compareString(serverName, "WIN2012P02")){
				var cdoMsg = new ActiveXObject("CDO.Message");
				cdoMsg.From = users.currentUser + "@bancodebogota.com.co";
				cdoMsg.To = users.currentUser + "@bancodebogota.com.co";
				cdoMsg.Subject = "Tarjeta Navidad" ;
				cdoMsg.HTMLBody = $('[name="idioma"]:checked').val() == "Espa�ol" ? "<span style='font-family: arial'>Estimado Cliente,<br><br></span><span>"+ replaceAll(correos[1].toString(),',',';') +"</span><br><br>"+ ImgESP +"<br><br>" : $('[name="idioma"]:checked').val() == "Ingles" ? "<span style='font-family: arial'>Dear Customer,<br><br></span><span>"+ replaceAll(correos[1].toString(),',',';') +"</span><br><br>"+ ImgENG +"<br><br>" : alert("Error Imagen");
				var namespace = "http://schemas.microsoft.com/cdo/configuration/";
				cdoMsg.Configuration.Fields.Item(namespace + "sendusing") = 2;
				cdoMsg.Configuration.Fields.Item(namespace + "smtpserver") = "outlook.bancodebogota.net";
				cdoMsg.Configuration.Fields.Item(namespace + "smtpserverport") = 25;
				cdoMsg.Configuration.Fields.Item(namespace + "sendusername") = "Internacional@bancodebogota.com.co";
				cdoMsg.Configuration.Fields.Update();
				cdoMsg.Send();
			} else{
				// Crea y abre una instancia de Outlook
				var outlook = new ActiveXObject('Outlook.Application');
				//Usuario de red
				var To = users.currentUser + "@bancodebogota.com.co";
				// Abre una nueva ventana de correo
				var email = outlook.CreateItem(0);
				// Agrega Destinatarios
				email.Recipients.Add(To);
				//Cliente en oculto	
				email.Bcc = replaceAll(correos[1].toString(),',',';');
				// Asunto
				email.Subject = "Tarjeta Navidad";
				// Muestra el contenido del correo
				email.Display();
				// Coloca contenido en el correo
				email.HTMLBody =  $('[name="idioma"]:checked').val() == "Espa�ol" ? "<span style='font-family: arial'>Estimado Cliente,<br><br></span>"+ ImgESP +"<br><br>" : $('[name="idioma"]:checked').val() == "Ingles" ? "<span style='font-family: arial'>Dear Customer,<br><br></span>"+ ImgENG +"<br><br>" : alert("Error Imagen");
				
			}
		}
		catch(e) {
				alert(e.message);
			}






		$("#gift-modal").modal('hide');
	});


	// Allow Only Numeric Values For All Numeric Inputs 
	$("#nit-gift-modal").keydown(function (e){allowNumericValues(e)});
	$("#unity-gift-modal").keydown(function (e){allowNumericValues(e)});
	
	// When Enter Key is pressed, button too
	$('#nit-gift-modal').keydown(function(e){if (e.keyCode == 13) {$('#gift-button-modal').click()}});
	$('#unity-gift-modal').keydown(function(e){if (e.keyCode == 13) {$('#unity-button-modal').click()}});




}

// Put Hover Events on Wizzard Buttons
function putHoverEvent(buttonSelector, tabSelector){
	$(buttonSelector).hover(
		function(){$(tabSelector).addClass(" active")},
		function(){$(tabSelector).removeClass(" active")}
	);
}


function getContacts (connection, recordSet, stringConnection, query){
	var correos = [[""],[]];

	try{
		connection.Open(stringConnection);
		recordSet.Open(query, connection);
		
		while (!recordSet.EOF){
			var customer = recordSet(0).Value;
			var email = recordSet(1).Value;
			correos[0] = correos[0] + "<div class='col-md-6 text-center info'><p><span>"+ customer +"</span></p></div> <div class='col-md-6 text-center info mails'><p><span>"+ email +"</span></p></div>";
			correos[1].push(email);
			recordSet.MoveNext();
		}
	}
	catch(e){
		alert(e.message);
	}
	finally{
		recordSet.Close();
		connection.Close();
	}
	
	return correos;
}


function getLogoCumple(){
	var rutaActual = location.pathname;
	rutaActual = rutaActual.substring(1, rutaActual.length);
	rutaActual = replaceAll(rutaActual, "/", "\\");
	rutaActual = replaceAll(rutaActual, "%20", " ");
	// rutaActual = replaceAll(rutaActual, "html\\Vencimientos.html", "img\\logo.png");
	return rutaActual;
}