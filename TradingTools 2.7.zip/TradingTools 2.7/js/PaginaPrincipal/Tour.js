// Muestra el tour (demo)
function mostrarTour(){
	var tour = new EnjoyHint({});
	var pasosTour = [];
	
	if (compareString(userType, "Consultor")){
		pasosTour = [
			{'next .tacticasComerciales':'Permite el ingreso al m�dulo de T�cticas Comerciales.','skipButton':{text:'Saltar'},'nextButton':{text:'Siguiente'},'shape':'circle'},
			{'next .tabNovedades':'Aqu� se encuentran las novedades de cada versi�n.','skipButton':{text:'Saltar'},'nextButton':{text:'Siguiente'}},
			{'click #menu-toggle':'Presione aqu� para desplegar el men�.','skipButton':{text:'Saltar'},'shape':'circle','showSkip':false},
			{'next .linksMenu':'Tambi�n podr� ingresar a los m�dulos desde aqu�.','nextButton':{text:'Finalizar'},'showSkip':false}
		];
	} else if(compareString(userType, "Trader") || compareString(userType, "Administrador")){
		pasosTour = [
			{'next .ordenesPago':'Permite el ingreso al m�dulo de �rdenes de Pago.','skipButton':{text:'Saltar'},'nextButton':{text:'Siguiente'},'shape':'circle'},
			{'next .operacionesFallidas':'Permite el ingreso al m�dulo de Operaciones Fallidas.','skipButton':{text:'Saltar'},'nextButton':{text:'Siguiente'},'shape':'circle'},
			{'next .tacticasComerciales':'Permite el ingreso al m�dulo de T�cticas Comerciales.','skipButton':{text:'Saltar'},'nextButton':{text:'Siguiente'},'shape':'circle'},
			{'next .tabNovedades':'Aqu� se encuentran las novedades de cada versi�n.','skipButton':{text:'Saltar'},'nextButton':{text:'Siguiente'}},
			{'click #menu-toggle':'Presione aqu� para desplegar el men�.','skipButton':{text:'Saltar'},'shape':'circle','showSkip':false},
			{'next .linksMenu':'Tambi�n podr� ingresar a los m�dulos desde aqu�.','nextButton':{text:'Finalizar'},'showSkip':false}
		];
	} else{
		return;
	}
	
	tour.set(pasosTour);
	tour.run();
}