/***********************************************************/
/*********************** VARIABLES *************************/
/***********************************************************/
// ActiveX Objects for DataBase
var connection = new ActiveXObject("ADODB.Connection");
var recordSet = new ActiveXObject("ADODB.Recordset");
// ActiveX Object for verify new updates
var fileObject = new ActiveXObject("Scripting.FileSystemObject");
// ActiveX object for detect current user
var net = new ActiveXObject("WScript.Network");
// User type
var userType = "";
//Array for Christmas Card
var correos = [[""],[]];
var today = new Date();
/***********************************************************/
/********************** START LOGIC ************************/
/***********************************************************/
showMessageLoading("tituloNotificacion", "cuerpoNotificacion");

$(document).ready(function() {
	try{
		// Verify if new updates are available
		actualizar(fileObject);
		// Get User Rol
		userType = getUserType(connection, recordSet, queries.queryGetRol, stringConnections.strConexionDataMart);
		// Center the content
		addClass("#rowPrincipal", "col-md-6 col-md-offset-3");
		// Show connected user
		showUserConnected("#connected-user");
		// Show modules for user
		showModules(userType);
		// Hide start message when page is charged and show main container
		hideStartMessage("#loading", "#divPrincipal");
		//Validate Button Christmas Card
		(today.getDate() >= 1 && today.getDate() <= 26 &&  today.getMonth() + 1 == 12 ) ? removeClass("#christmas-card","hide") : addClass("#christmas-card","hide");
		//Add All Events
		addEvents();
	} catch(e){
		removeClass("#panelLoading", "panel-primary");
		addClass("#panelLoading", "panel-red");
		assignContent("#tituloNotificacion", "Error");
		assignContent("#cuerpoNotificacion", e.message);
	}
});

